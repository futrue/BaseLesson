//
//  main.c
//  题2
//
//  Created by lanou3g on 15/4/3.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#include <stdio.h>
#include <stdbool.h>
typedef struct
{
    char name[20];
    float score;
}stu;
bool sortByScore(stu *stu1,stu *stu2);
bool sortByName(stu *stu1,stu *stu2);
void sortStudent(stu a[],int lenth,bool (*p)(stu*,stu*));

int main(int argc, const char * argv[]) {
    
//    有30个学⽣生需要排序
//    1.按姓名排
//    2.按成绩排
//    3.按年龄排
    char str[20]={0};
    stu s1={"xiaoA",98.5};
    stu s2={"xiaoB",88.5};
    stu s3={"xiaoC",78.5};
    stu s4={"xiaoD",68.5};
    stu s5={"xiaoE",95.5};
    stu STU[5] = {s1,s2,s3,s4,s5};
    printf("输入相应的功能（sortByScore sortByName）：");
    scanf("%s",str);
    if(strcmp(sortByScore, str))
    {
        sortStudent(STU,5,sortByScore);
        printf("按成绩排的顺序：");
        for (int i=0; i<5; i++)
        {
            printf("姓名：%s，成绩：%f",STU[i].name,STU[i].score);
        }
    }
    else if (strcmp(sortByName, str))
    {
        sortStudent(STU,5,sortByName);
        printf("按姓名排的顺序：");
        for (int i=0; i<5; i++)
        {
            printf("姓名：%s，成绩：%f",STU[i].name,STU[i].score);
        }
    }
    
    
    
    
    
    
    return 0;
}
//定义一个排序规则
bool sortByScore(stu *stu1,stu *stu2)
{
    return (stu1->score)>(stu2->score);
}
//再定义一个排序规则
bool sortByName(stu *stu1,stu *stu2)
{
    return strcmp(stu1->name, stu2->name);
}
//写一个排序函数，这个函数可以根据，第三个参数来实现不同的排序
void sortStudent(stu a[],int lenth,bool (*p)(stu*,stu*))
{
    for (int i =0; i<lenth; i++)
    {
        for (int j =0; j<lenth-1+i; j++)
        {
            if (p(&a[j],&a[j+1]))
            {
                stu temp;
                temp = a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
        }
    }
}
