//
//  main.c
//  题3
//
//  Created by lanou3g on 15/4/3.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#include <stdio.h>
typedef struct
{
    char name[20];
    int score;
}stu;
void changeStudentName(stu  *STU);
void findStudent(stu s[],int lenth,void(*p)(stu *));

int main(int argc, const char * argv[]) {
  //写一个函数查找成绩90分以上的学员,使⽤用回调函数在姓名后加”学霸”。
    stu s1={"xiaoA",98.5};
    stu s2={"xiaoB",88.5};
    stu s3={"xiaoC",78.5};
    stu s4={"xiaoD",68.5};
    stu s5={"xiaoE",95.5};
    stu STU[5] = {s1,s2,s3,s4,s5};
    findStudent(STU,5,changeStudentName);
    printf("查找后的学员：\n");
    for (int i =0; i<5; i++)
    {
        printf("名字：%s，分数：%d\n",STU[i].name,STU[i].score);
    }
    
    
    
    
    
    
    
    
    return 0;
}
void changeStudentName(stu  *STU)
{
    strcat(STU->name, "学霸");
}
void findStudent(stu s[],int lenth,void(*p)(stu *))
{
    for (int i=0; i<lenth; i++)
    {
        if (s[i].score>90)
        {
            p(&s[i]);//在函数里面使用了，改变函数，只不过以函数指针的形式使用，这就是回调函数
        }
    }
}