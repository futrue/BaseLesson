//
//  main.c
//  题1
//
//  Created by lanou3g on 15/4/3.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
void goStep();
void BackStep();

typedef void(*p)();

p RandStep(int a)
{
    if (a%2==0)
    {
        return BackStep;
    }
    return goStep;
}

int main(int argc, const char * argv[]) {
   
    
    
    int a = (arc4random()%6)+1;
    p fun = RandStep(a);
    fun();

    return 0;
}

void goStep()
{
    printf("恭喜你前进10步\n");
}
void BackStep()
{
    printf("恭喜你回到原点");
}