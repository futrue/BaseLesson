//
//  main.c
//  lesson_C_3
//
//  Created by lanou3g on 15/3/24.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
#if 0
/*
 **********************1.while*******************************
 语法 while（循环条件）
       {
           循环体（循环要执行的代码）
       }
 注意：
      while循环，必须要有一个变量来控制循环次数，并且这个变量要定义在循环体的外面
      while会先判断循环条件是否成立，再决定是否执行循环体
      while循环的控制变量一定要在循环体内改变，不然会造成死循环
 
 */
    int i = 1;//定义一个变量来控制循环
    while (i<11)
    {
        printf("当前循环是第%d\n",i);
        i++;
    }
    while (i<=100)
    {
        if (i%7==0)
        {
            printf("100以内7的倍数的数为%d\n",i);
        }
        else if (i%10==7)
        {
            printf("100以内尾数为7的数为%d\n",i);
        }
        else if (i/10==7)
        {
            printf("100以内十位数为7的数为%d\n",i);
        }
        i++;
    }
 
/* 
 *************************2.do-while******************************
    do {
        循环体
    } while (判断条件);
     1.do-while循环先执行一次循环体，再去判断是否继续执行
     2.do-while循环后面有个分号
     3.do-while循环仍然需要一个变量控制循环次数，并且定义在循环体外，改变在循环体内
 */
    do
    {
        if (i%7==0)
        {
            printf("100以内7的倍数的数为%d\n",i);
        }
        ++i;
    }
    while (i<=100);
    do
    {
        if (i%7==0)
        {
            printf("100以内7的倍数的数为%d\n",i);
        }
        else if (i%10==7)
        {
            printf("100以内尾数为7的数为%d\n",i);
        }
        else if (i/10==7)
        {
            printf("100以内十位数为7的数为%d\n",i);
        }
             ++i;
    }
    while (i<=100);
/*
 ***********************3.for**************************************
 for (表达式1; 表达式2; 表达式3) 
 {
         循环语句4
 }
  表达式1：初始化循环变量（从哪里开始）
  表达式2：循环条件（什么时候结束）
  表达式3：循环变量自身的改变 例如：i++
  循环语句4：满足循环条件就会一直执行
 循环顺序：表1->表2->语句4->表3->表2->语句4->表3
              |(不成立)        |(不成立)
            结束循环          结束循环
 */
    for (int num1 = 50 ;num1<=100; num1++)
    {
        if (num1%7==0)
        {
            continue;//结束本次循环
            break;//跳出整个循环
        }
              printf("num1=%d\n",num1);
    }
/*
    for (表1; 表2; 表3)
    {
        for (表1; 表2; 表3)
        {
            内层语句
        }
    }
  多层for循环，每次都是内层for循环全部循环完毕之后，才会跳出倒外层循环，然后外层循环加1之
  后，再次进入内层循环
*/
    for (int i = 0; i<123; i++)
    {
        printf("i=%2d;",i);//%2d的意义
        for (int j = 0; j<5; j++)
        {
            printf("j=%d ",j);
        }
            printf("\n");
    }


   
    for (int i = 1; i<10; i++)
    {
         for (int j = 1; j<i; j++)
        {
            printf("  ");
        }
            for (int k = 1; k<=10-i; k++)
            {
                printf("* ");
            }
          printf("\n");
    }
#endif
    for (int i = 1; i<10; i++)
    {
        for (int j = 1; j<=i; j++)
        {
            printf("%d*%d=%2d ",j,i,j*i);
        }
        printf("\n");
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}
