//
//  main.c
//  lesson_C_10
//
//  Created by lanou3g on 15/4/2.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, const char * argv[]) {
    /*
    栈区：在函数内部声明的变量都存在栈区，只管申请，系统会帮我们自动释放，释放的时间是作用域结束，遵循先进后出（FILO），栈的开辟是连续的，不会造成内存碎片，效率比较高
     堆区：堆区是五个区中占用比例最大的一个区，堆区需要我们手动的开辟，然后手动释放，遵循队列的原则（FIFO）
     全局区（静态全局区）：存放的是全局变量和静态变量，生命周期长，一直到程序结束才释放，静态变量是用static修饰的变量只初始化一次
     常量区：主要存放一些常量，常量区的数据不可以被修改
     代码区：所编写的原文件，被编译过的二进制文件都是存放在代码区，代码区是内存中最小的一个区
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     */
    
    //栈区
    int a = 10;
    printf("a的地址为%p\n",&a);
    int b  = 1;
    printf("b的地址为%p\n",&b);
    
    //堆区
    int *p = NULL;
    p = (int *)malloc(sizeof(int)*1);//int *p = malloc(4);
    *p = 10;
    printf("地址：%p,值：%d\n",p,*p);
    free(p);
    p = NULL;
    
    int *array=malloc(4);
    *array=1;
    free(array);//只释放内存空间
    array=NULL;//数据重置为NULL
    //静态区（全局区）
    /*
     修饰变量
     1.static修饰的静态变量只初始化一次
     2.static修饰的变量存在静态区，其生命周期是整个应用程序，但是static修饰的全局变量可以被其他文件使用，没有被static修饰的变量只能在源文件使用
     3.static修饰的局部变量，虽然生命周期是整个应用程序周期，但是也只能被作用于内的函数和变量使用
     修饰函数
     static修饰的函数只能被源文件使用，没有被static修饰的函数，可以跨文件使用，正好和static修饰变量相反
     */
  
    for (int i =0; i<4; i++)
    {
        static int a = 2;
        printf("a=%d,a的地址=%p\n",a,&a);
        a++;
    }
    
    //常量区（用常量修饰的在常量区，不可以被修改）
    //大致分为const type value；type const value
    
    
    
    
    
    
    const char *str1="iphone";
    char str2[] = "iphone";
    printf("str1：%p str2：%p iphone=%p\n",str1,str2,"iphone");
    str2[0]='I';
    printf("str2=%s\n",str2);
    
    //常量指针指向的内容不能修改，但是指向可以修改
    const char str3[]="iOS";
    str1=str3;
    printf("str1的内容为%s\n",str1);//const修饰的是内容
    
    
    //指针常量的指向不能修改，指向的内容可以修改
    char arr[] = "iphone";
    char *const p1 =arr;//const修饰的是指针（地址）
    
    //关于内存的一些函数
    int *a2=malloc(sizeof(int)*10);
    //realloc（）函数，根据给定的内存地址，重新开辟空间
    realloc(a2, 20);
    free(a2);
    a2=NULL;
    
    //内存设置
    char *name =malloc(sizeof(char)*100);
    memset(name, 'c', 100);//name:从哪里开始初始化，'c':初始内容，100：长度
    printf("%s\n",name);
    free(name);
    name=NULL;
    
    //内存比较 
    char *s1 = malloc(10);
    char *s2 = malloc(10);
    strcpy(s1, "iPhone");
    strcpy(s2, "iOS");
    int result = memcmp(s1, s2, 10);//不确定字符串
    printf("result=%d",result);
    free(s1);
    s1=NULL;
    free(s2);
    s2=NULL;
    
    //内存拷贝函数
    char *name1 =malloc(sizeof(char)*20);
    memcpy(name1, "ipad", 3);
    printf("name1=%s\n",name1);
    free(name1);
    name1=NULL;//不NULL,会形成野指针
    
    return 0;
}
