//
//  main.c
//  lesson_C_7
//
//  Created by lanou3g on 15/3/30.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#include <stdio.h>
//结构体，枚举，一般都写在程序的开头，这样的话作用更大
struct MyPoint
{
    int x;
    int y;
};



int main(int argc, const char * argv[]) {
/***********************************结构体************************************
 语法：struct 结构体名
      {
        成员变量1:
        成员变量2:
        。。。
      };
 注意：
 1.最后要以分号结束
 2.struct结构体的关键字
 3.struct+结构体名 一起表示一种类型
计算结构体在内存中的字节数（重点）
 
 
     
*/
    
    
//定义一个结构来形容一个学生的信息
   typedef  struct StudentInfo
    {
        int age;
        char name[20];
        float score;
    }student ;
   student  stu1={20,"zhangsan",95.3};
// 结构体的使用(struct StudentInfo类型)
//结构体赋值首先定义一个结构体变量，让后依次按结构体定义的成员变量顺序，进行赋值
//结构体的使用
    printf("张三的成绩为%.2f\n",stu1.score);//保存两位有效数字
    
    struct MyPoint p1={10,20};
    printf("p1这个点的坐标为(%d,%d)\n",p1.x,p1.y);
 
//匿名结构体
  /*
   1.匿名结构体不需要结构体名字
   2.需要在定义好结构体后的时候就对其赋值；
   3.在给结构体变量赋完值之后以分号结束
   4.其实就是将结构体烦人定义和赋值写在了一起
   
   */
    struct
    {
        int yuwen;
        int shuxue;
        int yingyu;
    }s1={80,88,92},s2={85,83,90};
//typedef类型重命名(只能对类型重新定义)
    typedef int  MyInt;//对int类型重新取了一个名字叫MyInt，在程序中MyInt就和int一样
    MyInt a = 10;
    printf("a=%d\n",a);
    
    typedef struct StudentInfo SI;
    SI stu4={2,"lisi",'W',98.5};
    printf("stu4的名字叫做%s\n",stu4.name);
    
 //在结构体定义的时候就用typedef定义,需要在定义完了之后，再去写上给他起的一个别名，本例中的S
    
    typedef struct Student
    {
        char name[20];
        char address[10];
        long int phone;
    }S;
    S stu5={"wangwu","beijing",123};
    printf("stu5住在%s\n",stu5.address);
    
    
    
   student stu2={21,"lisi",88.6};
   student stu3={18,"wangwu",99.4};
    
 //求年龄最小的
    if (stu1.age<=stu2.age&&stu1.age<=stu3.age)
    {
        printf("年龄最小的学生是%s",stu1.name);
    }
    else if(stu2.age<=stu1.age&&stu2.age<=stu3.age)
    {
        printf("年龄最小的学生是%s",stu2.name);
    }
    else
    {
        printf("年龄最小的学生是%s\n",stu3.name);
    }
     printf("stu1在内存中占得字节数为%lu\n",sizeof(stu1));
    printf("stu5在内存中占得字节数为%lu\n",sizeof(stu5));
//结构体求字节长度的原则是：每次开辟内存空间都会开辟最长的一个为基本单位，如果不够存放下一个成员变量的时候，就会重新开辟一段内存空间，如果，这一次开辟的够，没有用完，而下一个成员变量也不会超过，那么下一个成员变量就还会存储在这一个内存空间上，不用再开辟新的内存空间。
//结构体还要注意字节对齐
//char（从哪里开始都行）
//int(从4的倍数位置开始)
//double（从8的倍数位置开始）
//无论结构体本身有多少成员变量，结构体本身占4个字节
// **************************************结构体数组****************************************
    typedef struct Stu
    {
        char name[10];
        int score;
        char sex;
    }StuInfo;
    StuInfo St1={"zhangsan",87,'M'},St2={"lisi",66,'W'},St3={"wangwu",44,'M'},
    St4={"zhaoliu",98,'W'},St5={"wangqi",65,'M'};
    //将这五个学生的信息放进数组中,这个时候St[5]这个数组里面存放的数据全是结构体变量，所以该数组就是结构体数组
    StuInfo St[5]={St1,St2,St3,St4,St5};
    int max = St[0].score;
    int index=0;
    for (int i=0; i<5; i++)
    {
        if(max<St[i].score)
        {
            max=St[i].score;
            index=i;
        }
    }
    printf("成绩最高的同学的名字是%s,性别为%c\n",St[index].name,St[index].sex);
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}
