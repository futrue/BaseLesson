//
//  main.c
//  lesson_C_8
//
//  Created by lanou3g on 15/3/31.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    /*
     1.指针的基本概念
     字节：在内存中是最小的储存单元，不同了性的数据在内存中占用的储存单元不同
     地址：为了正确的访问内存单元，每个内存单元的编号称为地址
     数据的访问形式：直接访问（通过变量名的形式方法）
                  间接访问（通过内存地址形式访问）
     指针：本身就是一个地址，可以理解为指向一块内存地址的箭头，给指针赋值的时候只能赋地址
     */
    int a=3;//在内存中定义一个变量，内存空间起名为a，内容为3
    int *p=&a;//定义一个指针，指向了a这一块内存空间，p指向了a这一块内存空间，就可以操作a这块内存空间，int修饰的是这个内存空间存放的数据类型，和p没有关系。而*是修饰p的，说明p是一个指针变量，&是取执符号，&a的意思为取a这一个的内存地址
    printf("a=%d\n",a);
    printf("指针p指向的那块内存空间上的值为%d\n",*p);
    printf("a在内存中的地址为%p\n",&a);
    printf("p指向的内存空间地址为%p\n",p);
    printf("p这个指针变量本身在内存中的地址为%p\n",&p);
   /*
    2.指针换指向
    3,指针和数组
    */
    int array[5]={1,2,3,4,5};//数组名代表首元素地址
    int *point = array;
    //指针p指向了数组a的首元素地址
    //当一个指针指向了一个数组的首元素地址，那么这个指针就叫做数组指针
    //间接访问
    printf("数组的第三个元素的值为%d\n",*(point+2));
    printf("数组的第三个元素的值为%d\n",point[2]);
    printf("数组a在内存中占%lu个字节\n",sizeof(a));
    printf("指针p在内存中占%lu个字节\n",sizeof(p));
//指针在内存中占8个字节，而数组根据长度确定占多少个字节
//指针可以重定向，而数组不可以重定向
    double  *p1=array;
    printf("*p1=%f",*p1);//不要使用一种类型的指针指向另外一种指针的数据
  /*
   4.指针和字符串
   */
//在c语言中使用字符数组表示字符串
//当一个指针指向了一个字符串的时候，这个指针叫做字符指针
    //字符指针p表示这个字符串的首元素地址，但是如果输出的时候，用%s格式化输出符，就是直接输出整个字符串，因为%s格式化输出符，会输出整个字符串，只到遇见'\0'的时候才终止
    
    char str[]="iphone";
    char *poi=str;
    char *poi1="iphone";
    printf("poi的值为%s\n",poi);
    printf("poi1的值为%s\n",poi1);
//间接访问
    printf("str这个字符串的首元素为%c\n",*poi);
//用指针的形式计算字符串的长度
    int i = 0;
    while (*(poi+i)!='\0')
    {
        i++;
    }
    printf("字符串的长度为%d\n",i);
/*
 5.指针数组
 */
//指针数组：实质上是一个数组，只不过这个数组里面存放的是指针
//写法上只需要在原来的数组名前加一个*
    char *str1[]={"IOS","ANDRIOD","WP"};//指针数组（解释不同于二维数组）
    printf("str的首元素的第二个字母为%c\n",str1[0][1]);//
    printf("str的首元素的第二个字母为%c\n",*(str1[0]+1));
    printf("str的首元素的第二个字母为%s\n",str1[0]+1);
//%s输出字符串的时候会向后一直输出，直到遇到'\0'
  
/*
 指针和函数
 */
    int max(int x,int y);//传数值，将实参的传给形参去操作，不会对实参产生影响
    int a1=3,b1=4;
    int result=max(a1, b1);
    printf("result=%d\n",result);
    int (*pointer)(int a,int b);//函数指针
    pointer=max;//将函数的地址赋给指针
    int result1=pointer(a1,b1);
    printf("result1=%d\n",result1);
    //函数指针本质是指针，这个指针指向的是函数的入口，
    //并不是什么样的指针都是函数指针，函数指针要求和被指向的函数格式要一样，包括（返回值类型，参数类型，参数个数）
    //函数指针的（*指针名），要用（）括起来
    void swap(int *p1,int *p2);
    int a2=5,b2=0;
    swap(&a2, &b2);//地址
    printf("a2=%d,b2=%d\n",a2,b2);
   
    return 0;
}
int max(int x,int y)
{
    return x>y?x:y;
}
//指针当做函数的参数（传址，直接对原数据进行操作）
void swap(int *p1,int *p2)
{
    int temp = 0;
    temp =*p2;
    *p2=*p1;
    *p1=temp;
}
