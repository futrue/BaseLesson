//
//  main.c
//  homework_C_11
//
//  Created by lanou3g on 15/4/1.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#include <stdio.h>
#include<math.h>
#include<string.h>
#define PI 3.14//宏定义没有等号，也没有分号
#define PP 5+4 
#define MAX(A,B)  (A*B)  //带参数的宏定义的时候，在宏名字的后面加上一个（），括号里面写参数，然后空格一下写参数的用法
#define SystemVersion 8
#ifdef  SystemVersion

#else

#endif

typedef struct student
{
    int num;
    char name[20];
    char sex;
    float score;
}student;
typedef struct CPoint
{
    float x;
    float y;
}P;
typedef struct xuyuan
{
    
    char sex;
    float score;


}STU;
int main(int argc, const char * argv[]) {
  
//    P m ={0.0,3.0},n={4.0,0.0};
//    double c=sqrt((m.x-n.x)*(m.x-n.x)+(m.y-n.y)*(m.y-n.y));
//    P *point1 ;
//    P *point2 ;//指针定义用地址符
//    printf("两点间的距离为%.2f\n",c);
//    student stu = {1,"lan ou",'m',95.6};
//    student *p = &stu;//结构体的名字不表示地址
//    char *v =(p->name);//正常结构体变量调用成员变量，是（.）语法，而结构体指针采用的时(->)的语法
//    if (*v<='z'&&*v>='a')
//    {
//        *v=*v-32;
//    }
//    unsigned long len = strlen(p->name);
//    for (int i =0; i<len; i++)
//    {
//        if ((p->name)[i]==' ')
//        {
//            (p->name)[i]='_';
//        }
//    }
//    printf("%s",p->name);
    
    
    STU stu1={'m',98.2},stu2={'w',67.5},stu3={'m',78.20},stu4={'w',88.20},stu5={'m',87.20};
    STU stu[20]={stu1,stu2,stu3,stu4,stu5};
    STU *p =stu;
    int i =0;
    while(i<5)
    {
        if ((p+i)->sex=='m')
        {
            if (((p+i)->score)+10<=100)
            {
                ((p+i)->score)=((p+i)->score)+10;
            }
            else
            {
                (p+i)->score=100;
            }
        }
           i++;
    }
    for (int i = 0; i<5; i++)
    {
        printf("%g ",(p+i)->score);
    }
    
    
    
    
    
    
    
    
    return 0;
}
