//
//  main.c
//  lesson_C_4
//
//  Created by lanou3g on 15/3/25.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{
/*
 ********************1.数组*************************************
 数组定义的语法：
 1.数据类型 数组名[长度]={值1,值2,值3...}
 2.数组是存放一组相同类型数据的容器，我们要想使用数组当中的某个数据，可以使用下标的形式进行取值，数组的下标是从0开始
 3.数组不能越界
 4.数组必须要有长度，要么直接指定长度，要么不指定长度就要对数组在定义的时候进行赋值，这个时候对数组赋了几个值，数组的长度就为几
 5.数组名，代表数组首元素的地址
*/
    int array1[5]={4,3,5,2,1};
    printf("第三个数据的值为%d\n",array1[2]);
    
    int a = sizeof(int);
    int b = sizeof(array1);
    printf("%d\n",a);
    printf("%d\n",b);//%lu->unsigned long   %u->unsigned int
    int count = b/a;
    
    //int array2[4]={4,3,5,2,1};
    //printf("第五个数据的值为%d\n",array2[4]);
 /*
 数组的遍历(将数组当中的数据从头到尾循环一遍)
 */
    int array3[count];
    int array4[count];
    //用来当做分离出来得数据在新数组当中的下标
    int m=0;
    int n=0;
    for (int i = 0; i<count;i++ )
    {
        if (array1[i]%2==0)
        {
            array3[m]=array1[i];
            m++;
        }
        else
        {
            array4[n]=array1[i];
            n++;
        }
    }
    printf("array3:");
    for (int i=0;i<m; i++)
    {
        printf("%d ",array3[i]);
    }
    printf("\n");
    printf("array4:");
    for (int i=0;i<n; i++)
    {
         printf("%d ",array4[i]);
    }
    
 //************************冒泡排序**************************
    int array5[5] = {6,3,8,4,5};
    int temp;
    for (int i =0; i<5; i++)//当i等于0的时候，array5[i] = 3
    {
        for (int j = 0; j<5-i-1; j++)
        {
            if (array5[j]>array5[j+1])
            {
                temp=array5[j];
                array5[j]=array5[j+1];
                array5[j+1]=temp;
            }
        }
    }
    for (int i =0; i<5; i++)
    {
        printf("%d ",array5[i]);
    }
    
    int array[10] ={7,9,8,6,5,1,2,4,3,10};
    int temp1;
    for (int i= 0; i<9; i++)
    {
        int m = 0;
        for (int j = 0; j<10-i-1; j++)
        {
            if (array[j]<array[j+1])
            {
                temp1=array[j];
                array[j]=array[j+1];
                array[j+1]=temp1;
                m = 1;//冒泡排序法优化
            }
        }
        if (m == 0 )
            break;
    }
    for (int i =0; i<10; i++)
    {
        printf("%d ",array[i]);
    }
 //************************跳出两层for循环***********************************
 //当i=3，j=2的时候，跳出循环
    for (int i= 0;i<5; i++)
    {
        for (int j=0; j<4; j++)
        {
            printf("i=%d,j=%d",i,j);
            if(i==3&&j==2)
            {
                i=6;//只需要在内存循环的时候改变外层循环的变量
                break;
            }
        }
    }
//************************冒泡排序的优化************************************
    int  array6[5]={3,4,2,1,5},Temp=0;
    for (int i=0; i<4; i++)
    {
        int k=0;
        for (int j =0; j<5-i-1; j++)
        {
            if (array6[j]>array6[j+1])
            {
                Temp = array6[j];
                array6[j]=array6[j+1];
                array6[j+1]=Temp;
                k=1;
            }
        }
        if(k == 0)
            break;
    }
    printf("排序后的数组为");
    for (int i = 0; i<5; i++)
    {
        printf("%d ",array6[i]);
    }
//*********************字符数组****************************************
//基本表达形式（系统不会在末尾加终止符号'\0'）
    char str[10]={'i','p','h','o','n','e','\0','a','b'};//  '\0'表示终止
    for (int i= 0; i<10; i++)
    {
        printf("%c",str[i]);
    }
    printf("\n");
    printf("%s",str);
 //第二种表达形式，用这种形式，系统会自动在后面加一个终止符号'\0'
    char str1[]="iphone";
    printf("str1=%s",str1);
    printf("str1[1] = %c",str1[2]);
 //strlen和sizeof的区别  strlen所求字符串长度不加'\0'
    return 0;
}
