//
//  main.c
//  lesson_C_6
//
//  Created by lanou3g on 15/3/27.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#include <stdio.h>
// #include"maopao.h"

int main(int argc, const char * argv[]) {
/*
   返回值类型 函数名（形参1，形参2，形参3...）
   {
       代码块
       return   需要返回的值
   }
   注意:1.并不是一定要有返回值，当没有返回值的时候，返回值类型就写void
       2.函数不允许嵌套，每个函数都必须是相互独立的，但是可以互相调用
       3.函数名最好要见名知意
       4.当韩素没有返回值的时候，return可以不写
       5.当一个函数需要多个函数的时候，参数之间用逗号隔开，如果没有参数，小括号也必须要写
       6.函数在使用前要先声明,函数的声明就是将返回值类型，函数名，参数列表全部拷贝，并在最后加一个分号，当被调函数写在主调函数的前面的时候，可以不声明，但是为了程序的可读性更高，最好也要声明再使用 
   分类：无返回值，无参数类型；
        无返回值，有参数类型；
        有返回值，无参数类型；
        有返回值，有参数类型。
   参数:
       实参->实际需要参与运算的数据
       形参—>在函数的内部使用的是形参，代替外部真实的数据
 
 变量的作用域：
 局部变量：一个变量定义在一个函数的内部，那么这个变量的作用就在这个函数的内部可以使用，除了函数就不可以使用
 全部变量：定义在函数的外部的变量成为全局变量
 注意：当全局变量和局部变量重名的时候，局部变量会覆盖全局变量
 
 内存：代码区（用来存放代码本身）
      常量区（用来存放程序中的常量例，例如：2，3，4）
      堆（凡是用malloc和alloc开辟的内存空间都是在对立面的，并且堆里面的内存空间需要程序员自己管理，有开辟就必须有释放，不然会内存泄露）
      栈（用来存放临时变量和正在运行的函数，当函数被调用的时候就会入栈，执行完毕的时候就会出栈）
      全局区(静态区：static修饰的变量都在该区)
*/
/* hello()*/
    void hello();
    //函数的声明（其实就是将返回值类型，函数名，参数列表全部拷贝，并在最后加个分号）
    hello();//函数的调用（其实就是函数名加上"参数列表"）
    printf("\n");
/* sum()*/
    int x = 3;
    int y = 4;
    int sum(int a,int b);//函数的声明，依然是形参
    int result = sum(x,y);//函数调用的时候使用实参
    printf("result=%d\n",result);
/* max()*/
    int a[]={2,4,56,73,23,45,6,8};
    int max(int a[],int length);//声明
    int m = max(a,8);//当数组当做参数来使用的时候，只需要写数组名(地址)就行了
    printf("数组中的最大值为：%d\n",m);
/*jiecheng()*/
    int jiecheng(int n);
    int n=jiecheng(5);
    printf("n=%d",n);
/*  MyPrintf()*/
    
    return  0;

}
//常见一个无参数，无返回值的打印函数
void hello()
{
    printf("hello world");
}
// 有返回值，有参数的函数
int sum(int a,int b)//函数定义时，使用的是形参
{
    return a+b;//
}
//求数组的最大值的函数
int max(int a[],int length)
{
    int m=a[0];
    for (int i =0; i<length; i++)
    {
        if (m<a[i])
        {
            m=a[i];
        }
    }
    return m;
}
//冒泡函数
void maopao(int a[],int length)
{
    int max=0;
    int m=0;
    for (int i= 0; i<length; i++)
    {
        for (int j=0; j<length-i-1; j++)
        {
            if (a[j]>a[j+1])
            {
                max=a[j];
                a[j]=a[j+1];
                a[j+1]=max;
                m=1;
            }
        }
        if (m==0) break;
    }
}
//递归函数（如果一个函数自己调用了和自己一样的函数，那么这个函数就是一个递归函数，递归函数必须要有一个出口）
int jiecheng(int n)
{
    if (n==1)
    {
        return 1;
    }
    return n*jiecheng(n-1);

}
//递减函数
int MyPrintf(int n)
{
  printf("%d",n);
    if (n==0)
    {
        exit;
    }
    return MyPrintf(n-1);
    
}











