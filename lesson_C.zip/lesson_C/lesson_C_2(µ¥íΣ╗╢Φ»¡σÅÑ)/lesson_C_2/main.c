//
//  main.c
//  lesson_C_2
//
//  Created by lanou3g on 15/3/23.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#include <stdio.h>
/*
 1.bool
 2.c语言头文件的引入
 3.if语句
   （1）单一条件，要么执行，要么不执行
   （2）两种情况必须执行一种（if——else）
    (3)当需要多个条件都满足的时候用if嵌套
   （4）多种情况执行其中一种（if-else if-else）
 4.三目运算符
 */

#include <stdbool.h>//C语言有很多头文件，但是有些是不经常使用的功能，为了提高编译器的工作效率，把一些不经常使用的头文件没有作为默认被工程导入，这个时候在需要的时候要我们自己添加头文件，添加的头文件有两种形式：1.#include<>,添加系统头文件    2.#include “”，添加自定义头文件
//****************1.Bool*************************************
/*
  1.使用场景：在分支语句或者循环语句中作为判断条件来使用
  2.在使用之前需要添加<stdbool,h>
  3.在C语言中存在着非0即为真
 */

int main(int argc, const char * argv[]) {
    /*
    int num1=0;//num1为假
    int num2=2;
    num1>num2; //当表达式不成立，则该表达式为假
    */
//******************2.if分支语句******************************
   /*
    1.if语句的第一种形式（只有一种情况要么执行，要么不执行）
    if (判断条件)
    {
        当判断条件成立的时候才会执行该{}里面的代码
    }
    2.if语句的第二种形式(适用于二者必选其一)
    if (判断条件)
    {
        当判断条件成立的时候才会执行该{}里面的代码
    }
    else
    {
        当判断条件不成立的时候执行else{}里面的代码
    }
    3.if的嵌套使用（适用于多种判断条件并存的时候）
    if(如果今天不下雨)
    {
          if(如果今天不堵车)
       {
         就坐车来
       }
    else
       {
         就走着来
       }
    }
    else
    {
        就打车来
    }
    4.if-else if-else(多种情况选择一种) (等价情况)
    if（（今天不下雨）&&（今天不堵车））
    {
       就坐车来
    }
    else if（（今天不下雨）&&（堵车））
    {
       就走着来
    }
    else
    {
      打车来
    }
    */
   /*
//求三个数字的最大值
        int a, b , c,max,m1;
    printf("请输入三个数字,用逗号隔开：\n");
    scanf("%d,%d,%d",&a,&b,&c);
    if ((a>=b)&&(a>=c))
    {
        printf("最大的数是%d\n",a);
    }
    else if((b>=a)&&(b>=c))
    {
         printf("最大的数是%d\n",b);
    }
    else
    {
        printf("最大的数是%d\n",c);
    }
    
 //求从控制输入的三个数字的最大值
    if (a>=b)
    {
       if(a>=c)
       {
           printf("最大值是%d\n",a);
       }
       else
       {
           printf("最大值是%d\n",c);
       }
    }
    else if(a<=b)
    {
       if (b>=c)
      {
          printf("最大值是%d\n",b);
      }
       else
       {
         printf("最大值是%d\n",c);
       }
    }
     */

//*************3.(表一)?(表二):(表三)****三目表达式*****************

    /*
    printf("请输入两个数字,用逗号隔开：\n");
    scanf("%d,%d",&a,&b);
    max=(a>=b?a:b);
    printf("输出的最大数是%d",max);
    ®printf("请输入三个数字,用逗号隔开：\n");
    scanf("%d,%d,%d",&a,&b,&c);
    m1=(a>=b?a:b);
    max=(m1>=c?m1:c);
    printf("输出的最大数是%d",max);
    */
//****************4.逻辑运算符**********************************
   //逻辑运算符存在短路情况，就是当表达式已经判断出结果的时候，后面的代码就不会被执行
    /*
    int num6=6;
    int  num7=7;
    if (num6>num7&&num7++)
    {
        printf("num6>num7\n");
    }
    else
    {
        printf("num7>num6");
    }*/
//******************5.switch-case语句*******************************************
    /*
     作用：和if语句一样，也是用作分支判断，只是用法不一样
     switch(表达式)
     {
       case1:要执行的代码
       case2:要执行的代码
       case3:要执行的代码
       。
       。
       。
      default：要执行的代码（以上所有的case都不满足的情况，才会执行default）
     }
     */
    /*
 1.作用：和if语句一样，也是用作分支判断，只是用法不一样
 2.每有一种情况，就需要有一个case,case后面跟switch变量的所有情况
 3.default并不是必须的
 4.switch变量必须是int类型，也可以使用char
 5.当我们不需要多种case是同一种情况的时候，就要在每个case后面加上一个break
 6.case是无序的，因为每一个case都是相互独立的（多种case同种情况除外）
 */
    /*
    printf("********菜单***********\n");
    printf("*      1.取款         *\n");
    printf("*      2.查询         *\n");
    printf("*      3.存款         *\n");
    printf("*      4.退卡         *\n");
    printf("请输入你的选择：\n");
    int num8;
    scanf("%d",&num8);
    switch (num8)//switch里面只能写int（char）类型
    {
        case 1:printf("你当前选择的是取款功能\n");break;
        case 2:printf("你当前选择的是查询功能\n");break;
        case 3:printf("你当前选择的是存款功能\n");break;
        case 4:printf("你当前选择的是退卡功能\n");break;
        default:printf("你输入的是错误的，请重新输入\n");break;
    }

    printf("请输入两个数字：");
    int num9,num10;
    scanf("%d,%d",&num9,&num10);
    //getchar();//消减回车符
    printf("请输入运算符号（+,-,*,/）:\n");
    char s,m;
    scanf("%c%c",&m,&s);//消减回车符
    switch (s)
    {
        case '+':printf("你输入得两个数的和是%d\n",num9+num10);break;
        case '-':printf("你输入得两个数的减是%d\n",num9-num10);break;
        case '*':printf("你输入得两个数的乘是%d\n",num9*num10);break;
        case '/':printf("你输入得两个数的除是%d\n",num9/num10);break;
        default:printf("输入错误");break;
    }
    */
    /*
 **********************6.枚举*******************************************
 1.enum是枚举的关键字
 2.studentName是枚举的变量名字
 3.zhangsan，lisi，wangwu是枚举的成员变量
 4.枚举的结尾要写一个;
 5.枚举值默认是从0开始，但是可以人为改变，如果不做改变，下一个默认是上一个加1，成员变量用逗号隔开
 6.枚举也是一种数据类型和int一样，只不过，int是基本数据类型，而枚举是复杂的数据构造类型
 */

    enum studentName //定义一个枚举
    {
      zhangsan = 3 ,
      lisi         ,
      wangwu   = 5
    };//枚举的结尾要写一个;
    enum studentName sn = 3   ;
    switch(sn)
    {
        case 3:printf("3\n");break;
        case 4:printf("4\n");break;
        case 5:printf("5\n");break;
    }
    
    
    
    
    return 0;//最后
}

enum  DiscountType {
    DiscountTypeOriginal,// 原价
    DiscountTypeNine,    // 九折
    DiscountTypeSeven,   // 七折
};

struct GoodsInfo
{
    int productID;// 商品编码
    float discount;// 折扣 A:1  B:0.9  C:0.7
    float price;// 商品价格
};

float getProductPrice(int productID, float price, float discount)
{
    return price * discount;
}

