//
//  Woman.m
//  lesson_OC_2
//
//  Created by lanou3g on 15/4/8.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Woman.h"

@implementation Woman
- (void)shopping
{
    NSLog(@"今天花了好多钱好开心");
}
- (Child *)makeBaby:(NSString *)name//返回值为Child类型
{
    Child *c = [[Child alloc]initWithName:name];
    //定义一个Child类的对象c 同时对对象c的name赋值
    return  c;
}
@end
