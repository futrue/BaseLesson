//
//  Person.m
//  lesson_OC_2
//
//  Created by lanou3g on 15/4/8.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Person.h"

@implementation Person

- (void)setName:(NSString *)name
{
    _name = name;
}
- (NSString *)name
{
    return  _name;
}

- (void)setAge:(NSInteger)age
{
    if (age<0)
    {
        NSLog(@"你输入的年龄不对");
    }
    else
    {
        _age=age;
    }
}
- (NSInteger)age
{
    return  _age;
}

- (void)setAddress:(NSString *)address
{
    _address = address;
}
- (NSString *)address
{
    return _address;
}

- (id)initWithName:(NSString *)name andAge:(NSInteger)age andAddress:(NSString *)address
{
    if ([super init])
    {
        _name = name;
        _age = age;
        _address = address;
    }
    //是将初始化传递的对象自己返回
    return  self;
}



















@end
