//
//  Man.h
//  lesson_OC_2
//
//  Created by lanou3g on 15/4/8.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Woman.h"
@interface Man : NSObject
{
    NSString *name;
    @public
    Woman *_wife;
}

- (void)makeMoney;

@end
