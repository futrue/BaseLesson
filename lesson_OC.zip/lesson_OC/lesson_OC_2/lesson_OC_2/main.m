//
//  main.m
//  lesson_OC_2
//
//  Created by lanou3g on 15/4/8.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Man.h"
#import "Woman.h"
#import "Child.h"
int main(int argc, const char * argv[]) {
    /*
     1.set方法是对实例变量赋值的方法，不需要返回值，需要参数
     2.get方法是对实例变量取值的方法，但是通常不写get，直接写实例变量名作为方法名，需要返回值，不需要参数
     3.自定义初始方法：
       在一个对象刚开始创造的时候，就对它的一些实例变量赋值，通常以init开头，返回值通常写id
     4.#import #include @class
       #import 和#include都是导入头文件是要使用的，都可以在OC中使用，只不过
       #import导入头文件的时候，编译器只会编译一次，不会造成重复引用的问题，而#include导入头文件的时候，编译器会多次编译，造成重复引用的问题。
     重复引用：例如：a引用了c，b 也引用了c，d又引用了a，b 这个时候c就会在d里面引用两次，如果#import就不会出现该问题
     @class是为了解决交叉引用的问题，交叉引用就是a引用了b，b也引用了a，而#import不能避免交叉引用，这个时候就要使用@class，@class只是声明有这个类，但是用不了这个类里的东西
     */
  /*
    Person *p=[[Person alloc]init];
    [p setName:@"王小贱"];
    NSLog(@"p的名字叫%@",[p name]);
    
    //Person *p1=[[Person alloc]init];
    [p setAge:23];
    NSLog(@"p的年龄为%ld",[p age]);

    
    [p setAddress:@"niubi"];
    NSLog(@"p的住址为%@",[p address]);
    
    
    Person *p1 = [[Person alloc]initWithName:@"王小贱" andAge:23 andAddress:@"清河中街"];
    NSLog(@"name=%@ age=%ld address=%@",[p1 name],[p1 age],[p1 address]);*/
    
    
    //w出生了
    Woman *w = [[Woman alloc]init];
    //m也出生了
    Man *m = [[Man alloc]init];
    m->_wife= w ;//w的类型是Woman
    w->_husband= m;
    [m makeMoney];
    [w shopping];
    
    //Child *c = [[Child alloc]initWithName:@"狗蛋"];
    Child *c1 =[w makeBaby:@"狗蛋"];
    NSLog(@"小孩的名字叫做%@",c1->_name);
    
    [c1 study];
    
    
    
    
    
    return 0;
}
