//
//  Woman.h
//  lesson_OC_2
//
//  Created by lanou3g on 15/4/8.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Child.h"
@class Man;//只能使用Man类型，不能使用Man内容
@interface Woman : NSObject
{
    @public
    NSString *_name;
    Man *_husband;
}
- (void)shopping;
- (Child *)makeBaby:(NSString *)name;

@end
