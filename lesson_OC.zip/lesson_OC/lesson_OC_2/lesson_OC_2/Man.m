//
//  Man.m
//  lesson_OC_2
//
//  Created by lanou3g on 15/4/8.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Man.h"

@implementation Man
- (void)makeMoney
{
    NSLog(@"我要努力挣钱，好给媳妇败家");
}
@end
