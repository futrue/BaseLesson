//
//  Person.h
//  lesson_OC_2
//
//  Created by lanou3g on 15/4/8.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
{
    //实例变量可以写在.m文件里，要以类目的形式
    NSString *_name;
    NSInteger _age;
    NSString *_address;
}
//在OC中，在类的外部直接使用实例变量，是不安全的，可以使用方法的形式对实例变量赋值，这样具体的赋值代码，会写在.m文件中，而.m文件是可以打包，让别人打不开，（看不到源代码怎么写的，所以比较安全，通过方法的形式，还可以加上一些逻辑等等，所以要比直接使用实例变量要好）而且OC中规定对实例变量赋值的方法以set开头

- (void)setName:(NSString *)name;
- (NSString *)name;//OC中对于取值的函数，想取谁的值，直接就以之歌实例变量名作为函数名就行

//对年龄的设置
- (void)setAge:(NSInteger)age;
- (NSInteger)age;

- (void)setAddress:(NSString *)address;
- (NSString *)address;

- (id)initWithName:(NSString *)name andAge:(NSInteger)age
        andAddress:(NSString *)address;









@end
