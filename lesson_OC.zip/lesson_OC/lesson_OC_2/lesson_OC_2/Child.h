//
//  Child.h
//  lesson_OC_2
//
//  Created by lanou3g on 15/4/8.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Child : NSObject
{
    @public
    NSString *_name;
}
//小孩出生了就带名字的方法
- (id)initWithName:(NSString *)name;

- (void)study;

//- (void)childName;
@end
