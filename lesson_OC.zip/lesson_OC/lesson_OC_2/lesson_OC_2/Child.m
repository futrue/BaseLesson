//
//  Child.m
//  lesson_OC_2
//
//  Created by lanou3g on 15/4/8.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Child.h"

@implementation Child


- (id)initWithName:(NSString *)name//只是初始化
{
    if ([super init])
    {
        _name = name;
    }
    return self;
}

- (void)study
{
    NSLog(@"好好学习，天天向上");
}

@end


