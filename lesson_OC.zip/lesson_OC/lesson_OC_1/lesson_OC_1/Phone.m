//
//  Phone.m
//  lesson_OC_1
//
//  Created by lanou3g on 15/4/7.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Phone.h"

@implementation Phone
+ (void)phoneNumber:(int)number
{
    NSLog(@"电话号码为%d",number);
}
- (void)phoneNumber:(int)number
{
    NSLog(@"电话号码为%d",number);
}


@end
