//
//  Phone.h
//  lesson_OC_1
//
//  Created by lanou3g on 15/4/7.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Phone : NSObject
{
    NSString *_phoneName;
    int _number;
}
+ (void)phoneNumber:(int)number;
- (void)phoneNumber:(int)number;

@end
