//
//  Calculate.m
//  lesson_OC_1
//
//  Created by lanou3g on 15/4/7.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Calculate.h"

@implementation Calculate


- (int)sumOfFirstNum:(int)firstNum andSecondNumber:(int)secondNum
{
    return firstNum+secondNum;

}

@end
