//
//  main.m
//  lesson_OC_1
//
//  Created by lanou3g on 15/4/7.
//  Copyright (c) 2015年 HYD. All rights reserved.
//
/*
 1.在OC语言里面导入头文件使用的是#import
 2.<Foundation/Foundation.h>是OC里面默认的一个系统库类，里面包含了基本的输入输出函数，字符串函数，数组的等常用函数，在OC里面几乎所有以NS开头的都在里面。
 */


#import <Foundation/Foundation.h>
#import "Car.h"
#import "Phone.h"
#import "Calculate.h"
int main(int argc, const char * argv[]) {
    
 
    
       //创建对象,c1就是一个Car类的对象
        Car *c1=[[Car alloc]init];
        c1->_name=@"大腿";
        c1->_wheel=2;
        NSLog(@"你好，我叫%@\n我有%d个大腿",c1->_name,c1->_wheel);
    
        //实例变量使用对象去调用
        [c1 Hello];
        //加号方法的使用规则 [方法的调用者 被调用的方法]
        [Car Hi:@"wanger!!"];
   
        [Phone phoneNumber:123];
    
        Phone *c2 =[[Phone alloc]init];
        [c2 phoneNumber:321];
    
        Calculate *c3 =[[Calculate alloc]init];
        int a=[c3 sumOfFirstNum:3 andSecondNumber:3];
        NSLog(@"sum=%d",a);
    
    return 0;
}
