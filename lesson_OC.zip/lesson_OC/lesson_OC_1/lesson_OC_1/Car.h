//
//  Car.h
//  lesson_OC_1
//
//  Created by lanou3g on 15/4/7.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

/*
 OC里面，一个.h文件和一个.m文件在一起组成了一个类 .h文件里面专门负责变量的声明，方法（函数）声明，属性的声明，所以.h文件就是专门放声明的文件 .m用来实现 .h里面声明的一些东西，例如，在.h里面声明了一个方法（函数），如果要实现就写在.m里面
 @implementation：.m实现文件的标志
 @interface是.h文件的标志，后面跟上当前类的类名，具体的代码要写在@interface和@end之间，冒号(:)表示继承关系，冒号后面的是父类。
 */

@interface Car : NSObject//
{
    //写在大括号里面的叫做实例变量，他的作用域都是全局的
    @public //公开的
    NSString *_name;//字符串类型的实例变量
    int _wheel;//凡是基本数据类型的实例变量都不加*号修饰
              //实例变量的定义是为了在类的内部来使用

}
//@public //公开的
//@protected//受保护的，只有自己和自类可以使用（默认）
//@private//私有的，只能在自己类的内部使用
//第二部分讲的是属性部分，属性以@property作为标志
//@property
//第三部分
//- :表示叫做实例方法，该类型的方法，在调用的时候用对象去调用
//+ :表示类方法（静态方法），该类型的方法在调用的时候用类名去调用
/*方法的定义规则：
1.方法类型（返回值类型）方法名->无参数类型
2.方法类型（返回值类型) 方法名1:(参数类型)参数名 方法名2:(参数类型)参数名->有参数类型
 
 
 
 */

- (void)Hello;//无参数类型

- (void)Hello:(NSString *)name andAge:(int)age;
- (void)Hello:(NSString *)name andAge:(int)age andAddress:(NSString *)add;

+ (void)Hi:(NSString *)name;


@end
