//
//  Car.m
//  lesson_OC_1
//
//  Created by lanou3g on 15/4/7.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Car.h"

@implementation Car

- (void)Hello
{
    NSLog(@"hello!!!");
}

//在OC里面对象的格式化输出符用%@（只要不是基本数据类型都是对象类型）
+ (void)Hi:(NSString *)name
{
    NSLog(@"hi，%@",name);
}

@end
