//
//  Calculate.h
//  lesson_OC_1
//
//  Created by lanou3g on 15/4/7.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Calculate : NSObject


- (int)sumOfFirstNum:(int)FirstNum andSecondNumber:(int)secondNum;




@end
