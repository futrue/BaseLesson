//
//  main.m
//  lesson_OC_6
//
//  Created by lanou3g on 15/4/14.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

int sum(int a, int b);
int sum(a,b)
{
    return a+b;
}
int x=1;

//OC中块语法的定义
/*
 1."^":块的标识
 2."block名字":代表一个block的变量
 3.等号前面表示定义了一个块的类型:
 等号后面是给block变量赋值的过程
 返回值类型 (^block的名字) (参数列表) = ^(参数列表){具体的实现功能}
 4.block也叫做匿名函数
 5.block是一个完整的语句需要在后面加一个分号
 
 
 */
int main(int argc, const char * argv[]) {
    @autoreleasepool {
/*
    //1.函数的正常调用
        int result=sum(10,20);
        NSLog(@"result=%d",result);
    //2.函数指针
        int(*p)(int a,int b)=sum;//函数指针就指向了函数
    //函数指针的使用
        int result1=p(20,30);
        NSLog(@"result1=%d",result1);
*/

    
  int (^sumBlock)(int a ,int b) = ^(int a ,int b)
        {
            return a+b;
        };
  //block的使用
        int result2 = sumBlock(30,40);
        NSLog(@"result2=%d",result2);
    
        
        int (^maxValue)(int a[],int length)=^(int a[],int length)
        {
            int max=a[0];
            for (int i =0;i<length; i++)
            {
                if (max<a[i])
                {
                    max=a[i];
                }
            }
            return  max;
        };
    //block的使用
        int  a[5]={1,2,3,4,5};
        int max = maxValue(a,5);
        NSLog(@"max=%d",max);
    
    //将字符串转化为整形
    int (^changeString)(NSString * str)=^(NSString * str)
        {
           return [str intValue];
        };
        int result3 = changeString(@"123");
        NSLog(@"result3=%d",result3);

        
//用typedef 形式来定义一个block变量
        typedef int(^block1)(int a,int b);
    //等价于 block1 就是返回值为int,有两个int类型参数的block类型
    block1 b = ^(int a, int b)
        {
            return a+b;
        };
        NSLog(@"b=%d",b(1,2));
    block1 c =^(int a,int b)
        {
            return  a-b;
        };
    
        NSLog(@"c=%d",c(1,2));
    
        typedef int(^block2)(int a);
        block2 b1 =^(int a)
        {
            int temp =1;
            for (int i=a; i>0; i--)
            {
                temp*=i;
            }
            return temp;
        };
        NSLog(@"result4=%d",b1(5));
//block与全局变量(block和函数一样只有在调用的时候才会进到block里面)
        int (^block3)(int a)=^(int a)
        {
            x++;
            return ++a;
        };
        NSLog(@"x=%d",x);
        int result5 = block3(x);
        NSLog(@"result5=%d",result5);
//block与局部变量
        /*
         1.不加__block的情况下，block在使用局部变量的时候，当程序运行到block定义的时候，不会执行block里面的代码，只有当block被调用的时候才会进到block里面执行具体的代码，但是这个时候，block里面如果用到了局部变量，虽然代码不执行，仍然会在block里面将局部变量的值拷贝进去，而且开辟了一块新的内存空间来存放这个局部变量的值，所以在block声明的后面，调用的前面，去修改局部变量，不会影响局部变量在block里面的值，加上__block就可以解决以上问题。
         */
        __block int y =1;
        y=2;
        int (^block4)(int a)=^(int a)
        {
            //y++;有错误
            NSLog(@"yy=%d",y);
            return ++a;
        };
//        y=3;
//        NSLog(@"yyy=%d",y);
        int result6 = block4(y);
        NSLog(@"result6=%d",result6);
    
    
//*****************************写一个数组排序的block***************************************
   void(^sortArray)(NSMutableArray *mArray)=^(NSMutableArray *mArray)
        {
            for (int i =0; i<mArray.count-1; i++)
            {
                for (int j=0; j<mArray.count-i-1; j++)
                {
                    if ([mArray[j] intValue]>[mArray[j+1] intValue])
                    {
                        //数组交换下标
                        [mArray exchangeObjectAtIndex:j withObjectAtIndex:j+1];
                    }
                }
            }
        };
    
        NSMutableArray *array = [NSMutableArray arrayWithObjects:@"3",@"5",@"2",@"4",@"9",nil];
        sortArray(array);
        NSLog(@"array=%@",array);
    
//block当参数使用
        NSArray *ageArray = [NSArray arrayWithObjects:@"23", @"21",@"25",@"24",@"18",nil];
        ageArray = [ageArray sortedArrayUsingComparator:
        ^NSComparisonResult(id obj1, id obj2)
        {
            if ([obj1 intValue]<[obj2 intValue])
            {
                 return NSOrderedDescending;
            }
            return  nil;
        }];
        NSLog(@"ageArray=%@",ageArray);
        
        
        
        
        
        
        
        
        
        
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    }
    return 0;
}
