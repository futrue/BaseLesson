//
//  Person.h
//  lesson_OC_05
//
//  Created by lanou3g on 15/4/13.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface Person :NSObject
{
    @public
    NSString *_name;
    int _age;
}
- (id)initWithName:(NSString *)name andAge:(int)age;
- (NSComparisonResult)sortByAge:(Person *)p;
@end
