//
//  main.m
//  lesson_OC_05
//
//  Created by lanou3g on 15/4/13.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
int main(int argc, const char * argv[]) {
//******************************不可变字典********************************************
    //创建一个空字典
    NSDictionary *dic1 =[NSDictionary dictionary];
    NSLog(@"dic1=%@",dic1);
    //创建一个键值对
    NSDictionary *dic2=[NSDictionary dictionaryWithObject:@"iPhone" forKey:@"k1"];
    //字典根据键位来取对应的值
    NSString *str =[dic2 objectForKey:@"k1"];
    NSLog(@"str=%@",str);
    //创建一个多键位的字典
    NSArray *keyArray=@[@"k1",@"k2",@"k3",@"k4"];
    NSArray *valueArray=@[@"v1",@"v2",@"v3",@"v4"];
    NSDictionary *dic3=[[NSDictionary alloc]initWithObjects:valueArray forKeys:keyArray];
    NSLog(@"dic3=%@",dic3);
    
    
    //(创建一个多键位的字典)第二种(字典里面的key是唯一的，如果写重复了，只保存第一个)
    NSDictionary *dic4=[NSDictionary dictionaryWithObjectsAndKeys:@"value1",@"key1", @"value2",@"key2",@"value3",@"key3",nil];
    NSLog(@"dic4=%@",dic4);
    //(创建一个多键位的字典)第三种(key在前)
    NSDictionary *dic5=@{@"k":@"v"};
    NSLog(@"dic5=%@",dic5);
    //字典的便利
       //1.便利所有的对象(allValues和allKeys取全部的value和全部的key)
       for (NSString *str in dic3.allValues)
       {
           NSLog(@"str=%@",str);
       }
//******************************可变字典********************************************
    NSMutableDictionary *mDic1 =[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"iPhone",@"k1",@"iPad",@"k2",@"iWatch",@"k3",nil];
    NSLog(@"mDic1=%@",mDic1);
    [mDic1 addEntriesFromDictionary:dic5];
    NSLog(@"mDic1=%@",mDic1);
    //修改原有的键值对
    [mDic1 setValue:@"iMac" forKey:@"k"];
    NSLog(@"mDic1=%@",mDic1);
    //添加一个新的键值对
    [mDic1 setValue:@"Pro" forKey:@"k4"];
    NSLog(@"mDic1=%@",mDic1);
    //删除一个键值对
    [mDic1 removeObjectsForKeys:keyArray];
    NSLog(@"mDic1=%@",mDic1);
    //*************************NSSet(会自动过滤掉重复数据)*****************************
    NSSet *set1=[[NSSet alloc]initWithObjects:@"iPhone",@"iPad",@"iWatch",@"apple", nil];
    NSSet *set2=[[NSSet alloc]initWithObjects:@"iMac",@"iBook",@"Pro",@"Air",@"apple", nil];
    NSLog(@"set1=%@",set1);
    //判断一个容器里面是否包含某个对象
    if ([set1 containsObject:@"iPad"])
    {
        NSLog(@"YES");
    }
    else
    {
        NSLog(@"NO");
    }
    //判断两个集合是否有交集
    if ([set1 intersectsSet:set2])
    {
        NSLog(@"有交集");
    }
    else
    {
        NSLog(@"没有交集");
    }
    //判断两个集合的内容是否相等
    if ([set1 isEqualToSet:set2])
    {
        NSLog(@"内容一样");
    }
    else
    {
        NSLog(@"内容不一样");
    }
    //判断一个集合是否为另外一个集合的子集
    if ([set1 isSubsetOfSet:set2])
    {
        NSLog(@"是子集");
    }
    else
    {
        NSLog(@"不是子集");
    }
//******************************可变集合********************************************
    //用一个集合初始化另一个集合
    NSMutableSet *mSet1 = [NSMutableSet setWithSet:set1];
    NSLog(@"mSet1=%@",mSet1);
    NSMutableSet *mSet2 = [NSMutableSet setWithSet:set2];
    NSLog(@"mSet2=%@",mSet2);
    
    //求交集
//    [mSet1 intersectSet:mSet2];
//    NSLog(@"mSet1=%@",mSet1);
    //求并集
//    [mSet1 unionSet:mSet2];
//    NSLog(@"mSet2=%@",mSet2);
    //从自身减去和mSet1的交集
    [mSet1 minusSet:set2];
    NSLog(@"mSet1=%@",mSet2);
//*****************************用来统计重复次数(NSCountedSet)*******************************
    NSCountedSet *cSet=[NSCountedSet setWithObjects:@"1",@"2",@"1",@"2",@"3",@"1",@"3",@"2", nil];
    NSLog(@"cSet中1的个数有%ld次",[cSet countForObject:@"1"]);
    NSLog(@"cSet=%@",cSet);
    
//数组排序(因为数组里面的元素自能使用他的值，不能对其修改，可变数组依然如此)
    NSMutableArray *array=[NSMutableArray arrayWithObjects:
                    [NSNumber numberWithInt:3],
                    [NSNumber numberWithInt:2],
                    [NSNumber numberWithInt:1],
                    [NSNumber numberWithInt:4],
                    [NSNumber numberWithInt:5], nil] ;

    //控制冒泡排序一共几次循环
//    for (int i =0; i<[array count]-1;i++)
//    {
//        for (int j =0; j<[array count]-i-1; j++)
//        {
//            if ([[array objectAtIndex:j] intValue]>[[array objectAtIndex:j+1] intValue])
//            {
//                int temp = 0;
//                temp = [[array objectAtIndex:j] intValue];
//                [[array objectAtIndex:j] intValue]=[[array objectAtIndex:j+1] intValue];
//                [[array objectAtIndex:j+1] intValue]=temp;
//            }
//        }
//    }
    
   //创建五个Person对象
    Person *p1 = [[Person alloc]initWithName:@"张三" andAge:13];
    Person *p2 = [[Person alloc]initWithName:@"李三" andAge:23];
    Person *p3 = [[Person alloc]initWithName:@"王三" andAge:33];
    Person *p4 = [[Person alloc]initWithName:@"赵三" andAge:43];
    Person *p5 = [[Person alloc]initWithName:@"刘三" andAge:53];
    
    NSMutableArray * personArray=[NSMutableArray arrayWithObjects:p1,p2,p3,p4,p5, nil];
    
    //sortUsingSelector(可变数组的排序)
    //sortedArrayUsingSelector(不可变数组的排序)
    //对于SEL类型的参数填写方式@selector(你想调用方法的名字)
    [personArray sortUsingSelector:@selector(sortByAge:)];
    
    for (Person *p in personArray)
    {
        NSLog(@"age=%d",p->_age);
    }
 
    
    return 0;
}
