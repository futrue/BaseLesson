//
//  Person.m
//  lesson_OC_05
//
//  Created by lanou3g on 15/4/13.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Person.h"

@implementation Person
- (id)initWithName:(NSString *)name andAge:(int)age
{
    if ([super init])
    {
        _name=name;
        _age=age;
    }
    return self;
}
- (NSComparisonResult)sortByAge:(Person *)p
{
//    if ((self ->_age)<(p->_age))
//    {
//        return NSOrderedAscending;
//    }
//    else if ((self->_age)==(p->_age))
//    {
//        return  NSOrderedSame;
//    }
//    else
//    {
//        return  NSOrderedDescending;
//    }
    return self->_age>p->_age;
}
@end










