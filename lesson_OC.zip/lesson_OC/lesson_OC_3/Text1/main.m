//
//  main.m
//  Text1
//
//  Created by lanou3g on 15/4/9.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
int main(int argc, const char * argv[]) {
   
    
    Person * p =[[Person alloc]init];
    p->_name = @"张三";
    p->_age = 25;
    NSLog(@"%@今年%ld岁",p->_name,p->_age);
    
    
    //set和get方法
    Person * p1 = [[Person alloc]init];
    [p1 setName:@"李四"];
    NSLog(@"%@的名字改为%@",p->_name,[p1 name]);
    /*
     set和get方法，封装了实例变量的赋值和取值，这样实例变量就没有直接暴露，比较安全，而且还可以在set和get方法里面加上我们逻辑判断，功能比较强大，弊端就是，一个实例变量就要对应一个set和一个get方法，比较麻烦
     */
    
    //属性通过(.)去赋值，也是通过(.)取值,自动生成set和get方法，还能帮我们生成同名的实例变量
    p1.address=@"北京";
    NSLog(@"%@在%@",p1->_name,p1.address);
    
    [p1 setAddress:@"北京"];
    NSLog(@"%@现在在%@",p->_name,[p1 address]);
    
    //自定义初始化方法（因为有些实力变量会在刚创建的时候需要有值，而不是默认的，所以我们要在初始化的时候，就对他的实例变量赋值）
    
    Person *p2 = [[Person alloc]initWithName:@"王五" andAge:23 andAddress:@"上海"];
    NSLog(@"%@今年%ld岁现在住在%@",p2->_name,[p2 age],p2.address);
    
    /*
     便利构造器：使用起来简单，写起来麻烦，因为要先写一个（-）号方法
     便利构造器在做内存管理的时候更简单，因为不需要我们管理，因为方法的内部封装了alloc开辟内存空间，一个完整地便利构造器也会封装好相应的释放空间，所以使用起来更方便
     */
    Person *p3 =[Person personWithName:@"张三" andAge:12 andAddress:@"铁岭"];
    NSLog(@"%@今年%ld岁现在住在%@",p3->_name,[p3 age],p3.address);
    
    
    
    
    
    
    return 0;
}
