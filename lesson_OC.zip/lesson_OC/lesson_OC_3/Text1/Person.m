
//
//  Person.m
//  lesson_OC_3
//
//  Created by lanou3g on 15/4/9.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Person.h"

@implementation Person
- (void)setName:(NSString *)name
{

    _name =name;
}
- (NSString *)name
{
    return _name;
}
- (void)setAge:(NSInteger)age
{
    _age=age;
    
}
- (NSInteger)age
{
    return _age;
}
- (id)initWithName:(NSString *)name andAge:(int)age andAddress:(NSString *)address
{
    if([super init])
    {
        _name=name;
        _age=age;
        //属性生成相应的实例变量
        _address=address;
    }
    return self;
}

+ (id)personWithName:(NSString *)name andAge:(NSInteger)age andAddress:(NSString *)address
{
    Person *p =[[Person alloc]initWithName:name andAge:age andAddress:address];
    return p;

}















@end
