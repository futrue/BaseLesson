//
//  main.m
//  lesson_OC_3
//
//  Created by lanou3g on 15/4/9.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Man.h"
#import "Woman.h"
#import "Baby.h"
#import "Cab.h"
#import "Person.h"
int main(int argc, const char * argv[]) {
   
    
    //男主角出生了
    Man *m=[[Man alloc]initWithName:@"杰克" andAge:25];
    //女猪脚也出生了
    Woman *w=[[Woman alloc]initWithName:@"肉丝" andAge:23];
    //结婚
    [Cab man:m andWoman:w];
    //又过了一段时间，肉丝怀孕了，小杰克出生了
    Baby *b = [w makeBaby:@"小杰克"];
    NSLog(@"%@快乐的成长",b->_name);
    
    //用便利构造器的形式去创建
    Person *p =[Person personWithName:@"小肉丝" andAge:6];
    NSLog(@"%@今年%d岁，刚上小学",p->_name,p->_age);
    
    
    
    
    
    
    return 0;
}
