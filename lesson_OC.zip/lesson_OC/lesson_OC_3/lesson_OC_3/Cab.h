//
//  Cab.h
//  lesson_OC_3
//
//  Created by lanou3g on 15/4/9.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Man.h"
#import "Woman.h"

@interface Cab : NSObject
+ (void)man:(Man *)aMan andWoman:(Woman *)aWoman;
@end
