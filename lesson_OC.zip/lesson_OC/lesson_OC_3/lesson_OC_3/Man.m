//
//  Man.m
//  lesson_OC_3
//
//  Created by lanou3g on 15/4/9.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Man.h"

@implementation Man
/*
- (id)initWithName:(NSString *)name andAge:(int)age
{
    if ([super init])
    {
        _name = name;
        _age = age;
    }
    return self;
}
*/ 
-(void)makeMoney
{
    NSLog(@"我的职责就是赚钱");
}
@end
