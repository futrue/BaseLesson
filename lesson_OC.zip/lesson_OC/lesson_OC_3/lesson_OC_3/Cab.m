//
//  Cab.m
//  lesson_OC_3
//
//  Created by lanou3g on 15/4/9.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Cab.h"

@implementation Cab

+ (void)man:(Man *)aMan andWoman:(Woman *)aWoman
{
    if((aMan->_age)>=22&&(aWoman->_age)>=20)
    {
        NSLog(@"从此%@和%@成为合法夫妻",aMan->_name,aWoman->_name);
    }
    else if ((aMan->_age)<22)
    {
        NSLog(@"%@年龄太小，再过两年",aMan->_name);
    }
    else
    {
        NSLog(@"%@年龄太小，再过两年",aWoman->_name);
    }
}
@end
