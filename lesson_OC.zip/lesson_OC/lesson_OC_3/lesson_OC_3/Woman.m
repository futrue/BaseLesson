
//
//  Woman.m
//  lesson_OC_3
//
//  Created by lanou3g on 15/4/9.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Woman.h"

@implementation Woman
/*
-(id)initWithName:(NSString *)name andAge:(int)age

{
    if ([super init])
    {
        _name =name;
        _age =age;
    }
    return self;

}
*/
- (Baby *)makeBaby:(NSString *)name;
{
    if ((self->_age)>20)//在类的内部使用self代表这个类
    {
        Baby *b = [[Baby alloc]initWithName:name andAge:0];
        return  b;
    }
    else
    {
        NSLog(@"未婚先孕");
        return nil;
    }
}

@end
