//
//  main.m
//  lesson_OC_7
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Interval.h"
int main(int argc, const char * argv[]) {
    //创建一个时间对象
    NSDate * date1=[NSDate date];
    NSLog(@"date1=%@",date1);
    //获得当前时区的方法
    NSDate *nowDate = [NSDate dateWithTimeIntervalSinceNow:8*60*60];//以秒为单位
    NSLog(@"nowDate=%@",nowDate);
    
    //创建一个明天的时间
    NSDate * yesterday =[NSDate dateWithTimeIntervalSinceNow:-16*60*60];
    NSLog(@"yesterday=%@",yesterday);
    //求昨天和今天这个时间的间隔
    NSTimeInterval time = [yesterday timeIntervalSinceDate:nowDate];
    NSLog(@"time=%d",(int)(time/3600));
    //计算一个时间到当前时间的间隔
    //1.当时间间隔小于1分钟，打印“刚刚聊天记录”
    //2.当时间间隔大于一分钟小于一个小时，打印“这是%d分钟前的聊天记录”
    //3.当间隔大于1个小时，小于24小时，打印“这是%d小时前的聊天记录”
    //4.当大于24个小时的时候，打印“这是%d天前的聊天记录”
    NSDate *date = [NSDate dateWithTimeIntervalSinceNow:48*60*60];
    [Interval interval:date];

    //创建格式化时间
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    //用这个时间格式化对象创建一个时间格式
    [dateFormatter setDateFormat:@"yyyy年MM月dd日HH时mm分ss秒"];//必须用y,M,d,H,m,s
    //用该方法获得的时间就是当前时区的时间
    NSString *timeStr = [dateFormatter stringFromDate:[NSDate date]];
    NSLog(@"timeStr=%@",timeStr);
    
    
    
    
    
    return 0;
}
