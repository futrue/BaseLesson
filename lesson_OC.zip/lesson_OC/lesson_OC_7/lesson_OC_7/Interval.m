//
//  Interval.m
//  lesson_OC_7
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Interval.h"

@implementation Interval
+ (void)interval:(NSDate *)date
{
    NSDate * nowDate = [NSDate dateWithTimeIntervalSinceNow:8*60*60];
    NSTimeInterval time = [date timeIntervalSinceDate:nowDate];
    if (time<60)
    {
        NSLog(@"刚刚来聊天记录");
    }
    else if (time>=60&&time<3600)
    {
        NSLog(@"这是%d分钟前的聊天记录",(int)(time/60));
    }
    else if (time>=3600&&time<(3600*24))
    {
        NSLog(@"这是%d小时前的聊天记录",(int)(time/3600));
    }
    else if (time>=(3600*24))
    {
    NSLog(@"这是%d天前的聊天记录",(int)(time/3600/24));
    }
}
@end
