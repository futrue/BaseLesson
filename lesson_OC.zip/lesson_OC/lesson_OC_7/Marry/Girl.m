//
//  Girl.m
//  lesson_OC_7
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Girl.h"

@implementation Girl
- (void)shopping
{
    NSLog(@"有钱花就是开心");
}
@end
