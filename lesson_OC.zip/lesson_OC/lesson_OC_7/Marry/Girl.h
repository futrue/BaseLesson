//
//  Girl.h
//  lesson_OC_7
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "marryProtocol.h"
@interface Girl : NSObject
{
    @public
    id <marryProtocol> _delegate;
}
- (void)shopping;
@end
      