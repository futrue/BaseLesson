//
//  main.m
//  Marry
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "marryProtocol.h"
#import "Girl.h"
#import "Boy.h"
int main(int argc, const char * argv[]) {
    
    
    Girl *g = [[Girl alloc]init];
    Boy *b = [[Boy alloc]init];
    g->_delegate = b;
    [b makeMoney];
    [g shopping];
    
    
    
    
    
    
    
    return 0;
}
