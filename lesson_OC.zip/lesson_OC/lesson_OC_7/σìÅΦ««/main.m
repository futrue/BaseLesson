//
//  main.m
//  协议
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "HouseDelegate.h"
/*
 一、委托设计模式：委托方，代理方，协议
 委托方：想要做，但是不去真正在实现
 代理方：真正去实现方法的类，谁去做谁就是代理
 协议：定义了委托方想要实现的方法，在这里声明的方法要在代理类里面实现
 二、其中有三个地方需要遵守协议
 1.委托方的类
 2.代理类也要遵守协议
 3.委托方的一个属性或实例变量
 三、协议的实现步骤
 1.先声明一个协议
 2.遵守协议
 3.设置代理
 4.实现协议方法
 */


int main(int argc, const char * argv[]) {
    //这个人需要找房子
    Person * p = [[Person alloc]init];
    //这个人是专业的房屋中介
    HouseDelegate *hd =[[HouseDelegate alloc]init];
    //hd这个专业中介就去帮p找房子
    p->_delegate = hd;
    //p的代理去找房子
    [hd findHouse];
    return 0;
}
