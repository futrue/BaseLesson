//
//  HouseDelegate.m
//  lesson_OC_7
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "HouseDelegate.h"

@implementation HouseDelegate
-(void)findHouse
{
    NSLog(@"找了两天终于找到了");
}
@end
