//
//  Protocol.h
//  lesson_OC_7
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HouseProtocol.h"
@interface Person : NSObject
{
    //代理是一个实例变量，只不过这个实例变量要遵守协议才行，而且代理要为id类型
    //<>表示遵守协议
    @public
    id <HouseProtocol>_delegate;
}
@end
