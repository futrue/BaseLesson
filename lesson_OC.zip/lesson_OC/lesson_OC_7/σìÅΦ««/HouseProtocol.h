//
//  HouseProtocol.h
//  lesson_OC_7
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
//协议@protocol的关键字
//协议分为可选协议@optional和必须执行的协议@required(默认)
//协议只是一个.h文件，用来声明代理需要做的事情

@protocol HouseProtocol <NSObject>

- (void)findHouse;

@end
