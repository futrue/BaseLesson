//
//  NSString+sayHello.h
//  lesson_OC_7
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
/*
 1.类目的类名后面不在是:父类，而是类目的介绍
 2.类目名：NSString+sayHello
 3.在类目里面写的方法就相当于在原始类本身里面去写
 4.可以被子类继承
 5.类目不能写实例变量
 6.类目里面语法上可以定义属性
 */
@interface NSString (sayHello)
//{
//    NSString * _name;
//}
@property NSString *name;
+ (void)sayHi;


//set get 方法
//- (void)setName:(NSString *)name;
//- (NSString *)name;






@end
