//
//  main.m
//  Category
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSString+sayHello.h"
#import "Mystring.h"
#import "Person.h"
#import "Person_sayHi.h"
/*
    延展：主要是给类添加私有方法，实例变量，属性
*/

//(创建一个student类)要把不用模板创建的类，类目，延展放在main函数的前面
@interface  Student : NSObject
-(void)niHao;
@end

@implementation Student
-(void)niHao
{
    NSLog(@"嗨，你好！");
}
@end

int main(int argc, const char * argv[]) {
    [NSString sayHi];
//类目里面添加的方法可以被子类继承
    [Mystring sayHi];
    
//    NSString * str = [[NSString alloc]initWithName:@"zhangsan"];
//    NSLog(@"%@",str.name);
    
    
    
    Person *p =[[Person alloc]init];
    [p sayHi];
    
    Student * s = [[Student alloc]init];
    [s niHao];

  
    return 0;
}

