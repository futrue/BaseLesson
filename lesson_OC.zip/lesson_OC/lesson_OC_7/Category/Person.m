//
//  Person.m
//  lesson_OC_7
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//




#import "Person.h"

@implementation Person
- (void)sayHi
{
    NSLog(@"嗨，你好！");
}
@end
@implementation Person (sleep)

- (void)sleep
{
    NSLog(@"sleep");
}
@end