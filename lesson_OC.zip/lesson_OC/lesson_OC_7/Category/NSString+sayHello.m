//
//  NSString+sayHello.m
//  lesson_OC_7
//
//  Created by lanou3g on 15/4/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "NSString+sayHello.h"

@implementation NSString (sayHello)
+ (void)sayHi
{
    NSLog(@"嗨，你好！");
}
//set get 方法
//- (void)setName:(NSString *)name
//{
//    self.name=name;
//}
//- (NSString *)name
//{
//    return name;
//}











@end
