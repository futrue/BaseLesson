//
//  Student.m
//  lesson_OC_8
//
//  Created by lanou3g on 15/4/16.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Student.h"

@implementation Student
- (id)initWithName:(NSString *)name andAge:(int)age
{
    if ([super init])
    {
        //以实例变量的形式
        // _name=name;
        //以KVC的形式
        [self setValue:name forKey:@"_name"];
        //KVC必须要求是对象类型，所以int类型需要用NSNumber转换为对象
        //value:后面是实例变量的值
        //key:就是实例变量
        [self setValue:[NSNumber numberWithInt:age] forKey:@"_age"];
    }
    return self;
}
//用该方法打印出错误的具体信息
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"key写错了%@",key);
}
@end
