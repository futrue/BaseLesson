//
//  Student.h
//  lesson_OC_8
//
//  Created by lanou3g on 15/4/16.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Computer.h"
@interface Student : NSObject
{
    NSString *_name;
    int _age;
    Computer *_pc;
}
-(id)initWithName:(NSString *)name andAge:(int)age;
@end
