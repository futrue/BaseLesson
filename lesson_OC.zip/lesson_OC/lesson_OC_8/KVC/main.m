//
//  main.m
//  KVC
//
//  Created by lanou3g on 15/4/16.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"
int main(int argc, const char * argv[]) {
   /*
    KVC:键值编码，是OC 2.0以前的语法，现在仍然使用，是一种间接访问实例变量的方式，KVC也是给实例变量取值，赋值的方式。
  */
    //***********************************对实例变量间接访问***********************************
    Student *s = [[Student alloc]initWithName:@"张三" andAge:23];
    //以KVC的形式来使用实例变量的值
    NSLog(@"%@-%d",[s valueForKey:@"_name"],[[s valueForKey:@"_age"] intValue]);
   //通过路径来访问
    
    Computer *c=[[Computer alloc]init];
    [c setValue:@"MacMini" forKey:@"_name"];
    //s买了一台电脑
    [s setValue:c forKey:@"_pc"];
    //获取电脑的名字
    //1.用电脑对象去获得电脑的名字
    NSLog(@"电脑的名字是%@",[c valueForKey:@"_name"]);
    //2.用学生对象去获得电脑的名字
    NSLog(@"电脑的名字是%@",[[s valueForKey:@"_pc"]valueForKey:@"_name"]);
    //直接写法
    NSLog(@"name=%@",[s valueForKeyPath:@"_pc._name"]);
    //**********************************对实例变量的一次性赋值*********************************
    Student *s2=[[Student alloc]init];
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"李四",@"_name",@"16",@"_age",c,@"_pc", nil];//c是对象不需要 @""
    [s2 setValuesForKeysWithDictionary:dic];
    NSLog(@"%@-%@-%@",[s2 valueForKey:@"_name"],[s2 valueForKey:@"_age"],[s2 valueForKeyPath:@"_pc._name"]);
    return 0;
}
