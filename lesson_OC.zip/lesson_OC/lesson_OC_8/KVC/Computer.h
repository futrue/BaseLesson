//
//  Computer.h
//  lesson_OC_8
//
//  Created by lanou3g on 15/4/16.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Computer : NSObject
{
    NSString *_name;
    
}
@end
