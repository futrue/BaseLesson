//
//  Teacher.m
//  lesson_OC_8
//
//  Created by lanou3g on 15/4/16.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Teacher.h"

@implementation Teacher
- (id)initWithName:(NSString *)name andAge :(NSInteger)age andSex:(NSString *)sex andNum:(NSInteger)num
{
    if ([super init])
    {
        //类的内部安全
        _name =name;
        _age=age;
        _num =num;
        _sex =sex;
    }
    return  self;
}
+ (id)teacherWithName:(NSString *)name andAge:(NSInteger)age andSex:(NSString *)sex andNum:(NSInteger)num
{
    Teacher *teacher = [[Teacher  alloc] initWithName:name
                                         andAge:age andSex:sex andNum:num];
    return teacher;
}




@end
