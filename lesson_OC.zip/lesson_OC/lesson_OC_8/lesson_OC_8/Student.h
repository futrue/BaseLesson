//
//  Student.h
//  lesson_OC_8
//
//  Created by lanou3g on 15/4/16.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject
@property (retain ,nonatomic)NSString *name;
@property (retain ,nonatomic)NSString *address;
@property (assign ,nonatomic)int age;
- (id)initWithName:(NSString *)name andAddress:(NSString *)address andAge:(int) age;
+ (id)studentWithName:(NSString *)name andAddress:(NSString *)address andAge:(int) age;




@end
