//
//  main.m
//  lesson_OC_8
//
//  Created by lanou3g on 15/4/16.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Student.h"
#import "Teacher.h"
int main(int argc, const char * argv[]) {
    Student *s = [Student studentWithName:@"张三" andAddress:@"北京" andAge:23];
    NSLog(@"%@-%@-%d",s.name,s.address,s.age);
    Student *s1 = [[Student alloc]init];
    //通过属性的点语法赋值
    s1.name=@"李四";
    s1.age=@"21";
    s1.address=@"北京";
    NSLog(@"%@_%@_%d",s1.name,s1.address,s1.age);
    
    return 0;
}
