//
//  Student.m
//  lesson_OC_8
//
//  Created by lanou3g on 15/4/16.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Student.h"

@implementation Student
-(id)initWithName:(NSString *)name andAddress:(NSString *)address andAge:(int)age
{
    if ([super init])
    {
        _name=name;
        _age=age;
        _address=address;
    }
    return  self;
}

+(id)studentWithName:(NSString *)name andAddress:(NSString *)address andAge:(int)age
{
    Student *student=[[Student alloc]initWithName:name andAddress:address andAge:age];
    return student;
}
//系统生成的assign的set方法
- (void)setAge:(int)age
{
    _age=age;
}
//系统生成的retain的set方法
- (void)setName:(NSString *)name
{
    //如果实例变量的值和参数不一样
    if (_name!=name)
    {
        //如果不一就把原来的实例变量的值给删除
        [_name release];
        //把参数retain一下再赋值
        _name =[name retain];
        //如果是copy修饰的属性
        //_name=[name copy];
    }
}
@end
