//
//  Teacher.h
//  lesson_OC_8
//
//  Created by lanou3g on 15/4/16.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Teacher : NSObject
{
    NSString * _name;
    NSInteger _age;
    NSInteger _num;
    NSString *_sex;
}
@property NSInteger num;
@property NSString *sex;
//属性会自动生成一些set和get方法，但是没有一些逻辑判断等复杂条件，如果我们需要在使用属性的时候做的更多，可以重新写系统的set和get方法

-(id)initWithName:(NSString *)name andAge:(NSInteger)age andSex:(NSString *)sex andNum:(NSInteger)num;
+ (id)teacherWithName:(NSString *)name andAge:(NSInteger)age
               andSex:(NSString *)sex andNum:(NSInteger)num;


@end
