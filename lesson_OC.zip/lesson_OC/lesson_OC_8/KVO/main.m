//
//  main.m
//  KVO
//
//  Created by lanou3g on 15/4/16.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Hero.h"
#import "Doctor.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Hero *h= [[Hero alloc]initWithName:@"sf" andHp:500];
        Doctor *d=[[Doctor alloc]init];
        /*
         1.注册观察者（被观察人主动注册）
         2.Observer:观察者
         3.KeyPath:观察哪一个属性
         4.options:观察新值还是旧值
         5.context:附加信息
        */
        [h addObserver:d forKeyPath:@"_hp"
               options:
               NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld
               context:@"help"];
        
        //模拟掉血过程
        int a=500;
        for(int i =0;i<5;i++)
        {
            a-=100;
            [h setValue:[NSNumber numberWithInt:a] forKey:@"_hp"];
            sleep(2);//让主线程休眠的函数
            NSLog(@"%@",[h valueForKey:@"_hp"]);
        }
        //移除观察者
        [h removeObserver:d forKeyPath:@"_hp"];
        
        /*
         1.（谁）添加观察者
         2.（谁）实现观察方法
         3.（谁）移除观察者
         KVO,即：Key-Value Observing，它提供一种机制，当指定的对象的属性被修改后，则对象就会接受到通知。简单的说就是每次指定的被观察的对象的属性被修改后，KVO就会自动通知相应的观察者了。
         KVO这种编码方式使用起来很简单，很适用与datamodel修改后，引发的UIVIew的变化这种情况，就像上边的例子那样，当更改属性的值后，监听对象会立即得到通知。
         */
        
        
        
        
        
        
        
        
        
        
    }
    return 0;
}
