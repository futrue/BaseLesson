//
//  Doctor.m
//  lesson_OC_8
//
//  Created by lanou3g on 15/4/16.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Doctor.h"
#import "Hero.h"
@implementation Doctor
//观察者发现被观察者已经开始发生改变了，就会自动执行这个方法
- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    NSLog(@"keyPath:%@,object:%@,change:%@,context:%@",keyPath,object,change,context);
    //模拟加血过程
    Hero *h =(Hero *)object;//将一个id类型的转化为具体的类型
    if ([[h valueForKey:@"_hp"] intValue]==100)
    {
        //加血
        [h setValue:[NSNumber numberWithInt:500] forKey:@"_hp"];
        NSLog(@"加血成功");
    }
}
@end
