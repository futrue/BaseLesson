//
//  Hero.m
//  lesson_OC_8
//
//  Created by lanou3g on 15/4/16.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Hero.h"

@implementation Hero
- (id)initWithName:(NSString *)name andHp:(int)hp
{
    if ([super init])
    {
        [self setValue:name forKey:@"_name"];
        [self setValue:[NSNumber numberWithInt:hp] forKey:@"_hp"];
        
    }
    return  self;
}

@end
