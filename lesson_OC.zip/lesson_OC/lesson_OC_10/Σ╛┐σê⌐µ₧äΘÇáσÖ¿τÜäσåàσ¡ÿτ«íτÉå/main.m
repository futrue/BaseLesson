//
//  main.m
//  便利构造器的内存管理
//
//  Created by lanou3g on 15/4/20.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import"Person.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
       //因为这里我们使用了alloc开辟内存空间
        Person *p=[[Person alloc]initWithName:@"张三"];
        //所以我们要有一个release与之对应
        [p release];
        //看到了alloc我们才会做内存管理，没有看见就不需要我们管理
        Person *p1 = [Person personWithName:@"李四"];
    }
    return 0;
}
