//
//  Person.m
//  lesson_OC_10
//
//  Created by lanou3g on 15/4/20.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Person.h"

@implementation Person
- (id)initWithName:(NSString *)name
{
    if ([super init])
    {
        self.name;
    }
    return self;
}
+(id)personWithName:(NSString *)name
{
    Person *p=[[Person alloc]initWithName:name];
    //1.因为p这个对象调用了alloc方法，所以要做内存管理
    //2.如果在return之前释放p，外面就接受不到这个对象，所以不能在return前释放
    //3.如果写在return后面，那么程序在执行到return的时候就会返回，return后面的就不会被执行，所以相当于没写
    //4.要对便利构造器类型的对象采用autorelease
    return [p autorelease];
}
-(void)dealloc
{
    self.name=nil;
    [super dealloc];
}
@end
