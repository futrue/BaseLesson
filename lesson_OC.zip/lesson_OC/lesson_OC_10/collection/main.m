//
//  main.m
//  collection
//
//  Created by lanou3g on 15/4/20.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        //p:引用计数为1
        Person *p = [[Person alloc]init];
        NSLog(@"p:%lu",[p retainCount]);
        //将p添加到数组里面
        //将一个对象添加到容器里面，那么这个容器就拥有了这个对象的所有权
        NSMutableArray *array = [[NSMutableArray alloc]initWithObjects:p, nil];
        NSLog(@"p:%lu", [p retainCount]);
        NSLog(@"p=%p，array=%p",p ,[array objectAtIndex:0]);
        //对象释放了，不会影响我们在数组继续使用这个对象
        [p release];
        //当一个容器移除了某个对象，不仅仅只移除内容，还会把所有权一起移除
        [array removeObject:p];
        //当一个容器被释放的时候，也会一起释放容器里面对象的所有权
        [array release];
        NSLog(@"p:%lu",[p retainCount]);
    }
    return 0;
}
