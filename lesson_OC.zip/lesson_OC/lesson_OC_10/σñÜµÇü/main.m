//
//  main.m
//  多态
//
//  Created by lanou3g on 15/4/20.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Baby1.h"
#import "Baby2.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        Baby1 *b1 = [[Baby1 alloc]init];
        //当重写父类方法的时候，会优先调用子类里面重写的方法
        [b1 sleep];
        
        Baby2 *b2 = [[Baby2 alloc]init];
        [b2 sleep];
        //多态：父类指针指向子类对象
        Person *p = [[Baby1 alloc]init];
        NSLog(@"p的类型为%@",[p class]);
        [p sleep];
        Baby1 *b11=[[Person alloc]init];
        [b11 sleep];
        //当子类指针指向父类对象的时候，因为子类里面的方法比较丰富，如果这个子类指针调用了一个子类里面有，父类里面没有的方法就会崩溃，所以这种写法不推荐，也不是OC里面的正常语法
        //[b11 walk];
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    return 0;
}
