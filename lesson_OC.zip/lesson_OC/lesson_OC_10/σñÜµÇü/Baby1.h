//
//  Baby1.h
//  lesson_OC_10
//
//  Created by lanou3g on 15/4/20.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Person.h"

@interface Baby1 : Person
-(void)sleep;
-(void)walk;
@end
