//
//  Baby2.m
//  lesson_OC_10
//
//  Created by lanou3g on 15/4/20.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Baby2.h"

@implementation Baby2
#pragma -mark在Baby2里面重写的父类方法
- (void)sleep
{
    NSLog(@"这是一个Baby2在睡觉");
}
@end
