//
//  Person.m
//  lesson_OC_10
//
//  Created by lanou3g on 15/4/20.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Person.h"

@implementation Person
//属性的实现：当我们重写set方法的时候，就需要写这个
@synthesize name =_name;
/*
 -(void)setName:(NSString *)name
{
    //assign简单赋值
    _name=name;
}
*/
-(void)setName:(NSString *)name
{
    if (_name!=name)
    {
        //第一次_name没有值,为nil，release没有用，后面有用
        [_name release];
        //不仅仅是把值给了属性，还把这个参数的所有权也赋值给了属性
        _name=[name retain];
    }

}
//当一个对象最后被销毁的时候，使用该方法只能释放自己的内存空间，通过属性（retain，copy）赋值之后能获得其他内存空间的所有权，这个时候要在销毁对象的时候把这些其他所有权空间一起释放。
- (void)dealloc
{
//推荐(用retain或者copy)
//self.name等同于调用set方法
    self.name=nil;
    
//    [_name release];
//    _name =nil;
    
    [super dealloc];
}
@end
