//
//  main.m
//  lesson_OC_10
//
//  Created by lanou3g on 15/4/20.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
       
        
        Person * p=[[Person alloc]init];
        //创建一个字符串额对象，给p的属性赋值
        NSString *str=[[NSString alloc]initWithFormat:@"张三"];
        p.name=str;//会调用属性的set方法
        //因为用的是assign，所以在赋值的时候str的引用计数不会加1,所以“张三”这一块内存空间的拥有者为str,而p.name只有这块空间的使用权
        NSLog(@"p.name=%@",p.name);
        //str把这块内存空间释放掉了
        [str  release];
        //因为p.name现在所指向的那块内存空间，现在已经被释放掉了，所以不能再使用了，这就是对象类型的属性，用assign修饰的一个隐患。所以对象类型的属性要用retain来修饰，这样就可以获得这块内存空间的所有权
        NSLog(@"p.name=%@",p.name);
        [p.name release];
        //不需要释放内存空间
        int a =25;
        p.age=a;
        //对于不在堆或者不满足内存管理原则对象，使用内存管理的方法不起作用
        NSString *str1=@"张三";
        NSLog(@"str1=%lu",[str1 retainCount]);
        [str1 release];
        [str1 release];
    }
    return 0;
}
