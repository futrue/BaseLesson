//
//  Person.h
//  lesson_OC_10
//
//  Created by lanou3g on 15/4/20.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
//@property (assign ,nonatomic)NSString *name;
@property (retain ,nonatomic)NSString *name;
//这里有一个retain，会使引用计数加一，所以必须有一个release或者autorelease与之对应保证引用平衡，规定属性的属性写在dealloc方法里面
@property(assign,nonatomic)int age;
@end
