//
//  main.m
//  lesson_OC_9
//
//  Created by lanou3g on 15/4/17.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
int main(int argc, const char * argv[]) {
    //alloc：内存空间角度(开辟内存空间)
    //引用计数角度：让一个对象的引用计数从0变为1
    Person *p=[[Person alloc]init];
    //retainCount查看一个对象引用计数的函数
    NSLog(@"p的引用计数为%lu",[p retainCount]);
    //让引用计数加1
    Person *p1 = [p retain];
    NSLog(@"p的引用计数为%lu",[p retainCount]);
    //p和p1都是同一个人，只不过有了两个名字
    NSLog(@"p=%p",p);
    NSLog(@"p1=%p",p1);
    //release:让引用计数减1
    [p1 release];
    NSLog(@"p的引用计数为%lu",[p retainCount]);
    [p release];
    p =nil,p1=nil;//指针也被释放，安全释放（如果不写，注意不要使用已经释放的对象，不然会崩溃）
    //当一个对象已经被释放的时候，如果你再去使用它就会崩溃
    NSLog(@"p的引用计数为%lu",[p retainCount]);
    Person * p2;
    /*
     1.自动释放池，用来释放autorelease对象
     2.autorelease:不能及时让对象的引用计数减1，但是会在这个对象出池的时候，对其引用计数减1
     3.每个方法都自带一个隐性的自动释放池
     */
    @autoreleasepool
    {
        p2=[[Person alloc]init];
        NSLog(@"p2=%p",p2);
        [p2 autorelease];
        NSLog(@"p2的引用计数为%lu",[p2 retainCount]);
    }
        //NSLog(@"p2的引用计数为%lu",[p2 retainCount]);
    return 0;
}
