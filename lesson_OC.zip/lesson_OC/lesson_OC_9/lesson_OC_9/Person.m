
//
//  Person.m
//  lesson_OC_9
//
//  Created by lanou3g on 15/4/17.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Person.h"

@implementation Person
//系统的方法不要在.h里面声明，因为系统早就声明过了，而且该方法会系统自动调用，当一个对象的引用计数为1的时候，再次调用release或者Autorelease的时候，系统就会自动调用该方法，释放对象
- (void)dealloc
{
    NSLog(@"该对象已死");
    [super dealloc];//写在该方法的最后
}
@end
