//
//  Person.h
//  lesson_OC_9
//
//  Created by lanou3g on 15/4/17.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject <NSCopying>
@property (retain,nonatomic)NSString*name;
@property (copy,nonatomic)NSArray *array;
@property(copy,nonatomic)NSMutableArray *mArray;
-(id)copyWithZone:(NSZone *)zone;
@end
