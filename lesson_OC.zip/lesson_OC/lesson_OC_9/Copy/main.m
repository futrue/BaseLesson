//
//  main.m
//  Copy
//
//  Created by lanou3g on 15/4/17.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
int main(int argc, const char * argv[]) {
    
    /*
     浅拷贝：就相当于retain，只copy了一个对象的引用，和本身是同一个对象，相当于影子
     深拷贝：重新开辟一块内存空间，用来存放原来对象里面的东西，这个时候copy出来的对象和原来的对象不是同一个对象，他们的内容一样，就相当于克隆人
     拷贝的对象是什么类型，取决于使用什么拷贝
     */
    
    //1.不可变copy拷贝不可变对象(浅拷贝)
    NSArray *array=[NSArray arrayWithObjects:@"1",@"2" ,nil];
    NSArray *array1=[array copy];
    NSLog(@"array1=%@",array1);
    NSLog(@"array=%p,array1=%p",array,array1);
    
    
    //2.不可变copy拷贝可变对象(深拷贝)
    NSMutableArray * mArray=[NSMutableArray arrayWithObjects:@"1",@"2" ,nil];
    NSMutableArray * mArray1 = [mArray copy];
    NSLog(@"mArray1=%@",mArray1);
    NSLog(@"mArray=%p,mArray1=%p",mArray,mArray1);
    NSLog(@"mArray的类型为%@",[mArray class]);
    //mArray1的类型取决于开辟的内存空间的类型，不取决于修饰的类型
    NSLog(@"mArray1的类型为%@",[mArray1 class]);
    
    //3.可变copy拷贝不可变对象(深拷贝)
    NSArray *array2=[NSArray arrayWithObjects:@"1",@"2", nil];
    NSLog(@"%@",[[array2 mutableCopy] class]);
    
   
    //4.可变copy拷贝可变对象(深拷贝)
    NSMutableArray *mArray2=[NSMutableArray arrayWithObjects:@"1",@"2",nil];
    NSLog(@"mArray2的类型为%@",[[mArray2 mutableCopy] class]);
    
    
    
    //5.自定义类的copy
    /*
     要实现copy必须遵守NSCopying或者NSMutableCopying协议，这里面有一个必须实现的协议copyWithZone:
    */
    Person *p = [[Person alloc]init];
    p.name =@"张三";
    Person *p1 =[p copy];
    NSLog(@"p =%p,p1=%p1",p,p1);
    NSLog(@"p1的名字为%@",p1.name);
    
    //6.属性的copy
    /*
     1.copy修饰不可变属性的时候，就相当于retain
     2.copy修饰可变属性的时候，就相当于不可变copy拷贝可变对象，属于深copy，这个时候，属性和对属性赋值的对象的内存都需要单独管理
     3.建议对象类型都使用retain
     */
    NSArray * bookArray = [[NSArray alloc]initWithObjects:@"三字经",@"水浒传",@"西游记", nil];
    p.array = bookArray;
    NSLog(@"p.array=%p,bookArray=%p",p.array,bookArray);
    
    NSMutableArray *moneyArray = [[NSMutableArray alloc]initWithObjects:@"1w",@"2w",@"3w", nil];
    p.mArray = moneyArray;
    NSLog(@"p.mArray=%p,moneyArray=%p",p.mArray,moneyArray);

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}
