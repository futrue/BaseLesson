

//
//  Person.m
//  lesson_OC_9
//
//  Created by lanou3g on 15/4/17.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Person.h"

@implementation Person
-(id)copyWithZone:(NSZone *)zone
{
    Person *pp = [[Person alloc]init];
    pp.name = self.name;
    NSLog(@"pp%@,%p",pp.name,pp);
    return pp;
}
@end
