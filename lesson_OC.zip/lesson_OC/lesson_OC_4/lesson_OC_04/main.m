//
//  main.m
//  lesson_OC_04
//
//  Created by lanou3g on 15/4/10.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    //创建一个字符串（常量字符串）
    NSString *str1 = @"你好";
    NSLog(@"str1=%@",str1);
    //创建一个格式化字符串
    NSString *str2 = [[NSString alloc]initWithFormat:@"你好，我叫%@，你叫什么?",str1];
    NSLog(@"%@",str2);
    
    NSString *str3 =[NSString stringWithFormat:@"你好，我叫%@，你叫什么?",str2];
    NSLog(@"%@",str3);
    //用一个字符串区创造另一个字符串
    NSString *str4 =[[NSString alloc]initWithString:str1];
    NSLog(@"str4=%@",str4);
    //用一个字符串区创造另一个字符串(便利构造器)
    NSString *str5 =[NSString stringWithString:str1];
     NSLog(@"str5=%@",str1);
    
    
    //字符串的拼接
    NSString *str6 = [NSString stringWithFormat:@"%@%@",str1,str2];
    NSLog(@"str6=%@",str6);
    
    
   
    //字符串的截取
    NSString * str7=[str2 substringFromIndex:1];
    NSLog(@"str7=%@",str7);
    //截取到索引
    NSString *str8 =[str5 substringToIndex:1];
    NSLog(@"str8=%@",str8);
    //字符串范围性截取
    NSRange r={2,3};
    NSString *str9 = [str2 substringWithRange:r];
    NSLog(@"str9= %@",str9);
    //字符串的拼接
    NSString *str10 = [NSString stringWithFormat:@"%@%@",str1,str2];
    NSLog(@"str10=%@",str10);
    
    NSString *str11 = [str1 stringByAppendingString:str2];
    NSLog(@"str11=%@",str11);
    //字符串比较
    //1.比较两个字符串是不是同一个字符串
    NSString *str01 =[NSString stringWithFormat:@"iphone"];
    NSString *str02 = [NSString stringWithFormat:@"ipad"];
    NSLog(@"str01的地址为%p",str01);
    NSLog(@"str02的地址为%p",str02);
    if (str01==str02)
    {
        NSLog(@"同一个字符串");
    }
    else
    {
        NSLog(@"不是同一个字符串");
    }
    //2.判断字符串的内容是否相等
    if ([str01 isEqualToString:str02])
    {
        NSLog(@"内容相同");
    }
     else
     {
         NSLog(@"内容不相等");
     }
    
    //字符串大小的比较
    NSComparisonResult CR=[@"脆皮" compare:@"阿明"];
    if (CR == NSOrderedAscending)
    {
        NSLog(@"str02大于str01");
    }
    else if(CR == NSOrderedSame)
    {
        NSLog(@"str02和str01相等");
    }
    else
    {
        NSLog(@"str02小于str01");
    }
    
    //大小写转换
    NSString *str12 =@"heLlO,world";
    NSString *ustr = [str12 uppercaseString];
    NSLog(@"ustr =%@",ustr);
    NSString *lstr = [str12 lowercaseString];
    NSLog(@"lstr =%@",lstr);
    //首字母大写
    NSString *cstr = [str12 capitalizedString];
    NSLog(@"cstr =%@",cstr);
    
    //判断字符串的开始和结束
    NSString *str13 =@"iOs-iphone";
    if ([str13 hasPrefix:@"iOs"])//判断以什么开始

    {
        NSLog(@"yes");
    }
    else
    {
        NSLog(@"no");
    }
    
    if ([str13 hasSuffix:@"e"])//判断以什么结束
    {
        NSLog(@"yes");
    }
    else
    {
        NSLog(@"no");
    }
//字符串替换
    NSString *str14 =[NSString stringWithFormat:@"QWERTYUIOP"];
    NSString * str15= [str14 stringByReplacingOccurrencesOfString:str14 withString:@"ASDFGHJKL"];
    NSLog(@"str15=%@",str15);
    NSLog(@"str14=%@",str14);
    NSString *str16=[str15 stringByReplacingCharactersInRange:
                       NSMakeRange(4,1) withString:@"A"];
    NSLog(@"str16=%@",str16);
    

    
//可变字符串
    NSMutableString * mstr = [NSMutableString
            stringWithFormat:@"IPHONE"];
    NSLog(@"mstr=%@",mstr);
    //在本身基础上插入了字符串
    [mstr insertString:@"IPAD" atIndex:3];
    NSLog(@"mstr=%@",mstr);
    //删除
    [mstr deleteCharactersInRange:NSMakeRange(3, 4)];
    NSLog(@"mstr=%@",mstr);
    //追加
    [mstr appendString:@"ipad"];
    NSLog(@"mstr=%@",mstr);
    
    NSString *str001 = [NSString stringWithFormat:@"12345png"];
    
    
    if ([str001 hasPrefix:@"png"])
    {
       NSString * str002= [str001 stringByReplacingCharactersInRange:
       NSMakeRange(str001.length-3, 3) withString:@"jpg"];
        NSLog(@"%@",str002);
    }
    else
    {
        NSString * str003=[str001 stringByAppendingString:@".jpg"];
        NSLog(@"%@",str003);
    }
    
    
    
    return 0;
}
