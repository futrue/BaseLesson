//
//  main.m
//  NSArray
//
//  Created by lanou3g on 15/4/10.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
//********************************数组的创建********************************************
    
    NSArray *array1=[[NSArray alloc]initWithObjects:@"IPHONE", @"IPAD",@"IWATCH",nil];
    NSLog(@"array1=%@",array1);
    
    NSArray *array2=[NSArray arrayWithObjects:@"zhangsan",@"lisi",@"wangwu" ,nil];
    NSLog(@"array2=%@",array2);
    
    //字面量
    NSArray *array3 = @[@"beijing",@"guangzhou",@"shanghai"];
    NSLog(@"array3=%@",array3);
    
    
//********************************求数组的元素个数********************************************
    
    NSLog(@"%ld",[array3 count]);
    
//********************************通过下标取值********************************************
    
    NSLog(@"array3的第二个元素是%@",array3[1]);
    NSLog(@"array3的第三个元素是%@",[array3 objectAtIndex:2]);
//****************************添加元素，添加后得到一个新数组*********************************
    NSArray *array4 =[array3 arrayByAddingObject:@"shenzhen"];
    NSLog(@"array4=%@",array4);
//***************************特殊的字符串和数组之间的转换***********************************
    //1.将数组转化为字符串
    NSString *str =[array4 componentsJoinedByString:@","];
    NSLog(@"str=%@",str);
    //2.将字符串转化为数组
    NSString * str1= [NSString stringWithFormat:@"ios andriod wp"];
    NSArray *array5 = [str1 componentsSeparatedByString:@"n"];
    NSLog(@"array5=%@",array5);
//********************************通过对象去查找下标********************************************
    
    NSInteger index =[array4 indexOfObject:@"shanghai"];
    NSLog(@"index=%ld",index);
//********************************数组的遍历********************************************
    
    for (int i=0; i<[array4 count]; i++)
    {
        id a =[array4 objectAtIndex:i];
        NSLog(@"a=%@",a);
    }
    //快速遍历
    for (id b in array4)
    {
        NSLog(@"b=%@",b);
    }
//********************************可变数组********************************************
    
    
    NSMutableArray *marray=[[NSMutableArray alloc]initWithObjects:@"a",@"b",@"c",@"d", nil];
    NSLog(@"marray=%@",marray);
    
    //追加
    [marray addObject:@"E"];
    NSLog(@"marray=%@",marray);
    //插入
    [marray insertObject:@"f" atIndex:2];
    NSLog(@"marray=%@",marray);
    //删除
    [marray removeObjectAtIndex:4];
    NSLog(@"marray=%@",marray);
    //替换
    [marray replaceObjectAtIndex:2 withObject:@"N"];
    NSLog(@"marray=%@",marray);
    
 //*******************************NSNumber(数字和对象转换)**************************************
    float a=3.2;
    NSNumber *aNum=[[NSNumber alloc] initWithFloat:a];
    NSLog(@"aNum=%@",aNum);
    //将对象类型转化为基本类型
    float b =[aNum floatValue];
    NSLog(@"b=%.1f",b);
 
    NSString *_str =@"123";
    int c=[_str intValue];
    NSLog(@"_str=%d",c);
    
    
    
    
    return 0;
}
