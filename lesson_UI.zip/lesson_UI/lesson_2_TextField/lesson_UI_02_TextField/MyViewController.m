//
//  MyViewController.m
//  lesson_UI_02_TextField
//
//  Created by lanou3g on 15/4/23.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "MyViewController.h"

@interface MyViewController ()

@end

@implementation MyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.view.backgroundColor=[UIColor cyanColor];
    //创建一个文本书输入框对象
    UITextField *textField = [[UITextField alloc]initWithFrame:CGRectMake(50, 100, 220, 40)];
    //添加进入父试图
    [self.view addSubview:textField];
    
    //1.设置背景颜色
    textField.backgroundColor = [UIColor whiteColor];
   
    //2.设置边框样式(不设置背景颜色，设置边框样式同样可以显示(默认白色))
    textField.borderStyle = UITextBorderStyleRoundedRect;
    
    //3.清除按钮的样式(在输入框的最后的小x)
    textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    
    //4.创建左视图
    UILabel *leftlabel = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, 50, 30)];
    leftlabel.backgroundColor= [UIColor blueColor];
    [leftlabel setTextColor:[UIColor brownColor]];
    [leftlabel setTextAlignment:NSTextAlignmentCenter];
    leftlabel.text=@"名字";
    textField.leftView=leftlabel;
    //设置左视图出现的样式
    textField.leftViewMode = UITextFieldViewModeAlways;
    
    //5.创建右视图
    UILabel *rightLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 40, 30)];
    rightLabel.text =@"撤销";
    //将创建好的右视图赋值给textField的右视图属性
    textField.rightView=rightLabel;
    //设置什么时候显示
    textField.rightViewMode=UITextFieldViewModeWhileEditing;
    
    //6.是否允许输入
    //textField.enabled= NO;
    
    //7.UIView的属性(用户交互)
    //textField.userInteractionEnabled=NO;
    
    //8.是否开启下次输入之前清空文本框的内容
    textField.clearsOnBeginEditing=YES;
    
    //9.是否以密码形式输入
    //textField.secureTextEntry = YES;
    
    //10.设置键盘样式
    //textField.keyboardType=UIKeyboardTypeDefault;
    
    //11.设置return键的样式
    textField.returnKeyType= UIReturnKeyDone;
    

    //12.附件视图
    UILabel *AccessLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 320, 40)];
    AccessLabel.backgroundColor = [UIColor brownColor];
    AccessLabel.text = @"中文   英文";
    [AccessLabel setFont:[UIFont fontWithName:@"Arial" size:20]];
    textField.inputAccessoryView=AccessLabel;
    
//**********************************UITextField代理方法***************************************
    /*
     使用系统协议
     第一步:遵守协议;
     第二步 设置代理
     第三步 实现协议方法(写在viewDidLoad函数外)
     */
    //指定代理人
    textField.delegate=self;
    
}



//协议中的optional方法
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSLog(@"当点击右下角键的时候，就会执行该方法");
    //取消第一响应者(取消键盘)
    return  [textField resignFirstResponder];
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    NSLog(@"文本框将要开始编辑时执行的方法");
    //如果返回值为NO就意味着不可以编辑
    return  YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    NSLog(@"已经开始编辑时执行的方法");
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    NSLog(@"文本框将要结束时执行的方法");
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    NSLog(@"文本输入框已经结束编辑时执行的方法");
    NSLog(@"文本输入框的内容是%@",textField.text);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
