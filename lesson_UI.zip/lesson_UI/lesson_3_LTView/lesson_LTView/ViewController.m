//
//  ViewController.m
//  lesson_LTView
//
//  Created by lanou3g on 15/4/24.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    LTView *userLv = [[LTView alloc]initWithFrame:CGRectMake(10, 100, 300, 50) text:@"用户名" placeHolder:@"请输入用户名"];
    [self.view addSubview:userLv];
    LTView *secureLv =[[LTView alloc]initWithFrame:CGRectMake(10, 170, 300, 50) text:@"密码" placeHolder:@"请输入密码"];
    [self.view addSubview:secureLv];
   
    LTView * LV = [[LTView alloc]initWithFrame:CGRectMake(10, 240, 300, 50) text:@"验证码" placeHolder:@"请输入验证码" color:[UIColor yellowColor] proportion:0.2 distance:30 agent:self];
    [self.view addSubview:LV];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
