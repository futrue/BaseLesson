//
//  LTView.m
//  lesson_LTView
//
//  Created by lanou3g on 15/4/24.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "LTView.h"

@implementation LTView
- (id)initWithFrame:(CGRect)frame
{
    if ([super initWithFrame:frame])
    {
        
    }
    return self;
}//必须要有

- (id)initWithFrame:(CGRect)frame text:(NSString *)LabelText placeHolder:(NSString *)TextFieldPlaceHolder
{
    if ([super initWithFrame:frame])
    {
    //默认Label占整个视图宽度的40%
        _label = [[UILabel alloc]initWithFrame
                   :CGRectMake(0, 0, frame.size.width*0.4, frame.size.height)];
    //设置一些默认的属性
        _label.textAlignment = NSTextAlignmentCenter;
        _label.backgroundColor = [UIColor cyanColor];
        //在初始化就设置label要显示的文字
        _label.text=LabelText;
    //将lable添加到父视图上
        [self addSubview:_label];
    
    //设置第二个模块文本输入框
        _textField = [[UITextField alloc]initWithFrame:CGRectMake(frame.size.width*0.4+10, 0, frame.size.width*0.6-10, frame.size.height)];
    //设置一些默认的属性
        _textField.placeholder=TextFieldPlaceHolder;
        _textField.borderStyle=UITextBorderStyleBezel;
    //将textField添加到父视图上
        [self addSubview:_textField];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame text:(NSString *)LabelText placeHolder:(NSString *)TextFieldPlaceHolder color:(UIColor *)labelColor proportion:(float)labelProportion distance:(int)distance agent:(id)delegate
{
    if ([super initWithFrame:frame])
    {
        _label = [[UILabel alloc ]initWithFrame
                  :CGRectMake(0, 0, frame.size.width*labelProportion, frame.size.height)];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.backgroundColor = labelColor;
        _label.text=LabelText;
        [self addSubview:_label];
        
        _textField = [[UITextField alloc]initWithFrame:CGRectMake(frame.size.width*0.4+10, 0, frame.size.width*(1-labelProportion)-distance, frame.size.height)];
        _textField.placeholder=TextFieldPlaceHolder;
        _textField.borderStyle=UITextBorderStyleBezel;
        [self addSubview:_textField];
        
        _textField.delegate=delegate;
        
        
    }
    return self;
}

@end
