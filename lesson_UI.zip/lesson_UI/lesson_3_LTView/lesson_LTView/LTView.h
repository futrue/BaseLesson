//
//  LTView.h
//  lesson_LTView
//
//  Created by lanou3g on 15/4/24.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LTView : UIView <UITextFieldDelegate>
{
    UILabel *_label;
    UITextField *_textField;
}
/**
 根据Frame初始化一个对象
 Frame：LTView的位置和大小
 */
-(id)initWithFrame:(CGRect)frame;
/*
描述:这是一个初始化方法
 参数:  frame->LTView的位置和大小
       LabelText->LTView中要显示的文本信息
       TextFieldPlaceHolder->LTView中textField要显示的提示文字
*/
- (id)initWithFrame:(CGRect)frame text:(NSString *)LabelText placeHolder:(NSString *)TextFieldPlaceHolder;

//通常第三方里面会提供很多初始化方法，这个时候对于使用者来说就可以根据不同的情况下，选择比较合适的初始化方法来创造一个对象，并且实例方法和便利构造器方法都会提供

//+ (id)ltviewWithFrame:(CGRect)frame text:(NSString *)labelText placeHolder:(NSString *)TextFieldPlaceHolder;

- (id)initWithFrame:(CGRect)frame text:(NSString *)LabelText placeHolder:(NSString *)TextFieldPlaceHolder color:(UIColor *)labelColor proportion:(float)labelProportion
           distance:(int)distance agent:(id)delegate;

@end
