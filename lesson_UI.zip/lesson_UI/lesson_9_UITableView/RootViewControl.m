//
//  RootViewControl.m
//  lesson_UITableView
//
//  Created by lanou3g on 15/5/4.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "RootViewControl.h"

@interface RootViewControl ()
@property(strong,nonatomic)UITableView *tableView;
@property(strong,nonatomic)NSArray *dataArray;
@end

@implementation RootViewControl

- (void)viewDidLoad {
    [super viewDidLoad];
    /*
     1.先走一个表视图里面有多少分区
     2.再走一个分区里面与多少cell
     3.最后再一个cell一个cell的创建
     
     */
    //先准备好表视图要显示的数据(1.0版本)
    //self.dataArray = [[NSArray alloc]initWithObjects:@"张三",@"李四",@"王五",@"赵六" ,nil];
    //数据源(2.0版本)
    //1.第一个分区的数据
    NSArray * array1 =[[NSArray alloc]initWithObjects:@"张三",@"李四",@"王五",@"赵六" ,nil];
    //2.第二个分区数据
    NSArray *array2 = [[NSArray alloc]initWithObjects:@"xiaoA",@"xiaoB",@"xiaoC",@"xiaoD", nil];
    //3.将每个分区的局部数据放在一起当做表视图的整体数据使用
    self.dataArray = [[NSArray alloc]initWithObjects:array1,array2 ,nil];
    
    //创建一个表视图
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height-60) style:UITableViewStyleGrouped];
    [self.view addSubview:self.tableView];
    //让视图从导航控制器下面显示
    self.edgesForExtendedLayout = UIRectEdgeNone;
//************************************创建头、尾视图****************************************
    UIImageView * headerView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 120)];
    headerView.image =[UIImage imageNamed:@"1.png"];
    self.tableView.tableHeaderView = headerView;
    
    UIImageView * footerView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 100)];
    footerView.image = [UIImage imageNamed:@"2.png"];
    self.tableView.tableFooterView = footerView;
//************************************表视图代理************************************
    self.tableView.delegate = self;//设置表视图外貌设置的代理
    self.tableView.dataSource = self;
    
    
}
#pragma -mark表视图dataSource代理的方法（必须实现）

#pragma -mark1.返回一个分区有多少个cell
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //return 20;
    NSLog(@"%s",__FUNCTION__);
    //return [self.dataArray count];(1.0版本)
    return [[self.dataArray objectAtIndex:section] count];//(2.0版本)
}
#pragma -mark2.创建cell上要显示什么内容的方法
/*
 1.只要有cell的出现和消失就会执行
 2.当满屏的时候还有多余的cell没有显示这个时候就不会在进if语句创建cell了，开始执行重用机制
 3.为什么重用？怎么重用？(内存、数据)

 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //1.创建一个重用标识符
    static NSString * indentifier = @"cell";
    //2.如果表视图重用，设置同一类型的才能重用
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:indentifier];
    NSLog(@"2---%@",indexPath);
    
    //通常一个屏幕能显示几个cell就会创建多少个cell，剩下的重用
    if (cell == nil)
    {
        //用indexPath来标记cell的位置
        NSLog(@"1---%@",indexPath);
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault            reuseIdentifier:indentifier];
    }
    //3.对cell上的内容的设置
    
    //cell.textLabel.text = @"123";
    //通常采用动态赋值的形式
    //cell.textLabel.text = [self.dataArray objectAtIndex:indexPath.row];(1.0版本)
    //给cell设置图片
    //cell.imageView.image = [UIImage imageNamed:@"1.png"];(1.0版本)
    
    //indexPath.section是当前cell所在分区
    //indexPath.row当前cell在分区的第几行
    cell.textLabel.text = [[self.dataArray objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];//(2.0版本)
    return cell;
}
#pragma -mark一个表视图有多少分区
 -(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    NSLog(@"%s",__FUNCTION__);
    //return 2;(1.0版本)
    return [self.dataArray count];//(2.0版本)
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
