//
//  ViewController.m
//  lesson_5_gesture
//
//  Created by lanou3g on 15/4/28.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    CGPoint startPoint ;
    CGFloat _centerX;
    CGFloat _centerY;
    UIView * _backgroundView;
}
//轻拍手势
@property(strong,nonatomic)UITapGestureRecognizer *tap;
//长按手势
@property(strong,nonatomic)UILongPressGestureRecognizer *longPress;
//轻扫手势
@property(strong,nonatomic)UISwipeGestureRecognizer *swipe;
//旋转手势
@property(strong,nonatomic)UIRotationGestureRecognizer* rotation;
//捏合手势
@property (strong,nonatomic)UIPinchGestureRecognizer *pinch;
//拖拽手势
@property(strong,nonatomic)UIPanGestureRecognizer *pan;
//边缘平移手势
@property(strong,nonatomic)UIScreenEdgePanGestureRecognizer *screenEdgePan;

@property(strong,nonatomic)UIImageView *myImageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.myImageView =[[UIImageView alloc]initWithFrame:CGRectMake(100, 50, 175, 250)];
   self.myImageView.image = [UIImage imageNamed:@"1.png"];
    [self.view addSubview:self.myImageView];
    //打开用户交互
    self.myImageView.userInteractionEnabled=YES;
   
    //轻拍手势
    /*
    //1.创造一个手势
    self.tap= [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(doTap:)];
    //2.将手势添加到要控制的视图上
    [self.myImageView addGestureRecognizer:self.tap];
    //3.实现doTap:
    */
   
    //长按手势
    /*
    self.longPress = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(doLongPress:)];
    [self.myImageView addGestureRecognizer:self.longPress ];
    */
    
    //轻扫手势
    /*
    self.swipe = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(doSwipe:)];
    [self.view addGestureRecognizer:self.swipe];
     */

    
    //旋转手势
    /*
    self.rotation = [[UIRotationGestureRecognizer alloc]initWithTarget:self action:@selector(doRotation:)];
    [self.myImageView addGestureRecognizer:self.rotation];
     */
    
    //捏合手势
    /*
    self.pinch = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(doPinch:)];
    [self.myImageView addGestureRecognizer:self.pinch];
    */
    
    //拖拽手势
    /*
    self.pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(doPan:)];
    [self.myImageView addGestureRecognizer:self.pan];
    */
    
    //边缘平移手势

    /*
    _centerX = self.view.bounds.size.width/2;
    _centerY =self.view.bounds.size.height/2;
    self.screenEdgePan = [[UIScreenEdgePanGestureRecognizer  alloc]initWithTarget:self action:@selector(doScreen:)];
    _backgroundView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width,[UIScreen mainScreen].bounds.size.height-300)];
    _backgroundView.backgroundColor = [UIColor yellowColor];
    
    
    [self.view addSubview:_backgroundView];
    [self.view addGestureRecognizer:self.screenEdgePan];
    //设置手势的触发边
    self.screenEdgePan.edges = UIRectEdgeRight;
     */

}



#pragma -mark检测到轻拍手势时执行的方法
-(void)doTap:(UITapGestureRecognizer *)tap
{
    NSLog(@"%s",__FUNCTION__);
}

#pragma -mark检测到长按手势时执行的方法
- (void)doLongPress:(UILongPressGestureRecognizer *)longPress
{
    NSLog(@"%s",__FUNCTION__);
}

#pragma -mark检测到轻扫手势时执行的方法
-(void)doSwipe:(UISwipeGestureRecognizer *)swipe
{
    UIView *aView = [[UIView alloc]initWithFrame:CGRectMake(-100, 0, 100, 500)];
    [aView setBackgroundColor:[UIColor cyanColor]];
    [self.view addSubview:aView];
    [UIView animateWithDuration:1 animations:^{
        aView.frame = CGRectMake(0, 0, 100, 568);
    }];
}

#pragma -mark检测到旋转手势时执行的方法
-(void)doRotation:(UIRotationGestureRecognizer *)rotation
{
    //transform:主要用于平移，翻转，旋转等动画效果

    //1.硬件设备会自动检测到手指在屏幕上的形变量
    CGAffineTransform transform = CGAffineTransformMakeRotation(self.rotation.rotation);
    //2.把上一步硬件检测到的旋转量赋值给相框
    self.myImageView.transform =  transform;
}

#pragma -mark检测到捏合手势时执行的方法
- (void)doPinch:(UIPinchGestureRecognizer *)pinch
{
 //1.硬件设备会自动检测到手指在屏幕上的形变量
    CGAffineTransform transform = CGAffineTransformMakeScale(self.pinch.scale, self.pinch.scale);
  //2.把上一步硬件检测到的旋转量赋值给相框
    self.myImageView.transform = transform;
}

#pragma -mark检测到拖拽手势时执行的方法
-(void)doPan:(UIPanGestureRecognizer *)pan
{
    //开始拖拽
    if (pan.state==UIGestureRecognizerStateBegan)
    {
        startPoint = [pan translationInView:self.myImageView];
    }
    //手势正在进行中
    else if (pan.state==UIGestureRecognizerStateChanged)
    {
        CGPoint currentPoint = [pan translationInView:self.myImageView];
        //获得偏移量
        float delatX = currentPoint.x-startPoint.x;
        float delatY = currentPoint.y-startPoint.y;
        startPoint = currentPoint;
        CGAffineTransform  transform = CGAffineTransformTranslate(self.myImageView.transform,delatX, delatY);
        self.myImageView.transform = transform;
    }
    
}
#pragma -mark检测到触摸边缘手势时执行的方法
-(void)doScreen:(UIScreenEdgePanGestureRecognizer *)screen
{
    //1.获得当前触摸的视图
    UIView *view= [self.view hitTest:[screen locationInView:self.view] withEvent:nil];
    if (UIGestureRecognizerStateBegan==screen.state||
        UIGestureRecognizerStateChanged==screen.state)
    {
        //根据被触摸手势的view计算得出坐标值
        CGPoint translation = [screen translationInView:screen.view];
        //进行偏移
        _backgroundView.center =
        CGPointMake(_centerX+translation.x,_backgroundView.center.y);
    }
    
    else
    {
        // 恢复设置
        [UIView animateWithDuration:.3 animations:^{
            _backgroundView.center = CGPointMake(_centerX, _backgroundView.center.y);
        }];
    }
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
