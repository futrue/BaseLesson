//
//  saveTest.h
//  leeson_UI_8
//
//  Created by lanou3g on 15/5/1.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
/*
代理传值:委托代理调用方法
        方法的实现和代理属性的定义在委托里
        指定代理和方法的调用在代理中
        属性和方法的实现不能在一个类里面
*/
@protocol saveTest <NSObject>
- (void)displayText:(NSString *)str;
@end
