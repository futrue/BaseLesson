//
//  secondViewController.h
//  leeson_UI_8
//
//  Created by lanou3g on 15/5/1.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import"saveTest.h"
@interface secondViewController : UIViewController
//代理不能用强引用，为了防止循环引用
@property(weak,nonatomic) id <saveTest>delegate;
@end
