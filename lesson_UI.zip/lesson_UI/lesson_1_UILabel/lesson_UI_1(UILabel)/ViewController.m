//
//  ViewController.m
//  lesson_UI_1(UILabel)
//
//  Created by lanou3g on 15/4/22.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //静态显示文字的类
    UILabel *label1=[[UILabel alloc]initWithFrame:CGRectMake(100, 100, 120,60)];
    [self.view addSubview:label1];
    [label1 setBackgroundColor:[UIColor blueColor]];
    //设置显示的文字
    label1.text=@"Hello,World!";
    //设置对齐方式
    [label1 setTextAlignment:NSTextAlignmentCenter];
    //设置字体大小
    [label1 setFont:[UIFont systemFontOfSize:20]];
    //设置行数(0代表自动适应)
    [label1 setNumberOfLines:0];
    //设置断行样式
    [label1 setLineBreakMode:0];
    //设置阴影的偏移量
    [label1 setShadowOffset:CGSizeMake(5, 5)];
    //设置阴影颜色
    [label1 setShadowColor:[UIColor redColor]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
