//
//  AppDelegate.h
//  lesson_II_DiyTableVieCell
//
//  Created by lanou3g on 15/5/6.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

