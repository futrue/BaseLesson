//
//  ViewController.m
//  lesson_II_DiyTableVieCell
//
//  Created by lanou3g on 15/5/6.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataArray = [NSArray arrayWithObjects:@"《岳阳楼记》是一篇为重修岳阳楼写的记。由北宋文学家范仲淹应好友巴陵郡守滕子京之请，于北宋庆历六年（1046年）九月十五日所作。其中的诗句“先天下之忧而忧，后天下之乐而乐”、“不以物喜，不以己悲”是较为出名和引用较多的句子。《岳阳楼记》能够成为传世名篇并非因为其对岳阳楼风景的描述，而是范仲淹借《岳阳楼记》一文抒发先忧后乐、忧国忧民的情怀", @"仁宗庆历四年春天，滕子京被降职到巴陵郡做太守。到了第二年，政事顺利，百姓和乐，各种荒废的事业都兴办起来。于是重新修建岳阳楼，扩增它旧有的规模，在岳阳楼上刻上唐代名家和当代人的诗赋。嘱托我写一篇文章来记述这件事", @"庆历四年春，滕（téng）子京谪（zhé）守巴陵郡。越明年，政通人和，百废具兴，乃重修岳阳楼，增其旧制，刻唐贤今人诗赋于其上。属（zhǔ）予（yú）作文以记之", @"予观夫（fú）巴陵胜状，在洞庭一湖", @"至若春和景明，波澜不惊，上下天光", @"岸芷（zhǐ） 汀（tīng）兰", @"若夫（fú）淫（yín）雨霏霏，连月不开；阴风怒号，浊浪排空。日星隐曜（yào），山岳潜形。商旅不行，樯（qiáng）倾楫（jí）摧。薄（bó）暮冥冥（míng），虎啸猿啼。登斯楼也，则有去国怀乡，忧谗畏讥（jī），满目萧然，感极而悲者矣。", @"岸芷（zhǐ） 汀（tīng）兰", @"若夫（fú）淫（yín）雨霏霏，连月不开；阴风怒号，浊浪排空。日星隐曜（yào），山岳潜形。商旅不行，樯（qiáng）倾楫（jí）摧。薄（bó）暮冥冥（míng），虎啸猿啼。登斯楼也，则有去国怀乡，忧谗畏讥（jī），满目萧然，感极而悲者矣。", @"至若春和景明，波澜不惊，上下天光，一碧万顷（qǐng）。沙鸥翔集，锦鳞游泳；岸芷（zhǐ） 汀（tīng）兰，郁郁青青。而或长烟一空，皓月千里，浮光跃金，静影沉璧。渔歌互答，此乐何极！登斯楼也，则有心旷神怡，宠辱偕（xié）忘，把酒临风，其喜洋洋者矣", nil];
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 20, self.view.bounds.size.width, self.view.bounds.size.height-20) style:UITableViewStylePlain];
    [self.view addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
}
 - (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * identifier = @"cell";
    MyTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if(cell==nil)
    {
        cell = [[MyTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    //该字符串是要在cell上面显示的内容
    NSString * text = [self.dataArray objectAtIndex:indexPath.row];
    
    NSDictionary * dic = [NSDictionary dictionaryWithObject:[UIFont systemFontOfSize:13] forKey:NSFontAttributeName];
    //该方法会计算text文本的大小，并且把大小计算后返回来
    /*
     参数1:设置一个大概的范围，这里的高设置的尽量的大一些
     参数2:从原点开始写内容
     参数3:设置字体的大小 
     参数4:对计算出来的区域大小范围做什么操作
     */
    CGRect  mylabelRect = [text boundingRectWithSize:CGSizeMake(self.view.bounds.size.width-5, 2000) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil];
    cell.myLabel.frame = mylabelRect;
    cell.myLabel.text = [self.dataArray objectAtIndex:indexPath.row];
    return cell;
}
//重新计算一下cell的行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
       NSString * text = [self.dataArray objectAtIndex:indexPath.row];
       NSDictionary * dic = [NSDictionary dictionaryWithObject:[UIFont systemFontOfSize:13] forKey:NSFontAttributeName];
    
       CGRect rect = [text boundingRectWithSize:CGSizeMake(self.view.bounds.size.width-5, 2000) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil];
       return rect.size.height+5;
}
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
                      
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
