//
//  ViewController.h
//  lesson_II_DiyTableVieCell
//
//  Created by lanou3g on 15/5/6.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTableViewCell.h"
@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property(strong,nonatomic)UITableView * tableView;
@property(strong,nonatomic)NSArray * dataArray;

@end

