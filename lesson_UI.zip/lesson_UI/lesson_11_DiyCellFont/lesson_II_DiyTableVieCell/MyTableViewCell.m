//
//  MyTableViewCell.m
//  lesson_II_DiyTableVieCell
//
//  Created by lanou3g on 15/5/6.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "MyTableViewCell.h"

@implementation MyTableViewCell


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if ([super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        //在创建label的时候，先给一个zero，当我们拿到具体的数据的时候，会计算文本的大小，得到大小之后，再对frame重新设置
        self.myLabel = [[UILabel alloc]initWithFrame:CGRectZero];
        //设置行数不限制
        self.myLabel.numberOfLines =0;
        [self.myLabel setFont:[UIFont systemFontOfSize:12]];
        [self.contentView addSubview:self.myLabel];
    }
    return  self;
}




- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
