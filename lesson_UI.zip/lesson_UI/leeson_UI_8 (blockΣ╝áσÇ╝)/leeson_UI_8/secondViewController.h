//
//  secondViewController.h
//  leeson_UI_8
//
//  Created by lanou3g on 15/5/1.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^Myblock)(NSString *str);

@interface secondViewController : UIViewController

@property(strong,nonatomic)Myblock mb;

@end
