//
//  firstViewController.m
//  leeson_UI_8
//
//  Created by lanou3g on 15/5/1.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "firstViewController.h"
#import "secondViewController.h"
@interface firstViewController () <UITextFieldDelegate>
{
    UIButton *_btn;
    UILabel *_label;
    UITextField *_textField;
}
@end

@implementation firstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor cyanColor]];
    [self layoutUI];
}

- (void)layoutUI
{
    //创建一个label
    _label = [[UILabel alloc]initWithFrame:CGRectMake(100, 60, 120, 40)];
    _label.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_label];
    //创建一个textfield
    _textField = [[UITextField alloc]initWithFrame:CGRectMake(100, 140, 120, 40)];
    _textField.borderStyle = UITextBorderStyleRoundedRect;
    [self.view addSubview:_textField];
    _textField.delegate=self;
    //创建一个button
    _btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 220, 120, 40)];
    _btn.backgroundColor = [UIColor blueColor];
    [self.view addSubview:_btn];
    [_btn addTarget:self action:@selector(dobtn) forControlEvents:UIControlEventTouchDown];
}

- (void)dobtn
{
    //该案例从second向first传值
    secondViewController *second = [[secondViewController alloc]init];
    second.mb = ^(NSString *str){
    //在这里只是声明这个block是干什么的
        _label.text=str;
    };
    
    [self.navigationController pushViewController:second animated:YES];
}










- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
