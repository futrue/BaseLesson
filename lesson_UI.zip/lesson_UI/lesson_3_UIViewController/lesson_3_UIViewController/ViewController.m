//
//  ViewController.m
//  lesson_3_UIViewController
//
//  Created by lanou3g on 15/4/24.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
#pragma -mark视图已经加载完成是执行的方法
- (void)viewDidLoad {
    [super viewDidLoad];
    //打印当前这个函数的名字
    NSLog(@"%s",__FUNCTION__);
    UIView *aView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    aView.backgroundColor = [UIColor redColor];
    [self.view addSubview:aView];
    
    NSLog(@"self.view的frame为%@",NSStringFromCGRect(self.view.frame));
    //属性赋值,将aView指定为当前视图控制的view
    //self.view = aView;
}
//设置应用程序的视图控制器是否支持旋转
- (BOOL)shouldAutorotate
{
    //视图控制器默认是支持旋转的
    return NO;
}

#pragma -mark视图将要出现时执行的方法
- (void)viewWillAppear:(BOOL)animated
{
    NSLog(@"%s",__FUNCTION__);
}

#pragma -mark视图已经出现时执行的方法
- (void)viewDidAppear:(BOOL)animated
{
    NSLog(@"%s",__FUNCTION__);
}

#pragma -mark视图将要消失时执行的方法
- (void)viewWillDisappear:(BOOL)animated
{
    NSLog(@"%s",__FUNCTION__);
}

#pragma -mark视图已经消失时执行的方法
- (void)viewDidDisappear:(BOOL)animated
{
    NSLog(@"%s",__FUNCTION__);
}



#pragma -mark开始触摸视图控制器时执行的方法
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%s",__FUNCTION__);
}
#pragma -mark在视图控制器滑动时执行的方法
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%s",__FUNCTION__);
}
#pragma -mark触摸取消时执行的方法
-(void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%s",__FUNCTION__);
}
#pragma - mark触摸结束时执行的方法
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%s",__FUNCTION__);
}

#pragma -mark当应用程序收到内存警告时执行的方法
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        
}

@end
