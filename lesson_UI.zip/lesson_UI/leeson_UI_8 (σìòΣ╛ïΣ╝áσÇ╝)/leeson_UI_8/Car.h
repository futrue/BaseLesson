//
//  Car.h
//  leeson_UI_8
//
//  Created by lanou3g on 15/5/1.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Car : NSObject
@property(strong,nonatomic)NSString *carContext;
+ (id)singleCar;
@end
