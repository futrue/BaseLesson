//
//  Car.m
//  leeson_UI_8
//
//  Created by lanou3g on 15/5/1.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Car.h"

@implementation Car
+ (id)singleCar
{
    static Car * car = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        car = [[Car alloc]init];
    });
    return car;
}
@end
