//
//  secondViewController.m
//  leeson_UI_8
//
//  Created by lanou3g on 15/5/1.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "secondViewController.h"
#import "Car.h"
@interface secondViewController ()<UITextFieldDelegate>
{
    UIButton *_btn;
    UILabel *_label;
    UITextField *_textField;
}
@end

@implementation secondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor redColor]];
    [self layoutUI];
    //卸货
    /*
    Car *c = [Car singleCar];
    _label.text=c.carContext;
    */
    NSUserDefaults * user = [NSUserDefaults standardUserDefaults];
    _label.text = [user valueForKey:@"k1"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)layoutUI
{
    //创建一个label
    _label = [[UILabel alloc]initWithFrame:CGRectMake(100, 60, 175, 40)];
    _label.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_label];
    //创建一个textfield
    _textField = [[UITextField alloc]initWithFrame:CGRectMake(100, 140, 175, 40)];
    _textField.borderStyle = UITextBorderStyleRoundedRect;
    [self.view addSubview:_textField];
    _textField.delegate=self;
    //创建一个button
    _btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 220, 175, 40)];
    _btn.backgroundColor = [UIColor blueColor];
    [self.view addSubview:_btn];
    [_btn addTarget:self action:@selector(dobtn) forControlEvents:UIControlEventTouchDown];
}

- (void)dobtn
{
    [self.navigationController popViewControllerAnimated:YES];
}















/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
