//
//  MyCell.h
//  lesson_14_storyBoardOtherCell
//
//  Created by lanou3g on 15/5/11.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *label;

@end
