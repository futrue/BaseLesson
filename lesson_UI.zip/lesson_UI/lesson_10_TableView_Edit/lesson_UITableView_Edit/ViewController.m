//
//  ViewController.m
//  lesson_UITableView_Edit
//
//  Created by lanou3g on 15/5/5.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property(strong,nonatomic)UITableView *tableView;
@property(strong,nonatomic)NSMutableArray * dataArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //准备表视图要显示的数据
    self.dataArray = [[NSMutableArray alloc]initWithObjects:@"A",@"B",@"C",@"D",@"E", nil];
    
    //创建表视图的相关信息
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 20, self.view.bounds.size.width, self.view.bounds.size.height-20) style:UITableViewStylePlain];
    self.tableView.delegate= self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    //调用系统的编辑按钮
    self.navigationItem.rightBarButtonItem = [self editButtonItem];
}

#pragma -mark 设置一个分区有多少单元格
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}
#pragma -mark 设置每个cell上面的内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //创建一个重用标识符
    static NSString * identifier = @"cell";
    //如果需要重用，就从这个cell的队列里面找标识符一样的重用
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
   
    //多种cell样式的创建方式
    if (indexPath.row>=self.dataArray.count-1)
    {
        //第二种重用标识符
        static NSString * identifier1 = @"cell1";
        //如果需要重用采用identifier1标记的cell
        UITableViewCell * cell1 = [tableView dequeueReusableCellWithIdentifier:identifier1];
        if (cell1==nil)
        {
            //创建另外一种的cell
            cell1 = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier1];
        }
        cell1.textLabel.text = @"添加";
        return cell1;
    }
    
    //如果在重用队列里面没有找到相同标识符的cell，就会创建一个cell、
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    //对cell内容的重用
    cell.textLabel.text = [self.dataArray objectAtIndex:indexPath.row];
    return cell;
}
#pragma -mark 点击编辑按钮执行的方法(第一步)
- (void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    //必须让父类也执行该方法，不然只能进入到编辑状态，不能返回原始状态
    [super setEditing:editing animated:animated];
    //点击编辑按钮的时候让表视图处于可编辑状态
    [self.tableView setEditing:editing animated:animated];
}
#pragma -mark设置单元格是否可以编辑(第二步)
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    //默认都可以编辑，如果需求为都可以编辑，该方法可以不写
//    if (indexPath.row == 4)
//    {
//        return NO;
//    }
    return YES;
}
#pragma -mark设置单元格是删除样式还是添加的样式(第三步)
-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCellEditingStyle style  = UITableViewCellEditingStyleDelete;
    if (indexPath.row == self.dataArray.count-1)
    {
        style = UITableViewCellEditingStyleInsert;
    }
    return style;
}
#pragma -mark真正的根据编辑的样式去删除和添加(第四步)
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    //删除的代码
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        //1.先从数据源中把要删除的数据删除
        [self.dataArray  removeObjectAtIndex:indexPath.row];
        //2.从UI上把表视图的单元格删了
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationRight];
    }
    //添加的时候
    else if (editingStyle == UITableViewCellEditingStyleInsert)
    {
        //1.添加数据
        [self.dataArray addObject:@"F"];
        //2.在UI上给tableView添加一个单元格
        [tableView insertRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationLeft];
    }

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
