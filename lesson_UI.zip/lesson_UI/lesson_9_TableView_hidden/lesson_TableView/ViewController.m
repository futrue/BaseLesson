//
//  ViewController.m
//  lesson_TableView
//
//  Created by lanou3g on 15/5/5.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(strong,nonatomic)UITableView * tableView;
@property(strong,nonatomic)NSMutableArray * array;
@property(strong,nonatomic)NSArray *listArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.listArray = [NSArray arrayWithObjects:
                           @"电影",@"动漫",@"原创",@"体育",@"娱乐",@"搞笑", nil];
    self.tableView= [[UITableView alloc]initWithFrame:CGRectMake(0, 20, self.view.bounds.size.width, self.view.bounds.size.height-20) style:UITableViewStylePlain];
    self.tableView.dataSource=self;
    self.tableView.delegate=self;
    [self.view addSubview:self.tableView];
    //用该数组控制分区的开和关
    //如果该分区里面有分区索引对应的数组则表示该分区是闭合状态
    self.array = [[NSMutableArray alloc]initWithObjects:[NSNumber numberWithInteger:0],
                                                        [NSNumber numberWithInteger:1],
                                                        [NSNumber numberWithInteger:2],
                                                        [NSNumber numberWithInteger:3],
                                                        [NSNumber numberWithInteger:4],
                  
                                                  [NSNumber numberWithInteger:5], nil];
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //注意死数据 活数据
    return self.listArray.count;
}
- (NSInteger )tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //将NSinteger类型的section转化为对象类型
    NSNumber * s=[NSNumber numberWithInteger:section];
    //如果该数组包含这个数字说明该分区是闭合状态
    if ([self.array containsObject:s])
    {
        return 0;
    }
    else
    {
        return 4;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell==nil)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.textLabel.text=@"123";
    return cell;
}
#pragma -mark 自定义表头的方法
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    UIButton * button =[[UIButton alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 0)];
    button.backgroundColor = [UIColor blackColor];
    [button setTitle:[self.listArray objectAtIndex:section] forState:UIControlStateNormal];
    //设置button上标题的对齐方式
    [button setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [button addTarget:self action:@selector(doButton:)
     forControlEvents:UIControlEventTouchDown];
    //添加tag标记，用来区分你点击的是哪一个按钮
    button.tag = section;
    return button;
}
#pragma -mark 平铺时给表头设置高度，表头才会出现
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}
#pragma -mark 点击分区头时执行的方法
- (void)doButton:(UIButton *)button
{
//首先根据tag值确定你当前点击的是哪一个分区
    NSNumber *t = [NSNumber numberWithInteger:button.tag];
    //判断数组里面是否包含t
    
    //如果包含t说明该数组里面有这个分区的索引
    //有这个分区的索引，能说明该分区现在时闭合状态

    NSMutableArray * indexPathArray = [[NSMutableArray alloc]init];
    for (int i=0; i<4; i++)
    {
        NSIndexPath * indexPath = [NSIndexPath indexPathForRow:i inSection:button.tag];
        [indexPathArray addObject:indexPath];
    }
    if ([self.array containsObject:t])
    {
        //删除该分区的索引，表示该分区现在已经打开了
        [self.array removeObject:t];
        //说明当前闭合状态，所以我们需要将它打开
        [self.tableView insertRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationLeft];
        
    }
    else
    {
        //将该分区的索引再添加到数组里面表示当前分区已经关闭
        [self.array addObject:t];
        //原来是打开的状态，我们需要将其关闭
        [self.tableView deleteRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationLeft];
    }
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
