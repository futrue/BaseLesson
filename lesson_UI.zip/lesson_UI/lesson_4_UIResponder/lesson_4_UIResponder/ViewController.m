//
//  ViewController.m
//  lesson_4_UIResponder
//
//  Created by lanou3g on 15/4/27.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    UILabel *_label;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /*
     1.什么是响应者？
     凡是UIResponder和他的子类对象都是响应者
     2.什么是第一响应者?
     最先检查到点击事件的控件叫做第一响应者
     3.什么是响应者链？
     View->viewController->window->AppDelegate->Application
     4.两个默认为响应者断开的控件
     静态显示文字:UILabel
     静态显示图片:UIImageView
     */
    //创建一个广告视图
    _label = [[UILabel alloc]initWithFrame:CGRectMake(100, 100, 150, 150)];
    [_label setBackgroundColor:[UIColor redColor]];
    [_label setTextAlignment:NSTextAlignmentCenter];
    [self.view addSubview:_label];
    _label.text=@"a";
    
    //创建一个关闭按钮
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundColor:[UIColor cyanColor]];
    button.frame = CGRectMake(120, 0, 30, 30);
    [button setTitle:@"X" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(doButton) forControlEvents:UIControlEventTouchDown];
    [_label addSubview:button];
    //如果要想让label具有消息传递的功能，就需要打开label的用户交互的属性
    [_label setUserInteractionEnabled:YES];
}


- (void)doButton
{
    [_label removeFromSuperview];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
