//
//  ViewController.m
//  lesson_15_JSON
//
//  Created by lanou3g on 15/5/12.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"
#import "StudentModel.h"
#import "JSONKit.h"
#import "SBJson.h"
@interface ViewController ()
@property(strong,nonatomic)NSMutableArray * allStudentArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    /*
    网络解析的过程
    1.通过网络请求，将在服务器上的数据请回到本地
    2.解析本地数据，并且在控件上使用解析好的数据
    3.JSON解析，是目前使用最多的一种解析方法，实质是一个数组或者字典
    4.在写JSON文件的时候要注意字典里面的键值对用逗号隔开，键和值用冒号连接
    */
    
     //JSON解析
     //1.使用系统自带的解析工具
     //模仿网络解析:将数据从网络上请求到本地。。。
     //2.解析本地（路径）
    NSString * filePath = [[NSBundle mainBundle]pathForResource:@"Student" ofType:@"json"];
    //3.将路径下的文件转化为一个二进制文件
    NSData * data = [NSData dataWithContentsOfFile:filePath];
    NSLog(@"data = %@",data);
//**************************使用系统自带的解析工具进行数据格式交换************************
    //真正解析的代码就这一行
/*
    //error类
    NSError *error = nil;
    NSArray * dataArray = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
    NSLog(@"dataArray = %@",dataArray);j 
    if(error)
    {
    //打印错误信息的描述（凡是error类型的参数都可以这样写）
        NSLog(@"%@",[error localizedDescription]);
    }
*/
//****************************使用JSONKit解析工具进行数据格式交换************************
/*
    NSArray *dataArray = [data objectFromJSONData];
    NSLog(@"dataArray = %@",dataArray);
*/
//*****************************使用SBJson解析工具进行数据格式交换*************************
    NSString *SBJsonStr = [[NSString alloc]initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"SBJson = %@",SBJsonStr);
    //将字符串转化为相应地格式的数据
    NSArray *dataArray= [SBJsonStr JSONValue];
    NSLog(@"dataArray = %@",dataArray);
    [SBJsonStr release];
//通过上面三种形式都可以将文本类型的json数据,转化为程序可直接使用的数组数据（所以上面的步骤叫做数据格式的转化，不叫做解析）
//解析是对数据的处理
    self.allStudentArray = [NSMutableArray array];
    for (NSDictionary * dic in dataArray)
    {
        StudentModel * stu = [[StudentModel alloc]init];
        stu.name = [dic valueForKey:@"name"];
        stu.age = [dic valueForKey:@"age"];
        stu.address = [dic valueForKey:@"address"];
        [self.allStudentArray addObject:stu];
//KVC模式(键名必须和model类的属性一致才能准确赋值)
/*
        [stu setValuesForKeysWithDictionary:dic];
        NSLog(@"stu.name=%@",stu.name);
*/
        [stu release];
    }
    //dataArray是未经处理的对象
    //allStudentArray是经过处理的数据，里面存放的全是model对象
    NSLog(@"allStudentArray = %@",self.allStudentArray);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
