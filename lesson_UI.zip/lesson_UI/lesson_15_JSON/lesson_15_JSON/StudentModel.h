//
//  Student.h
//  lesson_15_JSON
//
//  Created by lanou3g on 15/5/12.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StudentModel : NSObject
@property(strong,nonatomic)NSString * name;
@property(strong,nonatomic)NSString * age;
@property(strong,nonatomic)NSString * address;
@end
