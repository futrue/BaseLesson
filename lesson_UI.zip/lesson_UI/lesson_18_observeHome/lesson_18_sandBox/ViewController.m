//
//  ViewController.m
//  lesson_18_sandBox
//
//  Created by lanou3g on 15/5/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
#pragma -mark 视图将要出现的方法
- (void) viewWillAppear:(BOOL)animated
{
    NSFileManager * fm =[NSFileManager defaultManager];
    if ([fm fileExistsAtPath:[self filePath]])
{
    NSString * text = [NSString stringWithContentsOfFile:[self filePath] usedEncoding:NSUTF8StringEncoding error:nil];
    self.textField.text=text;
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    //注册一个通知，监听Home键有没有被点击(系统级别的单例)
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(doHome:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    
}

#pragma -mark 监听到程序进入后台时执行的方法
- (void)doHome:(NSNotification *)notification
{
    //获得文件管理者
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:[self filePath]])
    {
        [self.textField.text writeToFile:[self filePath] atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
    else
    {
        [fm createFileAtPath:[self filePath] contents:nil attributes:nil];
        [self.textField.text writeToFile:[self filePath] atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
}
#pragma -mark 获得文件路径的方法
- (NSString *)filePath
{
  //1.找到这个文件要保存的文件夹路径
    NSString * docPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    //2.在这个文件夹的下面创建一个文件路径
    NSString * filePath = [docPath stringByAppendingPathComponent:@"save.text"];
    return filePath;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
