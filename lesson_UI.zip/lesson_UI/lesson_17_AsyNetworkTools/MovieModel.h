//
//  MovieModel.h
//  UI_!7_AsyNetworkTools
//
//  Created by lanou3g on 15/5/14.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface MovieModel : NSObject
//model类提供的是应该是最终的数据
@property  (strong,nonatomic)NSString *movieId;
@property  (strong,nonatomic)NSString *movieName;
@property  (strong,nonatomic)NSString *pic_url;
//根据图片的url请求回来的最终的图片，提供给其他类使用
@property  (strong,nonatomic)UIImage *pic_image;
@end
