//
//  MyTableViewCell.m
//  UI_!7_AsyNetworkTools
//
//  Created by lanou3g on 15/5/14.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import "MyTableViewCell.h"

@implementation MyTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
