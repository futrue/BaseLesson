
//
//  AsyNetworkTools.m
//  UI_!7_AsyNetworkTools
//
//  Created by lanou3g on 15/5/14.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import "AsyNetworkTools.h"

//手动写的延展,方便创建私有方法和属性
@interface AsyNetworkTools () <NSURLConnectionDataDelegate>
//用来接收异步请求得到的最终数据
@property (strong,nonatomic)NSMutableData *receiveData;




@end

@implementation AsyNetworkTools
-(id)initWithURlString:(NSString *)urlString
{
    if ([super init])
    {
        //1.根据外面传递过来的字符串创建一个url
        NSURL *url=[NSURL URLWithString:urlString];
        //2.根据一个url创建一个request
        NSURLRequest *request=[NSURLRequest requestWithURL:url];
        //3.设置代理并且发送异步请求
        [NSURLConnection connectionWithRequest:request delegate:self];
    }
    return self;
}
#pragma -mark异步请求的代理方法
#pragma  -mark ---收到响应时的执行方法
-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //初始化接收数据的data
    self.receiveData=[NSMutableData data];
}
#pragma -mark ---正在接收时执行
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //数据拼接
    [self.receiveData appendData:data];
}
#pragma -mark ---结束时执行
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    //使用系统json工具进行格式转换
    NSDictionary *dic=[NSJSONSerialization JSONObjectWithData:self.receiveData options:NSJSONReadingMutableContainers error:nil];
    //属性传值
    //self.dic=dic;
    //NSLog(@"dic=%@",dic);
    
    //代理传值
    //为什么要在这里写?
    //1.因为拿到数据之后再让代理去执行方法,这样才会有数据
    if (self.delegate!=nil && [self.delegate respondsToSelector:@selector(asyResult:)])
    {
        //2.代理去调用asyResult这个方法,所以代理这个类必须要有asyResult:这个方法 ,不让会崩溃
        [self.delegate asyResult:dic];
    }
}
#pragma -mark  ---出错时执行
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    
}



@end
