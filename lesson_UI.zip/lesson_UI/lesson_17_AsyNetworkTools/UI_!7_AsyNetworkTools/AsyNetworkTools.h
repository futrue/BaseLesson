//
//  AsyNetworkTools.h
//  UI_!7_AsyNetworkTools
//
//  Created by lanou3g on 15/5/14.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol AsyNetworkToolsDelegate <NSObject>
@optional
//id类型 通用 协议传值方法,将需要传的值当做协议方法的参数,就OK
-(void)asyResult:(id)result;

@end

//就相当于委托方法,给其他类提供数据服务
@interface AsyNetworkTools : NSObject <NSURLConnectionDataDelegate>
//@property (strong ,nonatomic)NSDictionary *dic;
@property (weak,nonatomic)id<AsyNetworkToolsDelegate>delegate;




#pragma -mark根据一个url字符串创建一个异步请求类的对象
-(id)initWithURlString:(NSString *)urlString;

@end
