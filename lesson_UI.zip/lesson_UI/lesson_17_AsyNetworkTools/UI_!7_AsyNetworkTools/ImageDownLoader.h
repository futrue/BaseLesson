//
//  ImageDownLoader.h
//  UI_!7_AsyNetworkTools
//
//  Created by lanou3g on 15/5/14.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import <Foundation/Foundation.h>

//这个框架才能使用UI系列
#import <UIKit/UIKit.h>

typedef void(^Result)(UIImage *img);

@interface ImageDownLoader : NSObject
//声明一个block用来做传值使用
+ (void)imageDownLoaderWithUrlString:(NSString *)urlString andResult:(Result)result;

@end
