//
//  ViewController.m
//  UI_!7_AsyNetworkTools
//
//  Created by lanou3g on 15/5/14.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//
#define url1 @"http://project.lanou3g.com/teacher/yihuiyun/lanouproject/movielist.php"

#import "ViewController.h"
#import "AsyNetworkTools.h"
#import "MyTableViewCell.h"
#import "MovieModel.h"

//因为AsyNEtworkToolsdelegate这个协议是在AsyNetworkTool.h的模板里声明的,所以不用再导入这个类了
@interface ViewController ()<AsyNetworkToolsDelegate>
//用来存放网络请求回来的属性
@property (strong,nonatomic)NSDictionary *dic;
@property (strong,nonatomic)NSMutableArray *array;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //这里不会执行异步请求的协议方法,协议方法会在该方法执行完毕后才会执行(协议方法),所以这里的属性没有值,也就意味着,通过属性把值传递过来的方法不可行.
    AsyNetworkTools *asy=[[AsyNetworkTools alloc]initWithURlString:url1];
    asy.delegate=self;
    self.dic=[NSDictionary dictionary];
    self.array=[NSMutableArray array];
    //对Xib创建的cell注册
    [self.myTableView  registerNib:[UINib nibWithNibName:@"MyTableViewCell" bundle:nil] forCellReuseIdentifier:@"cell"];
    
//   NSLog(@"asy.dic=%@",asy.dic);
    
    
}
-(void)asyResult:(id)result
{
    //该方法并没有在这个方法里面直接调用
    //在AsyNetworkTools这个类里面,数据请求完毕的时候,等于自己去调用.
    self.dic=(NSDictionary*)result;
    //数据解析
    NSArray *resultArray=[self.dic valueForKey:@"result"];
    //对resultArray的解析
    for (NSDictionary *indic in resultArray) {
        //创建model类对象
        MovieModel *m=[[MovieModel alloc]init];
        //通过KVC对model快速赋值
        [m setValuesForKeysWithDictionary:indic];
        [self.array addObject:m];
        
    }
    //拿到数据之后,刷新表视图.
    [self.myTableView reloadData];
   
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.array count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    //使用Xib就不用再开辟空间
    MyTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    MovieModel *movie=[self.array objectAtIndex:indexPath.row];
    cell.nameLabel.text=movie.movieName;
    cell.IDlabel.text=movie.movieId;
    //对于图片要特殊处理
    if (movie.pic_image!=nil)
    {
        //如果图片已经请求回来了就直接赋值
        cell.myImageView.image = movie.pic_image;
    }
    else
    {
        //图片还没有请求回来的时候
    /*
        1.我们使用KVO来时刻监听图片下载，一旦下载好了，我们就把下载好的图片再贴到表视图上
        movie:被观察者
        KeyPath:观察的属性
        options:要观察的是新值还是旧值
        context:附加信息(通常用来传值)
    */
        [movie addObserver:self forKeyPath:@"pic_image" options:NSKeyValueObservingOptionNew context:(__bridge void *)(indexPath)];
    }
    return cell;
}
#pragma -mark当被观察的属性发生改变的时候就会执行该方法
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    //当图片下载好了，观察者就会自动执行该方法
    //我们把下载好的图片重新贴在cell上
    if ([keyPath isEqualToString:@"pic_image"])
    {
        //1.将下载好的图片先取出来(对应NSKeyValueObservingOptionNew)
        UIImage * image = [change valueForKey:NSKeyValueChangeNewKey];
        //2.获取cell的indexPath
        NSIndexPath *indexPath = (__bridge NSIndexPath *)(context);
        //3.根据indexPath找到相应的cell
        MyTableViewCell * cell = [self.myTableView cellForRowAtIndexPath:indexPath];
        //4.对cell重新添加图片
        cell.myImageView.image = image;
        //5.刷新该cell
        [self.myTableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        //6.移除观察者
        [object removeObserver:self forKeyPath:keyPath];
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 130;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
