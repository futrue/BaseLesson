//
//  ImageDownLoader.m
//  UI_!7_AsyNetworkTools
//
//  Created by lanou3g on 15/5/14.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import "ImageDownLoader.h"

@implementation ImageDownLoader
+ (void)imageDownLoaderWithUrlString:(NSString *)urlString andResult:(Result)result
{
    NSURL * url = [NSURL URLWithString:urlString];
    NSURLRequest * request = [NSURLRequest requestWithURL:url];
    //发送异步链接
    //参数1:发送的参数是什么
    //参数2:在哪个线程中进行数据请求(新开辟一个线程)
    //参数3:block块，当数据请求完成时才会进到block里面
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *data, NSError *connectionError)
    {
        //请求完成时才会进来，这里的data就是我们想要的数据
        UIImage * image = [UIImage imageWithData:data];
        //通过block传递出去
        result(image);
    }];
    /*
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue new] completionHandler:
     ^(NSURLResponse *response, NSData *data, NSError *connectionError)
     {
         //请求完成时才会进来，这里的data就是我们想要的数据
         UIImage * image = [UIImage imageWithData:data];
         //通过block传递出去
         result(image);
     }];
    */
}
@end
