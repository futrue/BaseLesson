//
//  MovieModel.m
//  UI_!7_AsyNetworkTools
//
//  Created by lanou3g on 15/5/14.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import "MovieModel.h"
#import "ImageDownLoader.h"
@implementation MovieModel
#pragma -mark重写set方法
//想在这个过渡数据赋值的时候，直接得到想要的最终数据
- (void)setPic_url:(NSString *)pic_url
{
    //不能使用.语法，因为.语法本身就是调用set方法,会形成死循环
    _pic_url =pic_url;
    //__block 用来解决在block中使用self
    __block MovieModel *weakModel =self;
    [ImageDownLoader imageDownLoaderWithUrlString:pic_url andResult:^(UIImage *img) {
        //用法错误，会造成循环引用
        //self.pic_image = img;
        weakModel.pic_image = img;
    }];
}

@end
