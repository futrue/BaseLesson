//
//  ViewController.m
//  lesson_15_XML
//
//  Created by lanou3g on 15/5/12.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"
#import "GDataXMLNode.h"
#import "StudentModel.h"
#import "StudentModel.h"
@interface ViewController ()<NSXMLParserDelegate>//xml SAX解析的协议
@property(strong,nonatomic)NSMutableArray * allStudentArray;
//用该属性记录目前正在解析哪一个节点
@property(strong,nonatomic)NSString * currentElement;
@property(strong,nonatomic)StudentModel * student;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.allStudentArray = [NSMutableArray array];
//**********************************1.DOM**************************************

    /*
     GData准备工作
     1.需要添加一个libxml2.dylib静态库
     2.Build Setting里面找到在Header Search Paths 在第三项里面添加/usr/include/libxml2这个配置
     3.在Build Setting里面找到Other Linker Flags添加-lxml2这个配置
     4.GDataXMLNode这个第三方是一个MRC的工程，在ARC中使用需要标记一下
     */
/*
    //1.找到XML文件路径
    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"Student" ofType:@"xml"];
    //2.用该文件路径创建一个xml类型的字符串
    NSString * xmlStr = [[NSString alloc]initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"xmlStr=%@",xmlStr);
    //3.将xml类型的字符串，转化为整个xml类型的数据(拿到整个xml文件)
    GDataXMLDocument *document = [[GDataXMLDocument alloc]initWithXMLString:xmlStr options:0 error:nil];
    NSLog(@"document=%@",document);
    //4.根据整个xml文件获取xml文件的根节点
    GDataXMLElement * rootElement = [document rootElement];
    NSLog(@"rootElement=%@",rootElement);
    //5.根据节点的名字一层一层的剥开，得到你想要的数据(解析数据)
    NSArray * StudentsArray = [rootElement elementsForName:@"Stu"];
    //NSLog(@"StudentsArray=%@",[[StudentsArray objectAtIndex:0] stringValue]);
    for (int i= 0; i<[StudentsArray count]; i++)
    {
        //剥到Stu这一层了
        GDataXMLElement * Stu= [StudentsArray objectAtIndex:i];
        //创建StudentModel类的对象
          StudentModel * student = [[StudentModel alloc]init];
        
        NSArray * stuNameArray = [Stu elementsForName:@"name"];
        // NSLog(@"stuNameArray = %@",stuNameArray);
        for (int j =0; j<stuNameArray.count; j++)
        {
            GDataXMLElement *name = [stuNameArray objectAtIndex:j];
            //拿到name这个节点了，取值
            NSLog(@"name的值为%@",[name stringValue]);
            
            //给StudentModel类的对象赋值
            student.name = [name stringValue];
            //将赋完值的model类对象存在数组里面就可以在外部赋值了
            [self.allStudentArray addObject:student];
        }
    }
*/
//**********************************2.SAX**************************************
    //1.找到文件路径
    NSString * filePath = [[NSBundle mainBundle]pathForResource:@"Student" ofType:@"xml"];
    //2.用路径创建一个data
    NSData * XMLData = [[NSData alloc]initWithContentsOfFile:filePath];
    //3.用data数据创建一个xml解析对象
    NSXMLParser * xmlParser = [[NSXMLParser alloc]initWithData:XMLData];
    xmlParser.delegate = self;
    //4.开始执行解析
    [xmlParser parse];
   
}
#pragma -mark NSParserDelegate协议方法
#pragma -mark开始解析文件的时候执行的方法
- (void)parserDidStartDocument:(NSXMLParser *)parser
{
    NSLog(@"开始解析文件了");
}
#pragma -mark已经开始解析标签（节点）的时候执行的方法
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    self.currentElement = elementName;
    NSLog(@"开始标签%@",elementName);
}
#pragma -mark 取值的方法
- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    //如果当前解析的节点为Stu这个节点，并且为开始标签的时候
    if ([self.currentElement isEqualToString:@"Stu"]&&string.length!=0)
    {
        self.student = [[StudentModel alloc]init];
    }
    //如果当前解析的节点为name这个节点，并且name没有值的时候
    if ([self.currentElement isEqualToString:@"name"]&&self.student.name==nil)
    {
        self.student.name= string;
    }
}
#pragma -mark 解析结束标签的时候执行的方法
- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if ([elementName isEqualToString:@"Stu"])
    {
        [self.allStudentArray addObject:self.student];
    }
    NSLog(@"结束标签%@",elementName);
    
}
#pragma -mark整个xml文件解析结束时执行的方法
- (void)parserDidEndDocument:(NSXMLParser *)parser
{
    for (int i =0; i<[self.allStudentArray count]; i++)
    {
        NSLog(@"name=%@",[[self.allStudentArray objectAtIndex:i] name]);
    }
    NSLog(@"xml文件解析完毕");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
