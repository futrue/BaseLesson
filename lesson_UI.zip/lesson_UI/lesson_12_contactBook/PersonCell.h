//
//  PersonCell.h
//  UI_12_通讯录
//
//  Created by lanou3g on 15/5/7.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Person.h"
@interface PersonCell : UITableViewCell
@property(strong,nonatomic)UIImageView * personImage;//头像
@property(strong,nonatomic)UILabel * nameLabel;
@property(strong,nonatomic)UILabel * addressLabel;
@property(strong,nonatomic)UILabel * phoneLabel;
@property(strong,nonatomic)Person * p;
@end
