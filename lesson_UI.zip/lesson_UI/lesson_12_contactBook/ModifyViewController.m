//
//  ModifyViewController.m
//  UI_12_通讯录
//
//  Created by lanou3g on 15/5/7.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ModifyViewController.h"

@interface ModifyViewController ()

@end

@implementation ModifyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blueColor];
    [self modifyView];
    self.edgesForExtendedLayout = UIRectEdgeNone;

}
- (void)modifyView
{
    //头像
    self.imageView = [[UIImageView alloc]initWithFrame:CGRectMake(100, 50, self.view.bounds.size.width-200, 150)];
    self.imageView.image = [UIImage imageNamed:self.p.imageName];
    [self.view addSubview:self.imageView];
    //名字
    UILabel * nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 230, 60, 40)];
    [nameLabel setText:@"姓名"];
    [self.view addSubview:nameLabel];
    self.userNametf = [[UITextField alloc]initWithFrame:CGRectMake(150, 230, 150, 40)];
    self.userNametf.text = self.p.name;
    self.userNametf.borderStyle = UITextBorderStyleRoundedRect;
    [self.view addSubview:self.userNametf];
    //地址
    UILabel * addLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 300, 60, 40)];
    [addLabel setText:@"住址"];
    [self.view addSubview:addLabel];
    self.userAddresstf = [[UITextField alloc]initWithFrame:CGRectMake(150, 300, 150, 40)];
    self.userAddresstf.text = self.p.address;
    self.userAddresstf.borderStyle = UITextBorderStyleRoundedRect;
    [self.view addSubview:self.userAddresstf];
    //联系方式
    UILabel * phoneLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 370, 60, 40)];
    [phoneLabel setText:@"手机号"];
    [self.view addSubview:phoneLabel];
    self.userPhonetf = [[UITextField alloc]initWithFrame:CGRectMake(150, 370, 150, 40)];
    self.userPhonetf.text = self.p.phone;
    self.userPhonetf.borderStyle = UITextBorderStyleRoundedRect;
    [self.view addSubview:self.userPhonetf];
    //取消按钮
    UIButton * cancelBtn = [[UIButton alloc]initWithFrame:CGRectMake(60, 440, self.view.bounds.size.width-120, 40)];
    [cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
    cancelBtn.backgroundColor = [UIColor redColor];
    [cancelBtn addTarget:self action:@selector(doCancel:) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:cancelBtn];
    
    //保存按钮
    UIButton * sureBtn = [[UIButton alloc]initWithFrame:CGRectMake(60, 510, self.view.bounds.size.width-120, 40)];
    [sureBtn setTitle:@"保存" forState:UIControlStateNormal];
    sureBtn.backgroundColor = [UIColor redColor];
    [sureBtn addTarget:self action:@selector(doSure:) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:sureBtn];

}
#pragma -mark点击取消按钮执行的方法
- (void)doCancel:(UIButton *)button
{
    [self.navigationController popViewControllerAnimated:YES ];
}
#pragma -mark点击保存执行的方法
- (void)doSure:(UIButton *)button
{
    
    self.p.name = self.userNametf.text;
    self.p.address = self.userAddresstf.text;
    self.p.phone = self.userPhonetf.text;
    
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
