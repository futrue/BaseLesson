//
//  searchViewController.h
//  UI_12_通讯录
//
//  Created by lanou3g on 15/5/7.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface searchViewController : UIViewController<UITextFieldDelegate>
@property(strong,nonatomic)NSArray * array;
@end
