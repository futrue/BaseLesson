//
//  ModifyViewController.h
//  UI_12_通讯录
//
//  Created by lanou3g on 15/5/7.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Person.h"
#import "PersonManager.h"
@interface ModifyViewController : UIViewController
@property(strong,nonatomic)UIImageView * imageView;
@property(strong,nonatomic)UITextField * userNametf;
@property(strong,nonatomic)UITextField * userAddresstf;
@property(strong,nonatomic)UITextField * userPhonetf;
@property(strong,nonatomic)Person * p;
@end
