//
//  PersonManager.m
//  UI_12_通讯录
//
//  Created by lanou3g on 15/5/7.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import "PersonManager.h"
#import "ChineseToPinyin.h"
#import <UIKit/UIKit.h>
@implementation PersonManager

+ (id)singlePersonManager
{
    static PersonManager * pm = nil;
    //在多线程中要加线程锁
    if (pm==nil)
    {
        pm = [[PersonManager alloc]init];
        //让数据管理者创建的时候就把数据从plist文件里面读取出来，这样外面就可以直接使用
        [pm readData];
    }
    return pm;
}
//用数据管理者将数据从plist文件里面读取出来
- (void)readData
{
    //获得plist文件的路径
    NSString * filePath = [[NSBundle mainBundle]pathForResource:@"Student" ofType:@"plist"];
    //全部数据
    NSDictionary * dic = [NSDictionary dictionaryWithContentsOfFile:filePath];
    self.allSectionArray = [NSMutableArray arrayWithArray:[dic allKeys]];
    //因为通信录通常都会按照字母来排序显示(默认是升序排列)
    [self.allSectionArray sortUsingSelector:@selector(compare:)];
    //对数据进行筛选
    self.allPersonDic = [NSMutableDictionary dictionary];
    //一个分区一个分区的遍历
    for (NSString * key in self.allSectionArray)
    {
        //为每个分区创建自己的数组
        NSMutableArray * groupArray = [NSMutableArray array];
        //在某个分区中把该分区的所有人都找出来
        for (NSDictionary * personDic in dic[key])
        {
            //创建一个model类对象
            Person * p = [[Person alloc]init];
            //将从plist里面对取出来的数据赋值给model类
            p.name=[personDic valueForKey:@"name"];
            p.address=[personDic valueForKey:@"QQ"];
            p.imageName=[personDic valueForKey:@"image"];
            p.phone=[personDic valueForKey:@"phoneNumber"];
            //在一个分区里面每找一个人，就放在数组里面
            [groupArray addObject:p];
        }
        //dic里面存放的是未处理的字典类型的数据
        //self.allPersonDic里面存放的是model类的对象
        [self.allPersonDic setObject:groupArray forKey:key];
    }
}
- (NSInteger)rowsInSection:(NSInteger)section
{
    NSString * key = [self.allSectionArray objectAtIndex:section];
    return [[self.allPersonDic valueForKey:key]count];
}
- (Person *)personWithSection:(NSInteger)section andRow:(NSInteger)row
{
    //先找到分区
    NSString * key = [self.allSectionArray objectAtIndex:section];
    NSArray * array = [self.allPersonDic valueForKey:key];
    //在分区内找到具体的人
    return [array objectAtIndex:row];
}
- (void)addPerson:(Person *)p
{
    //1.得到该联系人的姓名的首字母
    NSString * firstchar = [[ChineseToPinyin pinyinFromChiniseString:p.name]
                            substringToIndex:1];
    //2.判断该分区是否存在
    if (![self.allSectionArray containsObject:firstchar])
    {
        //1.为该字母创建一个分区数组
        [self.allPersonDic setObject:[NSMutableArray array] forKey:firstchar];
        //2.分区数组也要添加这个分区字母
        [self.allSectionArray addObject:firstchar];
        //3.分区要重新排序
        [self.allSectionArray sortUsingSelector:@selector(compare:)];
    }
    [[self.allPersonDic valueForKey:firstchar] addObject:p];
}
#pragma -mark删除联系人的方法(根据返回值判断是否也要删除该分区)
- (BOOL)deletePerson:(NSIndexPath *)indexPath
{
    //1.找到分区对应的key
    NSString * key = [self.allSectionArray objectAtIndex:indexPath.section];
    //2.根据key找到对应的分区数组
    NSMutableArray * groupArray =[self.allPersonDic valueForKey:key];
    //3.在这个数组中找到要删除的人
    Person * p = [groupArray objectAtIndex:indexPath.row];
    //4.删除该人
    [groupArray removeObject:p];
    //5.判断是否需要删分区
    if(groupArray.count==0)
    {
        //先删除该key对应的value
        [self.allPersonDic removeObjectForKey:key];
        //再把这个key删除
        [self.allSectionArray removeObject:key];
        //分区的数据已经删除(说明该分区都要被删除)
        return YES;
    }
    return NO;
}
#pragma -mark返回全部联系人的姓名的数组
- (NSMutableArray *)personName
{
    NSMutableArray * personNameArray = [NSMutableArray array];
    for (NSString * key in self.allSectionArray)
    {
        for (Person * p in [self.allPersonDic valueForKey:key])
        {
            [personNameArray addObject:p.name];
        }
    }
    return personNameArray;
}


















@end
