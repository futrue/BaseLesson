//
//  Person.h
//  UI_12_通讯录
//
//  Created by lanou3g on 15/5/7.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
@property(strong,nonatomic)NSString * name;
@property(strong,nonatomic)NSString * address;
@property(strong,nonatomic)NSString * phone;
@property(strong,nonatomic)NSString * imageName;


@end
