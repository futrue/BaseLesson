//
//  PersonManager.h
//  UI_12_通讯录
//
//  Created by lanou3g on 15/5/7.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
@interface PersonManager : NSObject
@property(strong,nonatomic)NSMutableDictionary * allPersonDic;
@property(strong,nonatomic)NSMutableArray * allSectionArray;
#pragma -mark创建单例的方法
+ (id)singlePersonManager;
#pragma -mark根据分区查找该分区有多少个cell
- (NSInteger)rowsInSection:(NSInteger)section;
#pragma -mark根据indexPath在数据中找到想要的人
- (Person *)personWithSection:(NSInteger)section andRow:(NSInteger)row;
#pragma -mark添加联系人的方法
-(void)addPerson:(Person *)p;
#pragma -mark删除联系人的方法(根据返回值判断是否也要删除该分区)
- (BOOL)deletePerson:(NSIndexPath *)indexPath;


#pragma -mark修改联系人信息
//-(void)modifyPersonInforWithIndexPath:(NSIndexPath*)indexPath;

#pragma -mark返回全部联系人的姓名的数组
- (NSMutableArray *)personName;
@end
