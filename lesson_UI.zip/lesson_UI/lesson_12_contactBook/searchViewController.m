//
//  searchViewController.m
//  UI_12_通讯录
//
//  Created by lanou3g on 15/5/7.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import "searchViewController.h"
#import "PersonManager.h"
#import "ModifyViewController.h"
@interface searchViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(strong,nonatomic)UITableView * tableView;
@property(strong,nonatomic)UITextField * textField;
@end

@implementation searchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.array = [[PersonManager singlePersonManager] personName];
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 40, self.view.bounds.size.width, self.view.bounds.size.height-94) style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate  = self;
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self.view addSubview:self.tableView];
    [self layoutSearchTf];
}
#pragma -mark tableView代理的方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   
    return self.array.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * identifier = @"cell";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell==nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.textLabel.text = [self.array objectAtIndex:indexPath.row];
    return cell;
}

#pragma -mark 搜索框的设置
- (void)layoutSearchTf
{
    self.textField = [[UITextField alloc]initWithFrame:CGRectMake(10, 0, self.view.bounds.size.width-20, 40)];
    self.textField.placeholder = @"搜索";
    self.textField.delegate = self;
    self.textField.borderStyle = UITextBorderStyleRoundedRect;
    [self.textField addTarget:self action:@selector(doTextField ) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:self.textField];
}
- (void)doTextField
{
    NSString * string = [NSString stringWithFormat:@"self like[c]'%@*'",self.textField.text];
    NSPredicate *pre = [NSPredicate predicateWithFormat:string];
    self.array = [[[PersonManager singlePersonManager] personName] filteredArrayUsingPredicate:pre];
    [self.tableView reloadData];
}
#pragma -mark点击return键关闭键盘
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    return [textField resignFirstResponder];
}
#pragma -mark点击单元格执行的方法
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ModifyViewController *modifyView = [[ModifyViewController alloc]init];
    for (NSString * key in [[PersonManager singlePersonManager] allSectionArray])
    {
        for (Person * p in [[[PersonManager singlePersonManager] allPersonDic] valueForKey:key])
        {
            if ([p.name isEqualToString:[self.array objectAtIndex:indexPath.row]])
            {
                modifyView.p = p;
            }
        }
    } 
    [self.navigationController pushViewController:modifyView animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
