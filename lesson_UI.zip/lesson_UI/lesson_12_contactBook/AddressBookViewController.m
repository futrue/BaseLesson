//
//  AddressBookViewController.m
//  UI_12_通讯录
//
//  Created by lanou3g on 15/5/7.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "AddressBookViewController.h"
#import "AddViewController.h"
#import "PersonManager.h"
#import "PersonCell.h"
#import "ModifyViewController.h"
#import "Person.h"
#import "searchViewController.h"
@interface AddressBookViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(strong,nonatomic)UITableView * tableView;
@end

@implementation AddressBookViewController

#pragma -mark视图将要出现时执行的方法
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //页面刷新必备
    [self.tableView reloadData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
    //设置导航栏的标题
    self.navigationItem.title=@"通讯录";
    //添加联系人的item
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:(UIBarButtonSystemItemAdd) target:self action:@selector(doAdd)];
    //添加编辑按钮
    self.navigationItem.rightBarButtonItem = self.editButtonItem;

//    NSDictionary * dic = [[PersonManager singlePersonManager] allPersonDic];
//    NSLog(@"dic=%@",dic);
  
    //创建表视图
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 40, self.view.bounds.size.width, self.view.bounds.size.height-94) style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate  = self;
    [self.view addSubview:self.tableView];
    //让表视图从导航栏的下面开始显示
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self searchPerson];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    return [[PersonManager singlePersonManager]rowsInSection:section];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * identifier = @"cell";
    PersonCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell==nil)
    {
        cell = [[PersonCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier ];
    }
    cell.p =[[PersonManager singlePersonManager] personWithSection:indexPath.section andRow:indexPath.row];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [[[PersonManager singlePersonManager] allSectionArray] count];
}
#pragma -mark 添加按钮执行方法
-(void)doAdd
{
    AddViewController *add=[[AddViewController alloc]init];
    [self presentViewController:add animated:YES completion:nil];
    
}
#pragma -mark让其触发编辑状态
- (void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    [super setEditing:editing animated:animated];
    [self.tableView setEditing:editing animated:animated];
}
#pragma -mark返回分区头的方法
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [[[PersonManager singlePersonManager] allSectionArray] objectAtIndex:section];
}

#pragma -mar设置右边快速索引栏
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return [[PersonManager singlePersonManager] allSectionArray];
}

#pragma -mark真正根据编辑样式去操作
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle==UITableViewCellEditingStyleDelete)
    {
       BOOL result= [[PersonManager singlePersonManager] deletePerson:indexPath];
        if (result==NO)
        {
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        }
        else
        {
            //需要删除分区
            [tableView deleteSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationLeft];
        }
    }
}
   
#pragma -mark点击单元格执行的方法
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ModifyViewController *modifyView = [[ModifyViewController alloc]init];
    modifyView.p =[[PersonManager singlePersonManager]
                 personWithSection:indexPath.section andRow:indexPath.row];
    [self.navigationController pushViewController:modifyView animated:YES];
}

#pragma -mark搜索联系人
- (void)searchPerson
{
    self.textField = [[UITextField alloc]initWithFrame:CGRectMake(10, 0, self.view.bounds.size.width-20, 40)];
    self.textField.placeholder = @"搜索";
    self.textField.borderStyle = UITextBorderStyleRoundedRect;
    [self.textField addTarget:self action:@selector(doTextField ) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:self.textField];
}
- (void)doTextField
{
    searchViewController * searchView = [[searchViewController alloc]init];
    [self.navigationController pushViewController:searchView   animated:YES];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
