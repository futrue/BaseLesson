//
//  PersonCell.m
//  UI_12_通讯录
//
//  Created by lanou3g on 15/5/7.
//  Copyright (c) 2015年 于吉祥♎️. All rights reserved.
//

#import "PersonCell.h"

@implementation PersonCell
@synthesize p=_p;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if ([super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        [self layoutAllView];
    }
    return self;
}
#pragma -mark对cell上的子视图进行排版的方法
- (void)layoutAllView
{
    //头像
    self.personImage = [[UIImageView alloc]initWithFrame:CGRectMake(1, 2, 98, 96) ];
    [self.personImage setBackgroundColor:[UIColor clearColor]];
    [self.contentView addSubview:self.personImage];
    //名字
    self.nameLabel= [[UILabel alloc]initWithFrame:CGRectMake(110, 2, 200, 30)];
    self.nameLabel.font = [UIFont systemFontOfSize:20];
    [self.contentView addSubview:self.nameLabel];
    
    //地址
    self.addressLabel = [[UILabel alloc]initWithFrame:CGRectMake(110, 35, 200, 30)];
    [self.contentView addSubview:self.addressLabel];
    //电话
    self.phoneLabel = [[UILabel alloc]initWithFrame:CGRectMake(110, 68, 200, 30)];
    [self.contentView addSubview:self.phoneLabel];
}
#pragma -mark重写set方法，在对cell赋值的时候整体一起赋值(还可以当属性使用)
- (void)setP:(Person *)p
{
    //在MRC中的写法
    /*
     [_p release];
     _p=[p retain];
     */
    //赋值
    self.personImage.image = [UIImage imageNamed:p.imageName];
    self.phoneLabel.text = p.phone;
    self.addressLabel.text = p.address;
    self.nameLabel.text = p.name;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
