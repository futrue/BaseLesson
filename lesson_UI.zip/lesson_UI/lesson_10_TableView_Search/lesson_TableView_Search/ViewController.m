//
//  ViewController.m
//  lesson_TableView_Search
//
//  Created by lanou3g on 15/5/5.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(strong,nonatomic)UITableView * tableView;
@property(strong,nonatomic)NSMutableArray * array;
@property(strong,nonatomic)UITextField * textField;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.array = [[NSMutableArray alloc]initWithArray:[UIFont familyNames]];
    
    self.textField = [[UITextField alloc]initWithFrame:CGRectMake(30, 30, self.view.bounds.size.width-60, 35)];
    self.textField.borderStyle = UITextBorderStyleRoundedRect;
    self.textField.returnKeyType = UIReturnKeySearch;
    //根据编辑状态的改变来触发事件
    [self.textField addTarget:self action:@selector(doTextField:) forControlEvents:UIControlEventEditingChanged];
    [self.view addSubview:self.textField];
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 65, self.view.bounds.size.width, self.view.bounds.size.height-65)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}
- (void)doTextField:(UITextField *)textField
{
    NSLog(@"123");
    //self 指当前要搜索的对象
    //like 模糊查询的关键字
    // * 表示统配
    //1.创建一个字符串类型的搜索语句
    NSString * string = [NSString stringWithFormat:@"self like[c]'%@*'",textField.text];
    //2.搜索的规则
    NSPredicate *pre = [NSPredicate predicateWithFormat:string];
    //3.把搜索出来的结果重新赋值给self.array，因为表视图呈现数组都是通过self.array
    self.array=(NSMutableArray *)([[UIFont familyNames]filteredArrayUsingPredicate:pre]);
    //4.刷新表视图
    [self.tableView reloadData];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.array.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * identifier = @"cell";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell==nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.textLabel.text = [self.array objectAtIndex:indexPath.row];
    return cell;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
