//
//  secondViewController.m
//  lesson_UINavigation
//
//  Created by lanou3g on 15/5/1.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "secondViewController.h"
#import "thirdViewController.h"
@interface secondViewController ()

@end

@implementation secondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor blueColor]];
    /*
     1.如果上一页的title没有设置，系统会默认创建一个back返回按钮
     2.如果我们在上一页创建了title，那么系统就会自动的将该标题当做下一页的返回按钮
     3.自定义返回按钮，先隐藏原来的系统item，再自己创建一个item
     */
    //自定义返回按钮
    [self.navigationItem setHidesBackButton:YES];
    UIBarButtonItem *leftBtn = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(doBack)];
    self.navigationItem.leftBarButtonItem = leftBtn;
   //
    UIBarButtonItem *right = [[UIBarButtonItem alloc]initWithTitle:@"->" style:UIBarButtonItemStylePlain target:self action:@selector(doNext)];
    self.navigationItem.rightBarButtonItem = right;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    }



- (void)doBack
{
    //返回到上一个页面
    [self.navigationController popViewControllerAnimated:YES];
}
//- (void)dealloc
//{
//    NSLog(@"第二个页面已经被释放");
//    [super dealloc];
//}


- (void)doNext
{
    thirdViewController *third = [[thirdViewController alloc]init];
    [self.navigationController pushViewController:third animated:YES];
}











/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
