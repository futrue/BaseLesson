//
//  AppDelegate.m
//  lesson_UINavigation
//
//  Created by lanou3g on 15/5/1.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //创建一个window
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    [self.window makeKeyAndVisible];
    [self.window setBackgroundColor:[UIColor redColor]];
    
    //单一页面时(视图控制器没有推到下一页面的功能)
    /*
    RootViewController * rootView = [[RootViewController alloc]init];
    //将该视图控制器赋值给window当做根视图控制器
    self.window.rootViewController = rootView;
    //不用的地方及时释放
    [rootView release];
    */
    //多页面交互时
    //导航控制器具有多个页面交互的功能(相互推)
    //1.创建一个视图控制器，用来当做导航控制器的根视图控制器来使用
    RootViewController *root = [[RootViewController alloc]init];
    //2.创建导航控制器
    UINavigationController *nav = [[UINavigationController alloc]
                                   initWithRootViewController:root];
    //当对于导航条的共同特性(每个页面中都需要的特性)可以用导航控制器对象统一设置，如果是页面独有的特性，就要在页面内自己去设置
    //这是设置导航栏y的起点坐标系
    //nav.navigationBar.translucent = NO;
    //3.让导航控制器当做window的根视图控制器
    self.window.rootViewController = nav;
    
    [root release];
    [nav release];
   
    
    
    
    
    
    
    
    
    
    
    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
