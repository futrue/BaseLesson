//
//  RootViewController.m
//  lesson_UINavigation
//
//  Created by lanou3g on 15/5/1.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "RootViewController.h"
#import "secondViewController.h"
@interface RootViewController ()

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor cyanColor]];
    [self navigationBar];
    [self navigatioItem];
}
#pragma -mark关于导航栏的相关知识
-(void)navigationBar
{
    /*
     1.style
     2.translucent
     3.背景色
     4.背景图(64 44)
    */
    UIView *aView =[[UIView alloc]initWithFrame:CGRectMake(65, 0, self.view.bounds.size.width-130, 200)];
    [aView setBackgroundColor:[UIColor purpleColor]];
    [self.view addSubview:aView];
    //设置导航条的barStyle和translucent
    //第一种:系统默认
    /*
     self.navigationController.navigationBar.barStyle=UIBarStyleDefault;
     self.navigationController.navigationBar.translucent = YES;
     */
    //第二种:(translucent改变坐标系)
    /*
     self.navigationController.navigationBar.barStyle=UIBarStyleDefault;
     self.navigationController.navigationBar.translucent = NO;
     */
    //第三种
    /*
     self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
     self.navigationController.navigationBar.translucent = YES;
     */
    //第四种
    /*
     self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
     self.navigationController.navigationBar.translucent = YES;
     */
    //如果使用该方法来设置让内容从导航栏下面来显示的话，需要在每个页面中都写，简单的方法是将该方法写在一个父类里面，然后让所有需要该功能的的视图控制器，都继承这个父类
    self.navigationController.edgesForExtendedLayout = UIRectEdgeNone;
    //添加一个背景色
    self.navigationController.navigationBar.backgroundColor = [UIColor redColor];
   
    //添加背景图片
    //64
    /*
     [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"NavBar_64.png"] forBarMetrics:UIBarMetricsDefault];
     */
    //44
    /*
     [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"NavBar_44.png"] forBarMetrics:UIBarMetricsDefault];
     */
    //30
    /*
    [self.navigationController.navigationBar setBackgroundImage:[ UIImage imageNamed:@"NavBar_30@2x.png"] forBarMetrics:UIBarMetricsDefault];
    */
}
#pragma -mark关于导航栏上的相关按钮的知识
- (void)navigatioItem
{
//******************************************标题*****************************************
    //1.会把该页面中的所有标题都设置成首页
    //self.title = @"首页";
    //2.专门为导航控制器设置标题
    //self.navigationItem.title = @"第一页";
    
    //self.navigationController.navigationItem.title = @"第一页"; 是错误的，关于navigationBar的需要通过导航控制器来设置，关于navigationItem的不需要通过导航控制器来设置
    
    //3.通过一个视图设置title
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
    imageView.image = [UIImage imageNamed:@"NavBtnleft.png"];
    self.navigationItem.titleView = imageView;

    
//**********************************设置左右item(三种方式)*********************************
    //1.使用系统按钮创建item
    //UIBarButtonItem *rightBtn = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemPlay target:self action:@selector(doRight)];
    
    //2.使用一个title创建item
    //UIBarButtonItem *rightBtn = [[UIBarButtonItem alloc]initWithTitle:@"下一页" style:UIBarButtonItemStylePlain target:self action:@selector(doRight)];
    
    //3.使用一个自定义视图创建item，再用btn创建item
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
    
    btn.backgroundColor = [UIColor blackColor];
    
    [btn setTitle:@"Next" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(doRight) forControlEvents:UIControlEventTouchDown];
    UIBarButtonItem * rightBtn = [[UIBarButtonItem alloc]initWithCustomView:btn];
    
    //将创建的系统按钮赋值给item(每种方法最后都要有)
    self.navigationItem.rightBarButtonItem = rightBtn;
    
    
}
#pragma -mark 点击右边的item时执行的方法
-(void)doRight
{
    NSLog(@"doRight");
    //从当前页面推到指定页面
    secondViewController *second=[[secondViewController alloc]init];
    [self.navigationController pushViewController:second animated:YES];
    //代码会先执行完当前方法，然后再跳转，虽然这里release，但是不影响我们对第二个页面的正常使用，因为在push的时候，导航控制器的栈就会持有下一个页面的所有权
    [second release];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
