//
//  thirdViewController.m
//  lesson_UINavigation
//
//  Created by lanou3g on 15/5/1.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "thirdViewController.h"
#import "secondViewController.h"
@interface thirdViewController ()

@end

@implementation thirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor blackColor]];
    UIButton *b1 = [[UIButton alloc]initWithFrame:CGRectMake(50, 100, 275, 50)];
    [b1 setTitle:@"返回到根视图" forState:UIControlStateNormal];
    [b1 setBackgroundColor:[UIColor blueColor]];
    [b1 addTarget:self action:@selector(dob1) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:b1];
    
    [self.view setBackgroundColor:[UIColor cyanColor]];
    UIButton *b2 = [[UIButton alloc]initWithFrame:CGRectMake(50, 300, 275, 50)];
    [b2 setTitle:@"返回到指定视图" forState:UIControlStateNormal];
    [b2 setBackgroundColor:[UIColor greenColor]];
    [b2 addTarget:self action:@selector(dob2) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:b2];

    
    self.edgesForExtendedLayout = UIRectEdgeNone;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

 - (void)dob1
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (void)dob2
{
    secondViewController * r = [self.navigationController.viewControllers objectAtIndex:1];
    [self.navigationController popToViewController:r animated:YES];
    
}








/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
