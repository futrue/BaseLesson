//
//  DataBaseManager.h
//  lesson_19_dataBase
//
//  Created by lanou3g on 15/5/18.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>//数据内嵌数据库文件
#import "StudentModel.h"
/*
 数据库
 
 Real 浮点数
 integer =int
 text 字符串类型
 BLOB  二进制
 数据库中数据是以表的形式存储的
 数据存在表中的，表又放在数据库中
 
 记录一般是横向看一横信息
 竖向看表，是一个字段一个字段的，叫做字段
 横向看，是一条一条信息，叫记录
 
 SQLite，是一个轻型的关系型数据库，它的设计目标是支持，嵌入式，它占用的资源非常低，在嵌入式设备中，他可能只需要几百K的内存，它能够支持WIndows/LINUX/等等主流的操作系统，目前版本是SQLite3
 
 主键：唯一标示一条记录的字段(它会随着)
 外键：在本表中存在其他表中的主键字段
 关系型数据库：就是根据主键和外键关联起来的
 多个表之间的联系
 
 //创建表
 create table stuBreakFast(fid integer primary key,fname text,price text,address text,stuID integer);
 
 //添加数据（字符要有单引号）
 insert into stuBreakFast(fname,price,address,stuID) values('面包','2.50','全家',1);//主键不用设置，会自动帮我们顺序加一
 
 insert into stuBreakFast(fname,price,address,stuID) values('豆浆','3.50','全家',1);
 
 //更新数据
 update stuBreakFast set fname='油条',price='4.0' where fid=1;
 
 //删除语法
 delete from stuBreakFast where fid=1;
 
 //查询语法
 select 字段一，字段二，字段三。。。from 表名 where 条件
 
 select fname,price from stuBreakFast;// * 表示所有的字段
 select fname from stuBreakFast where address='路边';
 select fname from stuBreakFast where address='全家' and stuID;
 模糊查询
 %,通配一个
 *统配多个
 
 select fname from stuBreakFast where fname like '酸%';
 select count(*) from stuBreakFast;
 select * from stuBreakFast;
 
 工具类最好声明称类方法，不用创建对象查看
 +方法里面只能使用静态变量用static修饰的，不能使用实例变量

 */
@interface DataBaseManager : NSObject
+ (sqlite3 *)openDB;//打开数据库操作
+ (void)closeDB;//关闭数据库的操作
//单例方法
+ (id)singleDB;
#pragma -mark 添加
- (BOOL)addStudent:(StudentModel *)stu;
#pragma -mark 更改
- (BOOL)updateStudentName:(NSString *)name andAge:(int)age andPhoneNum:(NSString *)phone whereIDIsEqual:(int)ID;
#pragma -mark 查询
- (NSMutableArray *)findAll;
#pragma -mark 删除
- (BOOL)deletByID:(int)ID;
























@end
