//
//  ViewController.m
//  lesson_19_dataBase
//
//  Created by lanou3g on 15/5/18.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"
#import "DataBaseManager.h"
#import "StudentModel.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [DataBaseManager openDB];
    DataBaseManager * DBManager=[DataBaseManager singleDB];
//添加
    /*
    StudentModel * student = [[StudentModel alloc]initWithName:@"张三" andAge:20 andID:1 andPhoneNum:@"123456"];
    BOOL success=[DBManager addStudent:student];
   */
//更改
    /*
    BOOL success=[DBManager updateStudentName:@"李四" andAge:23 andPhoneNum:@"121212" whereIDIsEqual:1];
    NSLog(@"success=%d",success);
    */
//查询
    /*
    NSMutableArray * array=[DBManager findAll];
    for (int i =0; i<[array count]; i++)
    {
        StudentModel * student = [array objectAtIndex:i];
        NSLog(@"-%@-%@-%d-%d-",student.name,student.phoneNum,student.ID,student.age);
    }
    */
//删除
    [DBManager deletByID:1];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
