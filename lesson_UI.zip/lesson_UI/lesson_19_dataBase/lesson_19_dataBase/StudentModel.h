//
//  StudentModel.h
//  lesson_19_dataBase
//
//  Created by lanou3g on 15/5/18.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StudentModel : NSObject
@property(nonatomic)int ID;
@property(nonatomic)int age;
@property(strong,nonatomic)NSString *phoneNum;
@property(strong,nonatomic)NSString *name;

- (id)initWithName:(NSString *)name andAge:(int)age andID:(int)ID
       andPhoneNum:(NSString *)phoneNum;
@end


