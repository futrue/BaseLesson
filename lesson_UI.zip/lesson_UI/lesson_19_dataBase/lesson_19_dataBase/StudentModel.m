//
//  StudentModel.m
//  lesson_19_dataBase
//
//  Created by lanou3g on 15/5/18.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "StudentModel.h"

@implementation StudentModel
- (id)initWithName:(NSString *)name andAge:(int)age andID:(int)ID andPhoneNum:(NSString *)phoneNum
{
    if ([super init])
    {
        self.name = name;
        self.age = age;
        self.ID =ID;
        self.phoneNum = phoneNum;
    }
    return self;
}
@end
