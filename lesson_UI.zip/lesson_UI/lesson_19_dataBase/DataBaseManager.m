//
//  DataBaseManager.m
//  lesson_19_dataBase
//
//  Created by lanou3g on 15/5/18.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "DataBaseManager.h"
/*
 一.数据库的操作主要分为:
 1.创建表 2.添加数据 3.删除数据 4.修改数据 5.查询数据
 二. 数据库操作的具体步骤
 1.打开数据库
 2.创建数据库管理员
 3.准备SQL语句
 4.根据判断去执行SQL语句
 三.常用方法
 sqlite3_open :根据一个路径去创建和打开数据库文件
 sqlite3_exec:对数据库的操作
 sqlite3_close : 关闭数据库
 sqlite3_stmt :创建数据管理员的方法
 sqlite3_prepare_v2 :准备一个SQL语句
 SQLITE_OK :表示SQL语句没有问题
 sqlite_bind_XXX:往数据库里面写值(对？的赋值)
 sqlite_step:对表里面的数据，一步一步执行的方法
 SQLITE_DONE :表示执行完毕
 SQLITE_ROW :一行数据
 sqlite_column_XXX :从数据库里面按字段取值的方法
 四.常用的SQL语句
 1.创建表的SQL语句
 create table if not exists classA(ID integer primary key,name text,phoneNum text,age integer
 
 2.插入数据的SQL语句
 insert into classA(name,phoneNum,age) values(?,?,?)
 
 3.修改数据的SQL语句
 update classA set name= ?,phoneNum = ?,age=? where ID =?
 
 4.查询全部数据的SQL语句
 select * from classA
 
 5.根据条件去查找
 6.删除数据的SQL语句
 delete from classA where ID =?
 */
@implementation DataBaseManager
//创建一个数据库对象
static sqlite3 *db = nil;
//1.写单例方法，是为了让数据对象在每个类里面得到的都是同一个数据库对象
//2.写单例方法，也是为了在多线程开发里面保证线程安全
+ (id)singleDB
{
    //先创建一个该类的空对象
    static DataBaseManager * db1 = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
    db1 = [[DataBaseManager alloc]init];
    });
    return db1;
}


#pragma -mark打开数据库操作
+(sqlite3 *)openDB
{
    if (db)
    {
        //能进到该if语句，说明数据库对象已经创建了，只要直接把原来创建的数据库对象直接返回出去就行
        return db;
    }
    else
    {
        //没有创建数据库的时候，就要先创建数据库
        //1.找到数据库文件要存放的路径
        NSString * docPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
        //2.在该路径下创建一个数据库文件的路径
        NSString * filePath = [docPath stringByAppendingPathComponent:@"student.sqlite"];
        NSLog(@"filePath=%@",filePath);
        //3.在该数据库下创建一个数据库文件
        //因为sqlite用得是C级别的语言，所以这里需要将OC的语法都转化为C的语法
        //参数一:数据库的路径，并且要转化成C的路径
        //参数二：你要操作的那个数据库对象
        //这一行代码就是告诉编译器，以后我都用db这个指针来操作硬盘里面的数据库文件
        int state = sqlite3_open([filePath UTF8String], &db);
        if (state !=SQLITE_OK)
        {
            NSLog(@"数据库打开失败");
            return nil;
        }
        else
        {
            //4.创建一个表用来存放数据(SQL语句)
            NSString * createTableStr = @"create table if not exists classA(ID integer primary key,name text,phoneNum text,age integer)";
            //sqlite3_exec:使用数据库的函数
            //参数一:你要使用的哪一个数据库
            //参数二:你要对数据库做什么操作(创建表，增，删，改，查)
            //参数三:系统预留参数
            //参数四:系统预留参数
            //参数五:错误信息,指针的指针填写地址
            char  * errmsg;
            if (sqlite3_exec(db,[createTableStr UTF8String], NULL, NULL, &errmsg))
            {
                //如果能进到该if语句里面说明操作成功
                //关闭数据库
                sqlite3_close(db);
                //释放指针
                sqlite3_free(errmsg);
            }
            //把创建好的表返回出去
            return db;
        }
    }
}
#pragma -mark 关闭数据库操作
+ (void)closeDB
{
    if (db)
    {
        //关闭数据库
        sqlite3_close(db);
    }
}
#pragma -mark 添加
/*
- (BOOL)addStudent:(StudentModel *)stu
{
    //1.打开数据库
    sqlite3 *db = [DataBaseManager openDB];
    //2.创建一个数据库管理员
    sqlite3_stmt * stmt = nil;
    //3.准备添加的SQL语句
    //NSString * addStr = @"insert into classA(name,phoneNum,age) values(?,?,?)";
    //准备执行的语句
    //参数一:准备哪一个数据库操作
    //参数二:sql
    //参数三: -1:(自动计算长度)
    //参数四:用谁去操作数据
    //参数五:系统预留参数
    int state = sqlite3_prepare_v2(db, "insert into classA(name,phoneNum,age) values(?,?,?)", -1,&stmt, nil);
    if (state==SQLITE_OK)
    {
        //对？进行具体的赋值
        //参数一:用仓库管理员去操作数据的写入
        //参数二:对哪一个?(字段)进行赋值
        //参数三:写入数据库的具体的值
        //参数四:-1
        //参数五:系统预留参数
        sqlite3_bind_text(stmt, 1, [stu.name UTF8String], -1, nil);
        sqlite3_bind_text(stmt, 2, [stu.phoneNum UTF8String], -1, nil);
        sqlite3_bind_int(stmt, 3, stu.age);
        //一步一步去执行的方法
        int result = sqlite3_step(stmt);
        if (result==SQLITE_DONE)
        {
            //进到该if语句说明添加成功
            return YES;
        }
    }
    return NO;
}
 */
#pragma -mark 更改
- (BOOL)updateStudentName:(NSString *)name andAge:(int)age andPhoneNum:(NSString *)phoneNum whereIDIsEqual:(int)ID
{
//1.打开数据库
    sqlite3 *db = [DataBaseManager openDB];
//2.创建管理员
    sqlite3_stmt *stmt = nil;
//3.准备更改的SQL语句
    int result = sqlite3_prepare_v2(db, "update classA set name= ?,phoneNum = ?,age=? where ID =?", -1, &stmt, nil);
    //4.如果SQL语句没有错误，进行具体赋值
    if (result==SQLITE_OK)
    {
        //对？进行具体的赋值
        sqlite3_bind_text(stmt, 1, [name UTF8String], -1, nil);
        sqlite3_bind_text(stmt, 2, [phoneNum UTF8String], -1, nil);
        sqlite3_bind_int(stmt, 3, age);
        sqlite3_bind_int(stmt, 4, ID);
        //一步一步去执行的  方法
        if (sqlite3_step(stmt)==SQLITE_DONE)
        {
            return YES;
        }
    }
    return NO;
}
#pragma -mark 查找
- (NSMutableArray *)findAll
{
//1.打开数据库
    sqlite3 *db= [DataBaseManager openDB];
    //2.创建管理员
    sqlite3_stmt * stmt = nil;
    //3.准备查询的SQL语句
    int result = sqlite3_prepare_v2(db, "select * from classA", -1, &stmt, nil);
    if (result==SQLITE_OK)
    {
        //开始搜索
        NSMutableArray * allStudent = [NSMutableArray array];
        //SQLITE_ROW:只要数据库里面还有下一行就会自动的循环
        while (SQLITE_ROW==sqlite3_step(stmt))
        {
            //sqlite3_column_int:从数据里面读取数据的方法
            //参数一:数据库管理者
            //参数二:要读取的数据的标号
            int ID =sqlite3_column_int(stmt, 0);
            const unsigned char * name = sqlite3_column_text(stmt, 1);
            const unsigned char * phoneNum = sqlite3_column_text(stmt, 2);
            int  age = sqlite3_column_int(stmt, 3);
            //将从数据库里面读取出来的C语句级别的数据转化为OC的类型的数据再赋值给Model类
            StudentModel * student = [[StudentModel alloc]init];
            student.ID = ID;
            student.name = [NSString stringWithUTF8String:(char *)name];
            student.phoneNum = [NSString stringWithUTF8String:(char *)phoneNum];
            student.age = age;
            [allStudent addObject:student];
        }
        return allStudent;
    }
    return nil;
}
#pragma -mark 删除
- (BOOL)deletByID:(int)ID
{
    sqlite3 *db = [DataBaseManager openDB];
    sqlite3_stmt * stmt =nil;
    int result =sqlite3_prepare_v2(db, "delete from classA where ID =?", -1, &stmt, nil);
    if (result ==SQLITE_OK)
    {
        sqlite3_bind_int(stmt, 1, ID);
        int state =sqlite3_step(stmt);
        if (state==SQLITE_DONE)
        {
            return YES;
        }
    }
    return NO;
}















@end
