//
//  AppDelegate.h
//  lesson_UI_09
//
//  Created by lanou3g on 15/5/4.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

