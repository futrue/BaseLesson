//
//  RootViewController.m
//  lesson_UI_09
//
//  Created by lanou3g on 15/5/4.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "RootViewController.h"
#import "SecondViewController.h"
@interface RootViewController ()
@property(strong,nonatomic)UITableView *tableView;
@property(strong,nonatomic)NSArray * dataArray;
@property(strong,nonatomic)NSMutableArray * imageTableArray;

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //第一个分区的数据
    NSArray *array1 = [[NSArray alloc]initWithObjects:@"张三",@"李四",@"王五",@"赵六" , nil];
    //第二个分区数据
    NSArray *array2 = [[NSArray alloc]initWithObjects:@"xiaoA",@"xiaoB",@"xiaoC",@"xiaoD", nil];
    //创建表视图的完整数据
    self.dataArray = [[NSArray alloc]initWithObjects:array1,array2 ,nil];
    
    //创建表视图
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height-64) style:UITableViewStyleGrouped];
    //从导航器的下面开始显示
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self.view addSubview:self.tableView];
    //设置代理
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    //设置分割线
    self.tableView.separatorStyle = UITableViewCellEditingStyleNone;
    //设置分割线颜色
    //self.tableView.separatorColor= [UIColor redColor];
  
}
#pragma -mark 一个表视图里面有多少个分区
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataArray.count;
}
#pragma -mark 每个分区里面有多少行
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.dataArray objectAtIndex:section] count];

}
#pragma -mark 创建每个cell的方法
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //1.创建重用标识符
    static NSString * identifier = @"cell";
    //2.利用重用标识符去创建重用队列
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    //3.判断当前这个cell是创建还是重用
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    //4.对cell上面要显示的内容进行设置
    cell.textLabel.text = [[self.dataArray objectAtIndex:indexPath.section]objectAtIndex: indexPath.row];
    return cell;
}

#pragma -mark 给分区加标题
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    NSArray * tittleArray = [[NSArray alloc]initWithObjects:@"第一分区",@"第二分区", nil];
    return [tittleArray objectAtIndex:section];
}
#pragma -mark自定义一个分区的头或者尾
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    NSArray * array = @[@"结束1",@"结束2"];
    //在这里只能设置视图的内容高度无效，通过代理方法来设置高度
    UIButton * button = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 40)];
    [button setBackgroundColor:[UIColor blackColor]];
    [button setTitle:[array objectAtIndex:section] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(doButton:)
     forControlEvents:UIControlEventTouchDown];
    return  button;
}

- (void)doButton:(UIButton *)button
{
    NSLog(@"%@",button.titleLabel.text);
}
#pragma -mark设置分区脚的高度
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 44;
}
#pragma -mark设置cell的高度
 - (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}

#pragma -mark 创建右边快速索引栏的方法
- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    NSArray * array = [NSArray arrayWithObjects:@"第一分区",@"第二分区", nil];
    return array;
}

#pragma -mark点击单元格执行的方法
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SecondViewController *second = [[SecondViewController alloc]init];
    second.name = [[self.dataArray objectAtIndex:indexPath.section]objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:second animated:YES];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
