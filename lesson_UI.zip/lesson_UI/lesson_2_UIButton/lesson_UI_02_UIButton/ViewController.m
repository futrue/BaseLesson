//
//  ViewController.m
//  lesson_UI_02_UIButton
//
//  Created by lanou3g on 15/4/23.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //对实例变量赋值
    _isYES=NO;
    
    
    
    //创建一个UIButton对象
    UIButton* button = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 120, 120)];
    //添加到父视图
    [self.view addSubview:button];
    //设置背景色
    button.backgroundColor = [UIColor redColor];
    //给按钮添加一个正常状态的标题(只有set方法)
    [button setTitle:@"A" forState:UIControlStateNormal];
    //改变标题的大小
    [button.titleLabel setFont:[UIFont systemFontOfSize:80]];
    //改变title的颜色
    [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    //设置高亮状态下的title
    [button setTitle:@"B" forState:UIControlStateHighlighted];
    [button setTitleColor:[UIColor yellowColor] forState:UIControlStateHighlighted];
    
    //设置背景图片
    [button setBackgroundImage:[UIImage imageNamed:@"1.png"] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:@"2.png"]
                      forState:UIControlStateHighlighted];
    //给按钮添加点击事件
    //target:事件的触发目标
    //action:触发什么方法(doButton的参数由调用的对象传入)
    //events:触发事件的方式
    [button addTarget:self action:@selector(doButton:)
                      forControlEvents:UIControlEventTouchDown];

    //练习(给按钮添加点击事件)
    UIButton *lightButton = [[UIButton alloc]initWithFrame:CGRectMake(100, 250, 50, 50)];
    lightButton.backgroundColor =[UIColor cyanColor];
    [self.view addSubview:lightButton];
    [lightButton addTarget:self action:@selector(dolightbutton) forControlEvents:UIControlEventTouchDownRepeat];
   //RGB配色
    UIButton *colorbutton= [[UIButton alloc]initWithFrame:CGRectMake(100, 450, 100, 100)];
    colorbutton.backgroundColor = [UIColor colorWithRed:100/255.0 green:156/255.0 blue:127/255.0 alpha:1];
    [self.view addSubview:colorbutton];
    [colorbutton addTarget:self action:@selector(doChangeBackGroundColor) forControlEvents:UIControlEventTouchDown];

}
//这里的参数btn就是外面那个被按的按钮
- (void)doButton:(UIButton *)btn
{
    NSLog(@"%@",btn.titleLabel.text);
    //获得不同状态下button的标题
    NSLog(@"%@",[btn titleForState:UIControlStateNormal]);
}

//一旦执行就意味着开关被按了一次
- (void)dolightbutton
{
    if (_isYES==YES)//表示灯亮的时候
    {
        NSLog(@"灯已经关了");
        _isYES=NO;
    }
    else//灯关的状态
    {
        NSLog(@"灯开了");
        _isYES=YES;
    }
}

- (void)doChangeBackGroundColor
{
    float r=arc4random()%256;
    float g=arc4random()%256;
    float b=arc4random()%256;
    self.view.backgroundColor = [UIColor colorWithRed:
                                 r/255.0  green:g/255.0 blue:b/255.0 alpha:1];
}























- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
