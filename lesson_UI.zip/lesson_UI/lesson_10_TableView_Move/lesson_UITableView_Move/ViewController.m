//
//  ViewController.m
//  lesson_UITableView_Move
//
//  Created by lanou3g on 15/5/5.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property(strong,nonatomic)UITableView *tableView;
@property(strong,nonatomic)NSMutableArray *array;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //1.准备数据
    self.array = [[NSMutableArray alloc]initWithObjects:@"A",@"B",@"C",@"D",@"E", nil];
    //2.创建表视图
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height-64) style:UITableViewStylePlain];
    //3.让表视图从导航控制器的下面开始
    [self setEdgesForExtendedLayout:UIRectEdgeNone];
    //4.添加到父视图
    [self.view addSubview:self.tableView];
    //5.设置代理
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    //6.添加一个编辑按钮
    self.navigationItem.rightBarButtonItem = [self editButtonItem];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.array.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * identifier = @"cell";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    cell.textLabel.text= [self.array objectAtIndex:indexPath.row];
    return cell;
}

#pragma -mark只是让编辑按钮可以触发编辑状态
- (void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    [super setEditing:editing animated:animated];
    [self.tableView setEditing:editing animated:animated];
}
#pragma -mark设置单元格是否可以移动(第一步)
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==self.array.count-1)
    {
        return NO;
    }
    return YES;
}
#pragma -mark配置移动的规则(第二步)
- (NSIndexPath *)tableView:(UITableView *)tableView targetIndexPathForMoveFromRowAtIndexPath:(NSIndexPath *)sourceIndexPath toProposedIndexPath:(NSIndexPath *)proposedDestinationIndexPath
{
    //如果目的是滑动到最后一行，不能移动
    if (proposedDestinationIndexPath.row == self.array.count-1)
    {
        return sourceIndexPath;
    }
    return proposedDestinationIndexPath;
}
#pragma -mark真正移动的方法(第三步)
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
{
    //1.先记录需要移动的数据
    NSString * str = [self.array objectAtIndex:sourceIndexPath.row];
    //2.将该数据从数组中删除
    [self.array removeObjectAtIndex:sourceIndexPath.row];
    //3.把数据插入目标位置
    [self.array insertObject:str atIndex:destinationIndexPath.row];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
