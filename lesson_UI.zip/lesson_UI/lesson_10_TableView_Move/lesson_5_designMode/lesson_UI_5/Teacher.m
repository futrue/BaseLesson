//
//  Teacher.m
//  lesson_UI_5
//
//  Created by lanou3g on 15/4/28.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Teacher.h"

@implementation Teacher
//静态变量->只能使用静态变量
+ (id)singleTeacher
{
    //1.因为这是一个静态方法，所以加static修饰
    //2.因为单例只会创造一个对象，而static修饰的变量也正好只能初始化一次
    //3.单例对象用static修饰，生命周期为贯穿程序的整个生命周期
    static Teacher *s=nil;
    
    @synchronized(self)//线程锁，在线程锁里面写的代码就会受到线程保护
    {
        if (s==nil)
        {
            s = [[Teacher alloc]init];
        }
    }
    return s;//在MRC下，也不需要autorelease，因为s是用static修饰的，在静态区存储
}
#pragma -mark利用多线程中，只能执行一次的技术
//初始化
+ (id)singleT;
{
    //声明了一个只能执行一次的多线程，线程名:onceToken
    static Teacher *tt = nil;
    static dispatch_once_t onceToken;
    //执行线程代码
    dispatch_once(&onceToken, ^{
        //在这里面的代码只能被执行一次
        tt = [[Teacher alloc]init];
    });
    return tt;
}
@end
