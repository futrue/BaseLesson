//
//  ViewController.m
//  lesson_UI_5
//
//  Created by lanou3g on 15/4/28.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"
#import "Teacher.h"
@interface ViewController ()
/*
 设计模式:是一种思路或者是一种解决某一类问题而特有的方式，并且经过大量的验证。
 MVC设计模式
 委托设计模式(delegate)
 观察者设计模式(KVO)
 单例设计模式:用这种模式给类创建对象的时候，只能创建出来一个对象，
            使用场景:1.创建一些管理者角色的对象
                    2.类与类之间的通信(传值:1.主要利用生命周期长 2.将值保存在属性中传递)
 工厂设计模式
 
 高内聚，低耦合:判断一个项目或者一个设计好坏的标准之一
   高内聚，指的是一个模块内各个元素之间彼此结合的程度，越高越好
   低耦合，指的是模块之间相互联系的程度，两个模块之间的联系度越高，说明他们的耦合度越高，耦合度越高，模块之间的联系就越大，就会相互影响，不符合面向对象编程的模块间相互对立的原则，耦合度越低越好。
 
*/
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Teacher * t = [Teacher singleTeacher];
    Teacher * t1= [Teacher singleTeacher];
    //通过打印地址看出，单例只能创建一个对象，如果多次调用单例方法，也只会创造出一个对象，只不过多起了一个别名
    NSLog(@"t=%p,t1=%p",t,t1);
    
    Teacher * t2 = [Teacher singleT];
    Teacher * t3 = [Teacher singleT];
    NSLog(@"t2=%p,t3=%p",t2,t3);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
