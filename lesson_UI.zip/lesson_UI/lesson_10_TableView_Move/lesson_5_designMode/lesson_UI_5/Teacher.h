//
//  Teacher.h
//  lesson_UI_5
//
//  Created by lanou3g on 15/4/28.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Teacher : NSObject

@property(strong ,nonatomic)NSString *name;
//单例通常都是+方法,没有参数，就是简单的创造一个对象
+ (id)singleTeacher;
//第二种单例形式
+ (id)singleT;
@end
