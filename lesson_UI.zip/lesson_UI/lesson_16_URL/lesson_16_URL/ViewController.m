//
//  ViewController.m
//  lesson_16_URL
//
//  Created by lanou3g on 15/5/13.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"
/*不同点:
 1、给服务器传输数据的方式:
 ￼   GET:通过网址字符串。
    POST:通过data
 2、传输数据的⼤小:
    GET:网址字符串最多255字节。
    POST:使⽤NSData,容量超过1G
 3、安全性: 
 GET:所有传输给服务器的数据,显示在网址里,类似于密码的明文输入,直接可见。
 POST:数据被转成NSData(二进制数据),类似于密码的密⽂输入,无法直接读取
 */

//通常都会把URL定义成宏来使用
//1.通过宏可以给URL起个名字，见名知意
//2.防止在写URL的时候，写错一个字母
#define WangYuan @"http://b.zol-img.com.cn/desk/bizhi/image/6/1920x1200/1423626053405.jpg"


#define BaseUrl @"http://ia.topit.me/a/01/d7/1192857991bbad701ao.jpg"

#define BASE_URL_2 @"http://ipad-bjwb.bjd.com.cn/DigitalPublication/publish/Handler/APINewsList.ashx"

#define BASE_URL_2_PARAM @"date=20131129&startRecord=1&len=5&udid=1234567890&terminalType=Iphone&cid=213"
@interface ViewController ()<NSURLConnectionDataDelegate>
@property(strong,nonatomic)NSMutableData * receive;
@property(nonatomic)long long length;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   //让进度条从零开始
    
    self.progress.progress = 0;
    self.receive = [[NSMutableData alloc]init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma -mark同步GET请求
- (IBAction)synGet:(id)sender
{
    //1.创建一个Url对象
    NSURL *url = [NSURL URLWithString:BaseUrl];
    //2.使用Url对象创建一个Request请求对象
    NSURLRequest * request = [NSURLRequest requestWithURL:url];
    //3.发送同步请求
    NSURLResponse *response = nil;
    NSData * receiveData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
    //4.用相应的控件接收回来的数据
    UIImage * image = [UIImage imageWithData:receiveData];
    //5.使用图片
    self.imageView.image =image;
}
#pragma -mark同步POST请求
- (IBAction)synPost:(id)sender
{
    /*
    //1.封装一个Url
    NSURL *url = [NSURL URLWithString:BASE_URL_2];
    //2.封装一个可变的request
    NSMutableURLRequest * mRequest = [NSMutableURLRequest requestWithURL:url];
    //3.手动指定请求为POST类型
    [mRequest setHTTPMethod:@"POST"];
    //4.把参数放在request的body体里面(dataUsingEncoding:都使用NSUTF8编码)
    NSData * bodyData = [BASE_URL_2_PARAM dataUsingEncoding:NSUTF8StringEncoding];
    [mRequest setHTTPBody: bodyData];
    //5.发送同步请求
    NSData * receiveData = [NSURLConnection sendSynchronousRequest:mRequest returningResponse:nil error:nil];
    //6.数据已经请求回来了，剩下的工作就和网络无关，该进行数据解析(数据格式转换)
    NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:receiveData options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"dic=%@",dic);
  */
}
#pragma -mark 异步GET请求
- (IBAction)asyGet:(id)sender
{
    //1.封装Url对象
    NSURL *url = [NSURL URLWithString:WangYuan];
    //2.封装Request
    NSURLRequest * request = [NSURLRequest requestWithURL:url];
    //3.发送异步链接
    [NSURLConnection connectionWithRequest:request delegate:self];
}
#pragma -mark 异步请求代理方法
/*
 #pragma -mark 请求收到响应时执行的方法
 - (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
 {
 NSLog(@"接收到响应");
 //利用response能够得到你请求东西的大小
 self.length = response.expectedContentLength;
 NSLog(@"self.length = %lld",self.length);
 }
 #pragma -mark 正在接收数据时执行的方法
 - (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
 {
 NSLog(@"正在接收数据");
 //每次请求回来一点,拼接一点
 [self.receive appendData:data];
 //乘以1.0是让结果成为float类型
 self.progress.progress = 1.0*self.receive.length/self.length;
 }
 #pragma -mark 接收完毕时执行的方法
 - (void)connectionDidFinishLoading:(NSURLConnection *)connection
 {
 NSLog(@"接收完毕");
 //用UIImage接收完毕的数据
 UIImage * image = [UIImage imageWithData:self.receive];
 self.imageView.image = image;
 }
 #pragma -mark 接收出错时执行的方法
 - (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
 {
 NSLog(@"接收出错");
 }
 */
#pragma -mark 异步POST请求
- (IBAction)asyPost:(id)sender
{
    //1.封装Url对象
    NSURL *url = [NSURL URLWithString:BASE_URL_2];
    //2.封装一个可变的request
    NSMutableURLRequest * mRequest = [NSMutableURLRequest requestWithURL:url];
    //3.手动指定请求为POST类型
    [mRequest setHTTPMethod:@"POST"];
    //4.把参数放在request的body体里面(dataUsingEncoding:都使用NSUTF8编码)
    [mRequest setHTTPBody:[BASE_URL_2_PARAM dataUsingEncoding:NSUTF8StringEncoding]];
    //5.发送异步链接
    [NSURLConnection connectionWithRequest:mRequest delegate:self];
}

#pragma -mark 异步请求代理方法
#pragma -mark 请求收到响应的时候执行的方法
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    self.length = response.expectedContentLength;
}
#pragma -mark 正在接收数据时执行的方法
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //每次请求一点，拼接一点
    [self.receive appendData:data];
}
#pragma -mark 接收完毕时执行的方法
- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    //数据格式的转化(数据解析)根据数据类型解析
    NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:self.receive options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"dic=%@",dic);

}
#pragma -mark 接收出错时执行的方法
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{}

@end
