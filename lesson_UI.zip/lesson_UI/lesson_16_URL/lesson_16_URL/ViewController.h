//
//  ViewController.h
//  lesson_16_URL
//
//  Created by lanou3g on 15/5/13.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIProgressView *progress;
#pragma -mark 同步GET
- (IBAction)synGet:(id)sender;
#pragma -mark 异步POST
- (IBAction)synPost:(id)sender;
#pragma -mark 同步GET
- (IBAction)asyGet:(id)sender;
#pragma -mark 异步POST
- (IBAction)asyPost:(id)sender;


@end

