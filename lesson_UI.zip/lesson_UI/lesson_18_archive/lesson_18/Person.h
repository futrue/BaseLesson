//
//  Person.h
//  lesson_18
//
//  Created by lanou3g on 15/5/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

//自定义类要想实现数据持久化，必须实现该协议，并且该协议里面有两个必须实现的方法
@interface Person : NSObject<NSCoding>
@property(strong,nonatomic)NSString * name;
@property(nonatomic)int age;

- (id)initWithName:(NSString *)name andAge:(int)age;

@end
