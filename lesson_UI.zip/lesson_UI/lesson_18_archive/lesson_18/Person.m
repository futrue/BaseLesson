//
//  Person.m
//  lesson_18
//
//  Created by lanou3g on 15/5/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "Person.h"

@implementation Person
- (id)initWithName:(NSString *)name andAge:(int)age
{
    if ([super init])
    {
        self.name = name;
        self.age = age;
    }
    return self;
}
#pragma -mark NSCoding协议里面的两个必须执行的方法
#pragma -mark 将对象转化为NSData的方法
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    //转化的为对象的属性(压缩的过程)
    [aCoder encodeObject:self.name forKey:@"name"];
    [aCoder encodeInt:self.age forKey:@"age"];
}
#pragma -mark 将NSData再转化为对象的方法
- (id)initWithCoder:(NSCoder *)aDecoder
{
    if ([super init])
    {
        //解压的过程
        self.name=[aDecoder decodeObjectForKey:@"name"];
        self.age = [aDecoder decodeIntForKey:@"int"];
    }
    return self;
}
@end
