//
//  ViewController.m
//  lesson_18
//
//  Created by lanou3g on 15/5/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Person *p = [[Person alloc]initWithName:@"xiaoA" andAge:20];
//***************************归档，序列化****************************************
    //1.创建一个可变的二进制流
    NSMutableData *data = [[NSMutableData alloc]init];
    //2.创建一个归档对象(将自定义类转化为二进制流的功能)
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc]initForWritingWithMutableData:data];
    //3.用该归档对象，把自定义类的对象转为二进制流
    [archiver encodeObject:p forKey:@"person"];
    //4.归档完毕
    [archiver finishEncoding];
    //5.对归档后的data就可以写入到文件中去了
    [data writeToFile:[self filePath] atomically:YES];
//***************************反归档，反序列化****************************************
    //1.从归档文件中读取出来二进制数据
    NSMutableData *mData = [NSMutableData dataWithContentsOfFile:[self filePath]];
    //2.创建一个反归档对象，将二进制数据解压成正常的OC数据
    NSKeyedUnarchiver * unArchiver = [[NSKeyedUnarchiver alloc]initForReadingWithData:mData];
    Person * p1=[unArchiver decodeObjectForKey:@"person"];
    NSLog(@"name=%@",p1.name);
    //打印p 和 p1的地址
    NSLog(@"p=%p,p1=%p",p,p1);

    
}
#pragma -mark 获取文件路径的方法
-(NSString *)filePath
{
    //下面方法可以通过制定的目录名称(第一个参数)和指定的作用域(第二个参数)以及BOOL类型(第三个参数)来确定是否返回完整路径.
    NSString * docPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString * filePath = [docPath stringByAppendingPathComponent:@"person.text"];
    NSLog(@"filePath=%@",filePath);
    
    return filePath;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
