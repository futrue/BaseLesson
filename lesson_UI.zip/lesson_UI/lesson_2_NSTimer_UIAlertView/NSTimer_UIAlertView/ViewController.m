//
//  ViewController.m
//  NSTimer_UIAlertView
//
//  Created by lanou3g on 15/4/23.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
     UIView *v1;
     UIView *v2;
     UIView *v3;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //NSTimer 可以重复的做某件事情
    _time = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(doTime) userInfo:nil repeats:YES];
    
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 120, 120, 60)];
    [btn setBackgroundColor:[UIColor cyanColor]];
    [btn setTitle:@"停止" forState:UIControlStateNormal];
    [self.view addSubview:btn];
    
    [btn addTarget:self action:@selector(doStop) forControlEvents:UIControlEventTouchDown];
    
    v1 = [[UIView alloc]initWithFrame:CGRectMake(100, 250, 120, 120)];
    v1.backgroundColor= [UIColor yellowColor];
    [self.view addSubview:v1];
    v2 = [[UIView alloc]initWithFrame:CGRectMake(120, 270, 80, 80)];
    v2.backgroundColor= [UIColor redColor];
    [self.view addSubview:v2];
    v3 = [[UIView alloc]initWithFrame:CGRectMake(140, 290, 40, 40)];
    v3.backgroundColor= [UIColor blackColor];
    [self.view addSubview:v3];
//****************************************警告框*******************************************
    /*
     1.必须要show;
     2.message:警告框的主要内容;
     3.当只有other键的时候，取消键在左边;
     4.当有多个other键的时候，取消键在最下面,其他键按顺序来
    */
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"标题"
      message:@"电量不足,请及时充电" delegate:self cancelButtonTitle:@"取消"
      otherButtonTitles: @"确定",nil];
    //必须展示才能出现
    [alert show];
    
    
    
    
 
}



-(void)doStop
{
    //计时器停止的方法
    [_time invalidate];
}
- (void)doTime
{
    //NSLog(@"123");
    //定义一个空的视图
    UIView *v=[[UIView alloc]init];
    v.backgroundColor=v1.backgroundColor;
    v1.backgroundColor=v2.backgroundColor;
    v2.backgroundColor=v3.backgroundColor;
    v3.backgroundColor=v.backgroundColor;
}
//UIAlerView协议中声明的方法
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex

{
    if (buttonIndex == 0)
    {
        NSLog(@"取消");
    }
    else
    {
        NSLog(@"其他按钮里面的第一个即“确定”");
    }
}











- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
