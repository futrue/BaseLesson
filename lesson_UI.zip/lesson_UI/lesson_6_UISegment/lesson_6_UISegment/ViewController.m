//
//  ViewController.m
//  lesson_6_UISegment
//
//  Created by lanou3g on 15/4/29.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //*****************************************1.分段控制器*****************************************
    
    NSArray *itemsArray = @[@"红",@"黄",@"蓝",@"绿"];
    //创建一个分段控制器(items必须是字符串或者是图片)
    UISegmentedControl * segment = [[UISegmentedControl alloc]initWithItems:itemsArray];
    [self.view addSubview:segment];
    segment.frame = CGRectMake(10, 30, [UIScreen mainScreen].bounds.size.width-20, 40);
    //是否让当前的item保持被选中状态
    segment.momentary=YES;
    //根据值的改变来触发 (UIControlEventValueChanged)
    [segment addTarget:self action:@selector(doSegment:) forControlEvents:UIControlEventValueChanged];
    //让分段控制器的item根据内容自己适应宽度
    segment.apportionsSegmentWidthsByContent = YES;
    
    //插入一个item
    [segment insertSegmentWithTitle:@"黑" atIndex:2 animated:YES];
    [segment removeSegmentAtIndex:2 animated:YES];
    
    //不能同时设置标题和图片
    //[segment setImage:[UIImage imageNamed:@"1.png"] forSegmentAtIndex:1];
    
    //设置item的宽度
    //[segment setWidth:100 forSegmentAtIndex:2];
    //设置分段控制器整体的颜色
    segment.tintColor = [UIColor cyanColor];
    //设置分段控制器背景图片(默认拉伸，需要大小合适的图片)
    //[segment setBackgroundImage:[UIImage imageNamed:@"1.png"] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
//*****************************************2.滑块控件*****************************************
    //滑块尺寸对于控件本身不起作用
    UISlider * slider= [[UISlider alloc]initWithFrame:CGRectMake(10, 150, [UIScreen mainScreen].bounds.size.width-20, 100)];
    //[slider setBackgroundColor:[UIColor cyanColor]];
    [self.view addSubview:slider];
    
    //背景色
    /*
     slider.thumbTintColor = [UIColor blackColor];
     slider.maximumTrackTintColor = [UIColor redColor];
     slider.minimumTrackTintColor = [UIColor grayColor];
     */
    //背景图片
    [slider setThumbImage:[UIImage imageNamed:@"1.png"] forState:UIControlStateNormal];
    
    //滑线的背景图片
    //[slider setMinimumTrackImage:[UIImage imageNamed:@"1.png"] forState:UIControlStateNormal];
    
    slider.minimumValue = 0.0;
    slider.maximumValue = 1.0;
    slider.value = 0.5;
    
    [slider addTarget:self action:@selector(doSlider:)
     forControlEvents:UIControlEventTouchDown];
//*****************************************3.UISwitch*****************************************
    
    UISwitch *switchView = [[UISwitch alloc] initWithFrame:CGRectMake(100, 250, 0, 0)];
    [self.view addSubview:switchView];
    
//*****************************************3.UIStepper*****************************************
    UIStepper *stepper = [[UIStepper alloc]initWithFrame:CGRectMake(100, 300, 0, 0)];
    [self.view addSubview:stepper];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//点击分段控制器执行的方法
-(void)doSegment:(UISegmentedControl *)seg
{
    if (seg.selectedSegmentIndex == 0)
    {
        self.view.backgroundColor = [UIColor redColor];
    }
    else if (seg.selectedSegmentIndex ==1)
    {
        self.view.backgroundColor = [UIColor yellowColor];
    }
    else if (seg.selectedSegmentIndex ==2)
    {
        self.view.backgroundColor = [UIColor blueColor];
    }
    else if (seg.selectedSegmentIndex ==3)
    {
        self.view.backgroundColor = [UIColor greenColor];
    }
}
- (void)doSlider:(UISlider *)s
{
    //通常根据值的改变做一些控制事情
    NSLog(@"当前的值为%f",s.value);
    //音乐播放器的音量控制，只需要将s.value赋值给音乐播放器的音量属性就行
    
}

@end
