//
//  ViewController.m
//  lesson_12_block
//
//  Created by lanou3g on 15/5/8.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"
typedef void(^Myblock)();
@interface ViewController ()
//1.block要用copy去修饰
//2.block声明的时候在栈区
//3.用copy修饰会把里面的内容从栈区copy到堆区
//4.用了copy修饰就必须有一个release与之对应
@property(copy,nonatomic)Myblock block;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //防止循环引用
    __block ViewController *vc = self;
    NSLog(@"1----%lu",[self retainCount]);
    self.block = ^{
        /*
         只要在block内部使用实例变量，block都会持有该对象的所有权
         1.block属性是定义在该视图控制器内，所以self拥有block的所有权
         2.又在block内使用的该视图控制器，这样block也持有了该视图控制器的所有权
         3.这时候block和视图控制器都相互持有，循环引用，谁都不能释放，所以不能这样使用
         4.使用__block修饰可以解决
         */
        self.view.backgroundColor = [UIColor redColor];
        NSLog(@"2----%lu",[self retainCount]);
    };
    //调用
    self.block();
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
