//
//  ViewController.m
//  lesson_7_UIScrollview
//
//  Created by lanou3g on 15/4/30.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"
//延展也可以遵守协议
@interface ViewController ()
@property(strong,nonatomic)UIScrollView *scrollView;
@property(strong,nonatomic)UIImageView *imageView;
@property (strong,nonatomic)UIPageControl *pageControl;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //单例方法(系统级别)，只创造出一个对象，是一个数据持久化的方式
    //每次启动记录数据，下次运行时数据还在,保证开机引导图只在第一次启动时运行
    //存档作用
//    NSUserDefaults * user = [NSUserDefaults standardUserDefaults];
//    if (![user valueForKey:@"first"])
//    {
        //调用ScrollView相关属性的方法
        [self layoutScrollView];
        //调用在滑动视图设置图片的方法
        [self layoutImageView];
        //调用pageControl的方法
        [self layoutPageControl];
        //为user设置一个key为first的键值对
//        [user setBool:YES forKey:@"first"];
    
        //调用轮播时间的方法
        [self scrollviewTime:1];

//    }
//    else
//    {
//        UIView *aView = [[UIView alloc]initWithFrame:self.view.bounds];
//        aView.backgroundColor=[UIColor magentaColor];
//        [self.view addSubview:aView];
//    }
    
}
#pragma -mark 设置滑动视图自动滑动的方法
-(void)scrollviewTime:(NSTimeInterval )time
{
    
    NSTimer * timer = [NSTimer scheduledTimerWithTimeInterval:time target:self selector:@selector(doTime) userInfo:nil repeats:YES];
}
#pragma -mark 定时器实行的方法
-(void)doTime
{
    static int i = 0;//静态变量
    self.scrollView.contentOffset = CGPointMake(self.view.bounds.size.width*(i%6), 0);
    i++;
}
#pragma -mark ScrollView的布局和属性
-(void)layoutScrollView
{
    self.scrollView = [[UIScrollView alloc]initWithFrame:self.view.bounds];
    //1.将滑动视图添加到self.view上
    [self.view addSubview:self.scrollView];
    //2.设置背景色
    self.scrollView.backgroundColor = [UIColor redColor];
    //3.设置滑动视图的滑动区间
    self.scrollView.contentSize = CGSizeMake(self.view.bounds.size.width*6, 0);
    //4.设置滑动条是否显示(默认YES)
    //self.scrollView.showsHorizontalScrollIndicator = NO;
    //5.设置滑动条样式
    self.scrollView.indicatorStyle = UIScrollViewIndicatorStyleBlack;
    //6.设置滑动到边界是否回弹
    self.scrollView.bounces = YES;
    //7.设置是否整形滑动(默认可以停在两张image之间)
    self.scrollView.pagingEnabled = YES;
    
    //8.关于缩放的属性，设置缩放的最大值
    self.scrollView.maximumZoomScale = 2;
    //9.设置缩放的最小值
    self.scrollView.minimumZoomScale = 0.5;
    //10.设置缩放比例
    self.scrollView.zoomScale = 1;
    //11.设置代理(使用系统协议第二步)
    self.scrollView.delegate=self;
}
#pragma -mark 布局在ScrollView上的要滑动的图片
-(void)layoutImageView
{
    for (int i=0; i<6; i++)
    {
        //1.在ContentView上面创建需要显示的UIImageView
        self.imageView = [[UIImageView alloc]initWithFrame:CGRectMake(self.view.bounds.size.width*i, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
        //2.给每个相框添加图片
        self.imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"v6_guide_%d@2x.png",i+1]];
        if (i==5)
        {
            //<1>打开用户交互
            self.imageView.userInteractionEnabled = YES;
            //<2>创建轻拍手势
            UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(welcome:)];
            //<3>将手势添加到视图上
            [self.imageView addGestureRecognizer:tap];
        }
        //3.将创建好的相框添加到滑动视图上
        [self.scrollView addSubview:self.imageView];
    }
}
#pragma -mark PageControl相关设置的方法
-(void)layoutPageControl
{

    self.pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(50, self.view.bounds.size.height-50, 280, 30)];
    //[self.pageControl setBackgroundColor:[UIColor blackColor]];
    [self.view addSubview:self.pageControl];
    //1.设置页数
    self.pageControl.numberOfPages = 6;
    //2.设置页面点当前颜色
    self.pageControl.currentPageIndicatorTintColor = [UIColor blueColor];
    //3.设置全部页面点的颜色
    self.pageControl.pageIndicatorTintColor = [UIColor redColor];
    //4.当只有一个页面的时候，隐藏pageControl
    self.pageControl.hidesForSinglePage = YES;
    //5.添加点击事件
    [self.pageControl addTarget:self action:@selector(doPageControl:) forControlEvents:UIControlEventValueChanged];
    
 

}
#pragma -mark 点击pageControl时执行的方法
-(void)doPageControl:(UIPageControl *)pageControl
{
    //点击pageControl控制scrollView(滑动视图)
    self.scrollView.contentOffset =CGPointMake(self.view.bounds.size.width*self.pageControl.currentPage, 0);
}

#pragma -mark当滑动到最后一页，点击页面就会执行该方法
- (void)welcome:(UITapGestureRecognizer *)tap
{
    [self.scrollView removeFromSuperview];
    UIView *aView = [[UIView alloc]initWithFrame:self.view.bounds];
    aView.backgroundColor = [UIColor cyanColor];
    [self.view addSubview:aView];
}


#pragma -mark 滑动视图的代理方法(delegate)

#pragma -mark 1.选择可以缩放的视图
- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    //缩放完毕之后，滑动就有问题
    return [self.scrollView.subviews objectAtIndex:0];
}
#pragma -mark 2.正在缩放时执行的方法
-(void)scrollViewDidZoom:(UIScrollView *)scrollView
{

}
#pragma -mark 3.正在滑动时执行的方法
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
//    NSLog(@"偏移量=%f",scrollView.contentOffset.x );
//    if ((int)scrollView.contentOffset.x<=-50)
//    {
//        NSLog(@"正在加载。。。");
//    }
    
    
    //通过滑动视图控制pageControl
    self.pageControl.currentPage = (int)(self.scrollView.contentOffset.x/self.view.bounds.size.width);
}
#pragma -mark 4.将要开始拖动滑动视图时执行的方法
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{


}
#pragma -mark 5.结束拖拽，将要减速的时候执行的方法
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{



}

#pragma -mark 6.减速完成时执行的方法
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //通常会在该方法中写重新请求最新网络数据的代码
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
