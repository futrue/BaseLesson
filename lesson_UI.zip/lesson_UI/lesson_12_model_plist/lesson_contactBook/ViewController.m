//
//  ViewController.m
//  lesson_contactBook
//
//  Created by lanou3g on 15/5/7.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor cyanColor]];
    //1.将plist文件从工程里面根据路径读取出来
    NSString * filePath = [[NSBundle mainBundle]pathForResource:@"Student" ofType:@"plist"];
    //2.用字典或者数组去接受plist文件
    NSDictionary * plistDic = [NSDictionary dictionaryWithContentsOfFile:filePath];
    NSLog(@"%@",plistDic);
    NSString * str=[[plistDic valueForKey:@"A"] objectAtIndex:1];
    NSLog(@"%@",str);
    
    
    
    
    
    //使用模态视图切换页面
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 200, self.view.bounds.size.width-200, 50)];
    btn.backgroundColor= [UIColor blueColor];
    [btn setTitle:@"切换" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(doBtn) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:btn];


}
- (void)doBtn
{
    SecondViewController * second = [[SecondViewController alloc]init];
    //将要出现的视图控制器以什么形式出现
    second.modalTransitionStyle =UIModalTransitionStyleFlipHorizontal;
    //模态视图推出临时页面
    [self presentViewController:second animated:YES completion:^{
        NSLog(@"已经推完毕");
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
