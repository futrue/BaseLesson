//
//  SecondViewController.m
//  lesson_contactBook
//
//  Created by lanou3g on 15/5/7.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor= [UIColor yellowColor];
    //第二个页面
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 200, self.view.bounds.size.width-200, 50)];
    btn.backgroundColor=[UIColor redColor];
    [btn setTitle:@"返回" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(doBtn) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:btn];




}

- (void)doBtn
{
[self dismissViewControllerAnimated:YES completion:^{
    NSLog(@"已返回");
}];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
