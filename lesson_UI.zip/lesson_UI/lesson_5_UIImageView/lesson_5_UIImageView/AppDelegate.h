//
//  AppDelegate.h
//  lesson_5_UIImageView
//
//  Created by lanou3g on 15/4/28.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

