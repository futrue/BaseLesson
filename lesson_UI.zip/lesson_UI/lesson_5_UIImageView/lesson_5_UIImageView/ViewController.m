//
//  ViewController.m
//  lesson_5_UIImageView
//
//  Created by lanou3g on 15/4/28.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    //相框类
    UIImageView *_imageView;
    UIImageView *_imageView1;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置UIView和它的子类，内容显示样式的属性
    _imageView.contentMode=UIViewContentModeScaleAspectFill;
    
    _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(100, 30, 375-200, 375-200)];
    [self.view addSubview:_imageView];
    //要给相框添加一张图片才能显示，单独的图片需要依赖相框来显示
    
    //1.通过图片名直接找到图片(便利构造器)
    //_imageView.image= [UIImage imageNamed:@"1.png"];
    
    //2.通过路径去找图片
    NSString * filePath = [[NSBundle mainBundle]pathForResource:@"1" ofType:@"png"];
    NSLog(@"filePath=%@",filePath);
    
    //3.用这个图片路径创建一个图片
    UIImage * image=[[UIImage alloc]initWithContentsOfFile:filePath];
    _imageView.image = image;
    
//****************************************读取多张图片***********************************
    NSMutableArray *imageArray = [[NSMutableArray alloc]init];
    for (int i = 1; i<53; i++)
    {
        //1.创建要查找文件的名字
        NSString *imageName = [NSString stringWithFormat:@"a%d",i];
        //2根据文件的名字在bundle中找到文件的路径.
        NSString *filePath = [[NSBundle mainBundle]pathForResource:imageName ofType:@"tiff"];
        //3.根据路径上面的内容创建对象
        UIImage *_image = [[UIImage alloc]initWithContentsOfFile:filePath];
        //4.将创建的图片添加到数组中去
        [imageArray addObject:_image];
    }
    //创建一个相框
    _imageView1=[[UIImageView alloc]initWithFrame:CGRectMake(80, 240, 215, 300)];
    [self.view addSubview:_imageView1];
    //设置播放时间
    _imageView1.animationDuration=15;
    //设置播放内容
    _imageView1.animationImages=imageArray;
    ///设置播放重复次数(0:一直重复)
    _imageView1.animationRepeatCount=0;
    //开始动画
    [_imageView1 startAnimating];
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
