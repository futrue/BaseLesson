//
//  MyTableViewCell.h
//  lesson_11_DiyCell
//
//  Created by lanou3g on 15/5/6.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FoodModel.h"
@interface MyTableViewCell : UITableViewCell
@property(strong,nonatomic)UIImageView * myImageView;//不要和系统的imageView重名
@property(strong,nonatomic)UILabel * nameLabel;
@property(strong,nonatomic)UILabel * priceLabel;
@property(strong,nonatomic)UILabel * countLabel;
@property(strong,nonatomic)UILabel * addressLabel;

//声明一个model类的属性用来赋值使用
@property(strong,nonatomic)FoodModel * fm;
@end
