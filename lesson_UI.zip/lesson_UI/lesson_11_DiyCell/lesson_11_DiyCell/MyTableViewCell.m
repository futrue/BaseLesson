//
//  MyTableViewCell.m
//  lesson_11_DiyCell
//
//  Created by lanou3g on 15/5/6.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "MyTableViewCell.h"

@implementation MyTableViewCell

//重写set方法(只有将属性转变为实例变量才可以重写set方法)
@synthesize fm=_fm;


#pragma -mark代码创建cell的时候执行的方法
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if ([super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        //初始化的代码
        [self laoutCell];
    }
    return self;
}
#pragma -mark对cell进行排版的方法
- (void)laoutCell
{
    //设置自定义cell的图片
    self.myImageView = [[UIImageView alloc]initWithFrame:CGRectMake(100, 10, self.bounds.size.width-200, 80)];
    self.myImageView.backgroundColor = [UIColor redColor];
    //将自定义的空间添加到cell的contentView
    [self.contentView addSubview:self.myImageView];

    //设置自定义cell的名字的label
    self.nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(2, 2, 96, 25)];
    self.nameLabel.backgroundColor = [UIColor cyanColor];
    [self.contentView addSubview:self.nameLabel];
    
    //设置自定义cell的价格的label
    self.priceLabel = [[UILabel alloc]initWithFrame:CGRectMake(2, 73, 96, 25)];
    self.priceLabel.backgroundColor = [UIColor blueColor];
    [self.contentView addSubview:self.priceLabel];
    
    //设置地址的label
    self.addressLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.bounds.size.width-98, 2, 96, 25)];
    self.addressLabel.backgroundColor = [UIColor greenColor];
    [self.contentView addSubview:self.addressLabel];
    
    //设置购买人数的label
    self.countLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.bounds.size.width-98, 73, 96, 25)];
    self.countLabel.backgroundColor = [UIColor magentaColor];
    [self.contentView addSubview:self.countLabel];
}
#pragma -mark重写set方法
- (void)setFm:(FoodModel *)fm
{
    self.myImageView.image=[UIImage imageNamed:fm.imageName];
    self.nameLabel.text = fm.name;
    self.priceLabel.text = fm.price;
    self.addressLabel.text = fm.address;
    self.countLabel.text = fm.count;
}

#pragma -mark从可视化编程工具里面创建一个cell
- (void)awakeFromNib {
    // Initialization code
}
#pragma -mark设置点击cell后的方法
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
