//
//  ViewController.m
//  lesson_11_DiyCell
//
//  Created by lanou3g on 15/5/6.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property(strong,nonatomic)UITableView * tableView;
@property(strong,nonatomic)NSArray *dataArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    FoodModel * fm1 = [[FoodModel alloc]initWithName:@"鱼香肉丝" andPrice:@"18" andCount:@"22" andAddress:@"清河" andImageName:@"1.png"];
    FoodModel * fm2 = [[FoodModel alloc]initWithName:@"宫保鸡丁" andPrice:@"20" andCount:@"11" andAddress:@"肯德基" andImageName:@"2.png"];
    FoodModel * fm3 = [[FoodModel alloc]initWithName:@"全家桶" andPrice:@"60" andCount:@"20" andAddress:@"麦当劳" andImageName:@"3.png"];
    
    self.dataArray = [[NSArray alloc]initWithObjects:fm1,fm2,fm3, nil];
    
    
    
    
    
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 20, self.view.bounds.size.width, self.view.bounds.size.height-20) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  3;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * identifier = @"cell";
    MyTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell==nil)
    {
        cell = [[MyTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault
                                     reuseIdentifier:identifier];
    }
    
    //第一种赋值写法
    //cell.nameLabel.text = [[self.dataArray objectAtIndex:indexPath.row] name];
    //第二种赋值写法
    cell.fm=[self.dataArray objectAtIndex:indexPath.row];
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
