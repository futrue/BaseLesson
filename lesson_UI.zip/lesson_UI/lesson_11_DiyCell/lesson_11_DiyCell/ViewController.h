//
//  ViewController.h
//  lesson_11_DiyCell
//
//  Created by lanou3g on 15/5/6.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyTableViewCell.h"
#import "FoodModel.h"
@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>


@end

