//
//  FoodModel.h
//  lesson_11_DiyCell
//
//  Created by lanou3g on 15/5/6.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FoodModel : NSObject
@property(strong,nonatomic)NSString * name;
@property(strong,nonatomic)NSString * price;
@property(strong,nonatomic)NSString * count;
@property(strong,nonatomic)NSString * address;
@property(strong,nonatomic)NSString * imageName;
- (id)initWithName:(NSString *)name andPrice:(NSString *)price andCount:(NSString *)count
        andAddress:(NSString *)address andImageName:(NSString *)imageName;
@end
