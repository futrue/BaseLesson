//
//  AppDelegate.m
//  lesson_UI_01
//
//  Created by lanou3g on 15/4/22.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "AppDelegate.h"
#import "MyViewController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate

#pragma -mark应用程序准备完毕，马上将要启动的时候执行的方法
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    
    
    //1.创建一个窗口(父视图)
    //<1>创建一个窗口 [UIScreen mainScreen]是获得你当前设备屏幕的方法
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    //<2>给创建出来的窗口添加一个背景颜色
    [self.window setBackgroundColor:[UIColor redColor]];
    //<3>给window添加一个视图控制器(页面，白纸)
    MyViewController *MyVc=[[MyViewController alloc]init];
    self.window.rootViewController=MyVc;
    //<4>让这个窗口显示出来
    [self.window makeKeyAndVisible];
    
    //创建一个视图
    UIView *yellowView = [[UIView alloc]initWithFrame:CGRectMake(100, 100, 120, 120)];
    //设置背景颜色
    yellowView.backgroundColor=[UIColor yellowColor];
    //父类写在前，子类写在后面
    [self.window addSubview:yellowView];

    
    for (int i =0 ; i<5; i++)
    {
        UIView *v=[[UIView alloc]initWithFrame:CGRectMake(10+62*i, 220, 52, 52)];
        
        //tag:给视图添加一个标记，方便快速的找到视图
        v.tag=i+1;
        
        v.backgroundColor = [UIColor blueColor];
        [self.window addSubview:v];
    }
    //根据标记找到想要的视图
    [[self.window viewWithTag:3]setBackgroundColor:[UIColor blackColor]];
    
//**********************************视图间的层次关系**********************************
   /*
    1.先创建的层级关系没有后创建的大，后面的视图可能会覆盖其那面的视图
    2.父视图调用改变视图层级关系的方法
    */
    UIView * purpleView=[[UIView alloc]initWithFrame:CGRectMake(120, 120, 120, 120)];
    [purpleView setBackgroundColor:[UIColor purpleColor]];
    [self.window addSubview:purpleView];
    UIView *greenView = [[UIView alloc]initWithFrame:CGRectMake( 110, 110, 120, 120)];
    [greenView setBackgroundColor:[UIColor greenColor]];
    //改变视图层次关系
    [self.window insertSubview:greenView atIndex:3];
    
    UIView *cyan=[[UIView alloc]initWithFrame:CGRectMake(130, 130, 120, 120)];
    
    cyan.backgroundColor = [UIColor cyanColor];
    [self.window insertSubview:cyan atIndex:5];
    
//***************************************bounds***************************************
   //frame是相对于父坐标系来说的
   //bounds是相对于自身坐标系来说的·
     NSLog(@"frame=%@",NSStringFromCGRect(cyan.frame));
     NSLog(@"bounds=%@",NSStringFromCGRect(cyan.bounds));
//***************************************常用属性***************************************
    //隐藏
    [[self.window viewWithTag:3] setHidden:YES];
    //移除
    [[self.window viewWithTag:4] removeFromSuperview];
    //透明度
    cyan.alpha = 0.1;
//***************************************UIView的常用动画***********************************
    //动画开始
    [UIView beginAnimations:nil context:nil];
    //设置动画执行的时间
    [UIView setAnimationDuration:3.0f];
    //动画的最终结果
    [self.window viewWithTag:1].frame=CGRectMake(10, 400, 100, 100);
    [self.window viewWithTag:1].alpha=0;
    //提交动画
    [UIView commitAnimations];
    
   
    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
