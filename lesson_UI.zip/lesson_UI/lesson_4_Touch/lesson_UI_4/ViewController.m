//
//  ViewController.m
//  lesson_UI_4
//
//  Created by lanou3g on 15/4/27.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    
    float x;//触摸点距离中心点x的距离
    float y;//触摸点距离中心点y的距离
    UIView *menuView;

}
@property(strong,nonatomic)UIView *aView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //创建一个拖拽视图
    self.aView = [[UIView alloc]initWithFrame:CGRectMake(100,100, 120, 120)];
    //设置一个颜色
    self.aView.backgroundColor= [UIColor redColor];
    //添加到父视图上显示
    [self.view addSubview:self.aView];
    
    //模拟菜单出现的过程(并且将菜单隐藏在屏幕的外面)
    menuView = [[UIView alloc]initWithFrame:CGRectMake(-100, 0, 100, [UIScreen mainScreen].bounds.size.height)];
    menuView.backgroundColor=[UIColor cyanColor];
    [self.view addSubview:menuView];
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    //1.得到触摸对象
    UITouch * touch = [touches anyObject];
    //2.根据触摸对象得到触摸点
    CGPoint point = [touch locationInView:self.view];
    //3.计算触摸点和中心的距离
    x=self.aView.center.x-point.x;
    y=self.aView.center.y-point.y;
    
    
  
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    //对于系统的方法，无论是协议方法，还是系统类自带的方法，参数是直接使用，并且参数里面是有值的
    //1.得到触摸的对象
    UITouch * touch = [touches anyObject];
    //2.根据触摸对象获得当前触摸的位置
    CGPoint point = [touch locationInView:self.view];
    //3.将得到的触摸点的位置赋值给拖拽视图的中心点，从而完成拖拽视跟着我们的触摸移动的功能
    if(touch.view==self.aView)
    {
        [self.aView setCenter:CGPointMake(point.x+x, point.y+y)];
    }
    
    
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch * touch = [touches anyObject];
    CGPoint point = [touch locationInView:self.view];
    
    //得到上一个触摸点位置
    CGPoint previousPoint = [touch previousLocationInView:self.view];
    
    
    if((point.x-previousPoint.x)>0)
    {
        NSLog(@"向右滑动");
        
        /*使用动画块
          参数1:  动画执行的时间
          参数2:  动画执行的内容
          参数3:  动画结束时执行的block
        */
        [UIView animateWithDuration:1 animations:^{
            //动画执行的内容
            menuView.frame=CGRectMake(0, 0, 100, [UIScreen mainScreen].bounds.size.height);
        }
        completion:^(BOOL finished) {
            if (finished)
            {
                NSLog(@"动画结束");
            }
        }];
    }
    //菜单栏收回(全局变量)
    if((point.x-previousPoint.x)<0)
    {
        [UIView animateWithDuration:1 animations:^{
            menuView.frame=CGRectMake(-100, 0, 100, [UIScreen mainScreen].bounds.size.height);
        }
        completion:^(BOOL finished) {
            if (finished)
            {
                NSLog(@"菜单栏收回");
            }
        }];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
