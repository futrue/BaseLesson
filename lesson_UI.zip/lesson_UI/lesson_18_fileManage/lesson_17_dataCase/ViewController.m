//
//  ViewController.m
//  lesson_17_dataCase
//
//  Created by lanou3g on 15/5/15.
//  Copyright (c) 2015年 HYD. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //沙盒:文件夹
    /*
    //1.根目录(路径)
    NSString *homePath = NSHomeDirectory();
    NSLog(@"homePath=%@",homePath);
    //2.Documents
    NSString *DocumentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSLog(@"DocumentsPath =%@",DocumentsPath);
    //3.进入到缓存文件夹
    NSString * cachesPath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    //4.tmp文件夹
    NSString * tmpPath = NSTemporaryDirectory();
    NSLog(@"tmpPath=%@",tmpPath);
    */
    
    //二.文件的操作
    //1.文件的操作都是用文件管理者操作的
    //2.文件的操作都是操作的文件路径
    
    //1.先创建文件路径
    NSString * docPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    //2.创建文件路径(用该方法拼接可以直接写文件名)
    NSString *filePath = [docPath stringByAppendingPathComponent:@"textField.text"];
    NSLog(@"filePath=%@",filePath);
    //3.在该路径下创建一个文件
    //创建一个文件管理者(系统单例)
    NSFileManager * fileManager = [NSFileManager defaultManager];
    //用文件管理者先判断一下该路径下有没有文件
    if ([fileManager fileExistsAtPath:filePath])
    {
       //已经有文件了
        NSLog(@"已经有文件了所以不需要再创建，直接使用就可以");
    }
    else
    {
        //文件管理者在该路径下创建一个文件
        [fileManager createFileAtPath:filePath contents:nil attributes:nil];
        NSLog(@"filePath=%@",filePath);
        
    }
    //4.往文件里面写入东西
    //NSString ,NSArray,NSDictionary,NSData这四个类可以直接写入到文件中去
    NSString *str = @"Iphone6";
    [str writeToFile:filePath atomically:NO encoding:NSUTF8StringEncoding error:nil];
    NSString * str1 = @"456";
    [str1 writeToFile:filePath atomically:NO encoding:NSUTF8StringEncoding error:nil];
    //5.使用文件当中的数据(读取)
    NSString * fileStr = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"fileStr=%@",fileStr);
    //6.文件的移动，首先要先创建一个目标路径
    NSString *libPath = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString * fileNamePath = [libPath stringByAppendingPathComponent:@"textField.text"];
    //从原始路径移动到目标路径
    BOOL success =[fileManager moveItemAtPath:filePath toPath:fileNamePath error:nil];
    if (success)
    {
        NSLog(@"移动成功");
    }
    else
    {
        NSLog(@"移动失败");
    }
    //7.文件删除
    if ([fileManager fileExistsAtPath:fileNamePath])
    {
        [fileManager removeItemAtPath:fileNamePath error:nil];
    }
    //8.查询文件夹下面的子文件
    NSArray *array = [fileManager contentsOfDirectoryAtPath:libPath error:nil];
    NSLog(@"array=%@",array);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
